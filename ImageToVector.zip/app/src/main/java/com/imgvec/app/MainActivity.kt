package com.imgvec.app

import android.Manifest
import android.content.ClipData
import android.content.ClipboardManager
import android.content.Context
import android.content.pm.PackageManager
import android.net.Uri
import android.os.Bundle
import android.widget.Toast
import androidx.activity.ComponentActivity
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.compose.setContent
import androidx.activity.enableEdgeToEdge
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.animation.core.LinearEasing
import androidx.compose.animation.core.RepeatMode
import androidx.compose.animation.core.animateFloat
import androidx.compose.animation.core.infiniteRepeatable
import androidx.compose.animation.core.rememberInfiniteTransition
import androidx.compose.animation.core.tween
import androidx.compose.foundation.Canvas
import androidx.compose.foundation.Image
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.ColumnScope
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.aspectRatio
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.navigationBarsPadding
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.statusBarsPadding
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Text
import androidx.compose.material3.lightColorScheme
import androidx.compose.runtime.Composable
import androidx.compose.runtime.CompositionLocalProvider
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableFloatStateOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.rememberCoroutineScope
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.ImageBitmap
import androidx.compose.ui.graphics.asImageBitmap
import androidx.compose.ui.graphics.drawscope.drawIntoCanvas
import androidx.compose.ui.graphics.nativeCanvas
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.platform.LocalLayoutDirection
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.LayoutDirection
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.imgvec.core.TemplateData
import com.kyant.backdrop.Backdrop
import com.kyant.backdrop.backdrops.layerBackdrop
import com.kyant.backdrop.backdrops.rememberLayerBackdrop
import com.kyant.backdrop.catalog.components.LiquidButton
import com.kyant.backdrop.catalog.components.LiquidDialog
import com.kyant.backdrop.catalog.components.LiquidSlider
import com.kyant.backdrop.catalog.components.LiquidToggle
import com.kyant.backdrop.drawBackdrop
import com.kyant.backdrop.effects.blur
import com.kyant.backdrop.effects.vibrancy
import kotlinx.coroutines.CancellationException
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.delay
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext
import kotlin.math.min
import kotlin.math.roundToInt

class MainActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        enableEdgeToEdge()
        setContent {
            MaterialTheme(colorScheme = lightColorScheme()) {
                CompositionLocalProvider(LocalLayoutDirection provides LayoutDirection.Rtl) {
                    AppScreen()
                }
            }
        }
    }
}

private val TextWhite = Color.White
private val TextDim = Color.White.copy(alpha = 0.72f)

@Composable
private fun AppScreen() {
    val ctx = LocalContext.current
    val scope = rememberCoroutineScope()
    val backdrop = rememberLayerBackdrop()
    val store = remember { TemplateStore(ctx.applicationContext) }

    var template by remember { mutableStateOf<TemplateData?>(null) }
    var templateCustom by remember { mutableStateOf(false) }
    var loaded by remember { mutableStateOf<LoadedImage?>(null) }
    var original by remember { mutableStateOf<ImageBitmap?>(null) }
    var converted by remember { mutableStateOf<Converted?>(null) }
    var busy by remember { mutableStateOf(false) }
    var progress by remember { mutableFloatStateOf(0f) }
    var detail by remember { mutableFloatStateOf(0.45f) }
    var colors by remember { mutableFloatStateOf(32f) }
    var keepTint by remember { mutableStateOf(false) }
    var asText by remember { mutableStateOf(false) }
    var dialogVisible by remember { mutableStateOf(false) }
    var dialogTitle by remember { mutableStateOf("") }
    var dialogMessage by remember { mutableStateOf("") }
    var pendingSave by remember { mutableStateOf<(() -> Unit)?>(null) }

    fun say(title: String, message: String) {
        dialogTitle = title; dialogMessage = message; dialogVisible = true
    }

    // ---- load the template once
    LaunchedEffect(Unit) {
        try {
            val t = withContext(Dispatchers.IO) { store.load() }
            template = t
            templateCustom = store.isCustom
        } catch (t: Throwable) {
            say("تعذر تحميل القالب", t.message ?: "خطأ غير معروف")
        }
    }

    // ---- automatic (debounced) conversion whenever the picture or a setting changes
    LaunchedEffect(loaded, template, detail, colors, keepTint, asText) {
        val img = loaded ?: return@LaunchedEffect
        val tpl = template ?: return@LaunchedEffect
        delay(450)
        busy = true
        progress = 0f
        try {
            val res = Pipeline.run(
                img.pixels, img.width, img.height,
                maxDim = (96 + (400 - 96) * detail).roundToInt(),
                colors = colors.roundToInt(),
                keepTint = keepTint, forceText = asText,
                template = tpl,
                onProgress = { progress = it }
            )
            converted = res
        } catch (e: CancellationException) {
            throw e
        } catch (t: Throwable) {
            converted = null
            val msg = if (t is IllegalArgumentException) "الصورة غير صالحة للتحويل (قد تكون شفافة بالكامل)."
            else "حصلت مشكلة أثناء التحويل: ${t.message}"
            say("تعذر التحويل", msg)
        } finally {
            busy = false
        }
    }

    // ---- pickers
    val pickImage = rememberLauncherForActivityResult(ActivityResultContracts.GetContent()) { uri: Uri? ->
        if (uri == null) return@rememberLauncherForActivityResult
        scope.launch {
            busy = true
            try {
                val img = withContext(Dispatchers.IO) { ImageLoader.load(ctx, uri) }
                original = img.preview.asImageBitmap()
                converted = null
                loaded = img
            } catch (t: Throwable) {
                busy = false
                say("تعذر فتح الصورة", t.message ?: "خطأ غير معروف")
            }
        }
    }

    val pickTemplate = rememberLauncherForActivityResult(ActivityResultContracts.GetContent()) { uri: Uri? ->
        if (uri == null) return@rememberLauncherForActivityResult
        scope.launch {
            try {
                val t = withContext(Dispatchers.IO) {
                    val bytes = TemplateStore.readBytes(ctx, uri)
                    store.saveCustom(bytes, TemplateStore.displayName(ctx, uri))
                }
                template = t
                templateCustom = true
                say("تم", "اعتمدت الملف «${t.name}» كقالب (${if (t.binary) "ثنائي مستخرج من تطبيق" else "نصي"}).")
            } catch (t: Throwable) {
                say("ملف القالب غير صالح", "لازم يكون ملف Drawable vector XML (مضغوط من APK أو نصي). ${t.message ?: ""}")
            }
        }
    }

    // ---- actions
    fun doSave() {
        val out = converted?.output ?: return
        scope.launch {
            try {
                val where = withContext(Dispatchers.IO) { FileSaver.save(ctx, out.fileName, out.fileBytes) }
                say("تم التنزيل ✓", "انحفظ الملف في:\n$where\n\nتم التحقق منه بعد الحفظ (${out.fileBytes.size / 1024 + 1} KB).")
            } catch (t: Throwable) {
                say("تعذر التنزيل", t.message ?: "خطأ غير معروف")
            }
        }
    }

    val permission = rememberLauncherForActivityResult(ActivityResultContracts.RequestPermission()) { granted ->
        if (granted) pendingSave?.invoke() else say("الصلاحية مرفوضة", "لازم تسمح بالتخزين حتى ينحفظ الملف في التنزيلات.")
        pendingSave = null
    }

    fun download() {
        if (converted == null) { say("ماكو ملف", "اختار صورة أول."); return }
        if (FileSaver.needsLegacyPermission() &&
            ctx.checkSelfPermission(Manifest.permission.WRITE_EXTERNAL_STORAGE) != PackageManager.PERMISSION_GRANTED
        ) {
            pendingSave = { doSave() }
            permission.launch(Manifest.permission.WRITE_EXTERNAL_STORAGE)
        } else doSave()
    }

    fun copy() {
        val out = converted?.output
        if (out == null) { say("ماكو كود", "اختار صورة أول."); return }
        try {
            val cm = ctx.getSystemService(Context.CLIPBOARD_SERVICE) as ClipboardManager
            cm.setPrimaryClip(ClipData.newPlainText("vector.xml", out.text))
            Toast.makeText(ctx, "تم نسخ الكود", Toast.LENGTH_SHORT).show()
        } catch (t: Throwable) {
            say("تعذر النسخ", "الكود كبير على الحافظة. استعمل زر التنزيل بدلها.")
        }
    }

    // ---- UI
    Box(Modifier.fillMaxSize()) {
        Wallpaper(Modifier.fillMaxSize().layerBackdrop(backdrop))

        Column(
            Modifier
                .fillMaxSize()
                .statusBarsPadding()
                .navigationBarsPadding()
                .verticalScroll(rememberScrollState())
                .padding(horizontal = 16.dp, vertical = 12.dp),
            verticalArrangement = Arrangement.spacedBy(14.dp)
        ) {
            Text(
                "محوّل الصور إلى Vector",
                color = TextWhite, fontSize = 26.sp, fontWeight = FontWeight.Bold,
                modifier = Modifier.fillMaxWidth(), textAlign = TextAlign.Center
            )

            GlassPanel(backdrop) {
                Row(horizontalArrangement = Arrangement.spacedBy(12.dp), modifier = Modifier.fillMaxWidth()) {
                    PreviewBox(Modifier.weight(1f), "الأصل") {
                        val o = original
                        if (o != null) Image(o, null, Modifier.fillMaxSize(), contentScale = ContentScale.Fit)
                        else Hint("ماكو صورة")
                    }
                    PreviewBox(Modifier.weight(1f), "Vector") {
                        val c = converted
                        if (c != null) VectorPreview(c, Modifier.fillMaxSize())
                        else Hint(if (busy) "…" else "—")
                    }
                }
                if (busy) {
                    Text("جاري المعالجة… ${(progress * 100).roundToInt()}%", color = TextDim, fontSize = 13.sp,
                        modifier = Modifier.fillMaxWidth(), textAlign = TextAlign.Center)
                } else {
                    val c = converted
                    if (c != null) {
                        val kb = c.output.fileBytes.size / 1024 + 1
                        Text(
                            "الطبقات: ${c.output.model.layers.size}  •  الحجم: $kb KB  •  التحقق: ✓ ناجح" +
                                    if (c.output.overBudget) "\nملاحظة: الملف كبير، قلل التفاصيل إذا تريده أخف." else "",
                            color = TextDim, fontSize = 13.sp,
                            modifier = Modifier.fillMaxWidth(), textAlign = TextAlign.Center
                        )
                    }
                }
                LiquidButton(onClick = { pickImage.launch("image/*") }, backdrop = backdrop, modifier = Modifier.fillMaxWidth()) {
                    Text("اختيار صورة", color = TextWhite, fontWeight = FontWeight.SemiBold)
                }
            }

            GlassPanel(backdrop) {
                Text("التفاصيل", color = TextWhite, fontWeight = FontWeight.SemiBold)
                LtrBox { LiquidSlider(value = { detail }, onValueChange = { detail = it }, valueRange = 0f..1f,
                    visibilityThreshold = 0.001f, backdrop = backdrop, dark = true, modifier = Modifier.fillMaxWidth()) }
                Text("عدد الألوان: ${colors.roundToInt()}", color = TextWhite, fontWeight = FontWeight.SemiBold)
                LtrBox { LiquidSlider(value = { colors }, onValueChange = { colors = it }, valueRange = 4f..64f,
                    visibilityThreshold = 0.01f, backdrop = backdrop, dark = true, modifier = Modifier.fillMaxWidth()) }
                Text("تفاصيل أعلى وألوان أكثر = شكل أدق (خصوصاً الوجوه) لكن حجم ملف أكبر.", color = TextDim, fontSize = 12.sp)
            }

            GlassPanel(backdrop) {
                val t = template
                Text("ملف القالب", color = TextWhite, fontWeight = FontWeight.SemiBold)
                Text(
                    if (t == null) "جاري التحميل…"
                    else "${t.name}  •  ${if (t.binary) "ثنائي (مستخرج من تطبيق)" else "نصي"}  •  ${if (templateCustom) "ملفك" else "الافتراضي"}",
                    color = TextDim, fontSize = 13.sp
                )
                Text("الكود الجديد يستبدل محتوى هذا الملف وينحفظ بنفس اسمه.", color = TextDim, fontSize = 12.sp)
                Row(horizontalArrangement = Arrangement.spacedBy(10.dp), modifier = Modifier.fillMaxWidth()) {
                    LiquidButton(onClick = { pickTemplate.launch("*/*") }, backdrop = backdrop, modifier = Modifier.weight(1f)) {
                        Text("اختيار قالب", color = TextWhite, fontSize = 14.sp)
                    }
                    if (templateCustom) {
                        LiquidButton(onClick = {
                            scope.launch {
                                try {
                                    withContext(Dispatchers.IO) { store.reset() }
                                    template = withContext(Dispatchers.IO) { store.load() }
                                    templateCustom = false
                                } catch (t: Throwable) { say("خطأ", t.message ?: "") }
                            }
                        }, backdrop = backdrop, modifier = Modifier.weight(1f)) {
                            Text("الافتراضي", color = TextWhite, fontSize = 14.sp)
                        }
                    }
                }
                ToggleRow("الاحتفاظ بـ tint من القالب", keepTint, backdrop) { keepTint = it }
                ToggleRow("ملف نصي عادي (Android Studio)", asText, backdrop) { asText = it }
            }

            Row(horizontalArrangement = Arrangement.spacedBy(10.dp), modifier = Modifier.fillMaxWidth()) {
                LiquidButton(onClick = { copy() }, backdrop = backdrop, tint = Color(0xFF0088FF), modifier = Modifier.weight(1f)) {
                    Text("نسخ الكود", color = TextWhite, fontWeight = FontWeight.SemiBold)
                }
                LiquidButton(onClick = { download() }, backdrop = backdrop, tint = Color(0xFF34C759), modifier = Modifier.weight(1f)) {
                    Text("تنزيل XML", color = TextWhite, fontWeight = FontWeight.SemiBold)
                }
            }
        }

        LiquidDialog(
            visible = dialogVisible,
            onDismiss = { dialogVisible = false },
            backdrop = backdrop,
            dark = true,
            title = dialogTitle,
            message = dialogMessage,
            confirmText = "حسناً",
            dismissText = "إغلاق",
            onConfirm = { dialogVisible = false }
        )
    }
}

// ------------------------------------------------------------------------------------------ widgets
@Composable
private fun GlassPanel(backdrop: Backdrop, content: @Composable ColumnScope.() -> Unit) {
    Column(
        Modifier
            .fillMaxWidth()
            .drawBackdrop(
                backdrop = backdrop,
                shape = { RoundedCornerShape(28.dp) },
                effects = {
                    vibrancy()
                    blur(10f.dp.toPx())
                },
                onDrawSurface = { drawRect(Color.White.copy(alpha = 0.14f)) }
            )
            .padding(16.dp),
        verticalArrangement = Arrangement.spacedBy(12.dp),
        content = content
    )
}

@Composable
private fun LtrBox(content: @Composable () -> Unit) {
    CompositionLocalProvider(LocalLayoutDirection provides LayoutDirection.Ltr) {
        Box(Modifier.fillMaxWidth().padding(vertical = 4.dp)) { content() }
    }
}

@Composable
private fun ToggleRow(label: String, value: Boolean, backdrop: Backdrop, onChange: (Boolean) -> Unit) {
    Row(Modifier.fillMaxWidth(), verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.SpaceBetween) {
        Text(label, color = TextWhite, fontSize = 14.sp, modifier = Modifier.weight(1f))
        CompositionLocalProvider(LocalLayoutDirection provides LayoutDirection.Ltr) {
            LiquidToggle(selected = { value }, onSelect = onChange, backdrop = backdrop, dark = true)
        }
    }
}

@Composable
private fun PreviewBox(modifier: Modifier, label: String, content: @Composable () -> Unit) {
    Column(modifier, verticalArrangement = Arrangement.spacedBy(6.dp), horizontalAlignment = Alignment.CenterHorizontally) {
        Box(
            Modifier
                .fillMaxWidth()
                .aspectRatio(1f)
                .clip(RoundedCornerShape(18.dp))
                .background(Color.White.copy(alpha = 0.92f)),
            contentAlignment = Alignment.Center
        ) { content() }
        Text(label, color = TextDim, fontSize = 12.sp)
    }
}

@Composable
private fun Hint(text: String) {
    Text(text, color = Color(0xFF666666), fontSize = 14.sp)
}

@Composable
private fun VectorPreview(conv: Converted, modifier: Modifier) {
    val paint = remember {
        android.graphics.Paint(android.graphics.Paint.ANTI_ALIAS_FLAG).apply { style = android.graphics.Paint.Style.FILL }
    }
    Canvas(modifier) {
        val vw = conv.output.model.width.toFloat()
        val vh = conv.output.model.height.toFloat()
        if (vw <= 0f || vh <= 0f) return@Canvas
        val s = min(size.width / vw, size.height / vh)
        val dx = (size.width - vw * s) / 2f
        val dy = (size.height - vh * s) / 2f
        drawIntoCanvas { c ->
            val nc = c.nativeCanvas
            nc.save()
            nc.translate(dx, dy)
            nc.scale(s, s)
            for ((color, path) in conv.paths) {
                paint.color = color
                nc.drawPath(path, paint)
            }
            nc.restore()
        }
    }
}

@Composable
private fun Wallpaper(modifier: Modifier) {
    val t = rememberInfiniteTransition(label = "wallpaper")
    val a by t.animateFloat(
        initialValue = 0f, targetValue = 1f,
        animationSpec = infiniteRepeatable(tween(16000, easing = LinearEasing), RepeatMode.Reverse),
        label = "wp"
    )
    Canvas(modifier.background(Brush.verticalGradient(listOf(Color(0xFF0B1026), Color(0xFF1B1245), Color(0xFF083A58))))) {
        val w = size.width
        val h = size.height
        val r = maxOf(w, h) * 0.55f
        drawCircle(
            Brush.radialGradient(listOf(Color(0xFF7C4DFF), Color.Transparent), Offset(w * (0.2f + 0.5f * a), h * 0.18f), r),
            r, Offset(w * (0.2f + 0.5f * a), h * 0.18f)
        )
        drawCircle(
            Brush.radialGradient(listOf(Color(0xFF00BCD4), Color.Transparent), Offset(w * (0.9f - 0.6f * a), h * 0.55f), r),
            r, Offset(w * (0.9f - 0.6f * a), h * 0.55f)
        )
        drawCircle(
            Brush.radialGradient(listOf(Color(0xFFFF4081), Color.Transparent), Offset(w * (0.3f + 0.3f * a), h * 0.92f), r * 0.9f),
            r * 0.9f, Offset(w * (0.3f + 0.3f * a), h * 0.92f)
        )
    }
}
