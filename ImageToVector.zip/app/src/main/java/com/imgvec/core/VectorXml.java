package com.imgvec.core;

import java.io.ByteArrayInputStream;
import java.nio.charset.Charset;
import java.util.ArrayList;
import java.util.List;
import java.util.Locale;
import java.util.regex.Matcher;
import java.util.regex.Pattern;

/** Text-XML side: template patching, generation and verification. */
public final class VectorXml {
    private VectorXml() {}

    public static final String ANDROID_URI = "http://schemas.android.com/apk/res/android";
    private static final Charset UTF8 = Charset.forName("UTF-8");

    /** A dimension such as 24dp. unit uses TypedValue unit codes. */
    public static final class Dim {
        public final float value;
        public final int unit;
        public Dim(float value, int unit) { this.value = value; this.unit = unit; }
    }

    private static final String[] UNIT_NAMES = {"px", "dp", "sp", "pt", "in", "mm"};

    public static String unitName(int u) { return u >= 0 && u < UNIT_NAMES.length ? UNIT_NAMES[u] : "dp"; }

    public static Dim parseDim(String s) {
        if (s == null) return null;
        Matcher m = Pattern.compile("^\\s*(-?[0-9]*\\.?[0-9]+)\\s*(px|dp|dip|sp|pt|in|mm)\\s*$").matcher(s);
        if (!m.matches()) return null;
        String u = m.group(2);
        int unit = 1;
        if (u.equals("px")) unit = 0; else if (u.equals("sp")) unit = 2; else if (u.equals("pt")) unit = 3;
        else if (u.equals("in")) unit = 4; else if (u.equals("mm")) unit = 5;
        try { return new Dim(Float.parseFloat(m.group(1)), unit); } catch (NumberFormatException e) { return null; }
    }

    /** Final width/height keeping the template's larger side and the image aspect ratio. */
    public static Dim[] fitSize(Dim w, Dim h, int vw, int vh) {
        float base; int unit;
        if (w != null && h != null) {
            if (w.unit == h.unit) { base = Math.max(w.value, h.value); unit = w.unit; }
            else { base = w.value; unit = w.unit; }
        } else if (w != null) { base = w.value; unit = w.unit; }
        else if (h != null) { base = h.value; unit = h.unit; }
        else { base = 24f; unit = 1; }
        if (!(base > 0)) { base = 24f; unit = 1; }
        float fw, fh;
        if (vw >= vh) { fw = base; fh = base * vh / vw; } else { fh = base; fw = base * vw / vh; }
        return new Dim[]{new Dim(fw, unit), new Dim(fh, unit)};
    }

    public static String fmtDim(Dim d) {
        float v = Math.round(d.value * 100f) / 100f;
        String s = (v == Math.rint(v)) ? Long.toString((long) v) : String.format(Locale.US, "%.2f", v);
        if (s.contains(".")) { s = s.replaceAll("0+$", ""); if (s.endsWith(".")) s = s.substring(0, s.length() - 1); }
        return s + unitName(d.unit);
    }

    // ------------------------------------------------------------------------------ template (text)
    private static final Pattern ROOT = Pattern.compile("<vector\\b([^>]*)>", Pattern.DOTALL);
    private static final Pattern ATTR = Pattern.compile("([A-Za-z_][\\w.:-]*)\\s*=\\s*(\"([^\"]*)\"|'([^']*)')");

    /** Ordered (name, rawValue) pairs of the root &lt;vector&gt; tag. */
    public static List<String[]> readRootAttrs(String xml) {
        Matcher m = ROOT.matcher(xml);
        if (!m.find()) throw new IllegalArgumentException("no <vector> root in template");
        List<String[]> out = new ArrayList<String[]>();
        Matcher a = ATTR.matcher(m.group(1));
        while (a.find()) out.add(new String[]{a.group(1), a.group(3) != null ? a.group(3) : a.group(4)});
        return out;
    }

    /** Builds the text XML. {@code templateAttrs} may be null (plain AndroidStudio-style output). */
    public static String buildText(VectorEngine.Result r, List<String[]> templateAttrs, boolean keepTint) {
        Dim tw = null, th = null;
        List<String[]> extra = new ArrayList<String[]>();
        if (templateAttrs != null) {
            for (String[] a : templateAttrs) {
                String n = a[0];
                if (n.equals("android:width")) tw = parseDim(a[1]);
                else if (n.equals("android:height")) th = parseDim(a[1]);
                else if (n.equals("android:viewportWidth") || n.equals("android:viewportHeight")) continue;
                else if (n.equals("xmlns:android")) continue;
                else if (n.equals("android:tint") && !keepTint) continue;
                else extra.add(a);
            }
        }
        Dim[] sz = fitSize(tw, th, r.width, r.height);
        StringBuilder sb = new StringBuilder(r.totalChars + 512);
        sb.append("<?xml version=\"1.0\" encoding=\"utf-8\"?>\n");
        sb.append("<vector xmlns:android=\"").append(ANDROID_URI).append("\"\n");
        sb.append("    android:width=\"").append(fmtDim(sz[0])).append("\"\n");
        sb.append("    android:height=\"").append(fmtDim(sz[1])).append("\"\n");
        for (String[] a : extra) sb.append("    ").append(a[0]).append("=\"").append(a[1]).append("\"\n");
        sb.append("    android:viewportWidth=\"").append(r.width).append("\"\n");
        sb.append("    android:viewportHeight=\"").append(r.height).append("\">\n");
        for (VectorEngine.Layer l : r.layers) {
            sb.append("  <path\n      android:fillColor=\"#")
              .append(String.format(Locale.US, "%08X", l.color)).append("\"\n")
              .append("      android:pathData=\"").append(l.pathData).append("\"/>\n");
        }
        sb.append("</vector>\n");
        return sb.toString();
    }

    /** Returns null if the XML is well formed and matches the model, else a problem description. */
    public static String verifyText(String xml, VectorEngine.Result r) {
        try {
            javax.xml.parsers.DocumentBuilderFactory f = javax.xml.parsers.DocumentBuilderFactory.newInstance();
            f.setNamespaceAware(true);
            org.w3c.dom.Document doc = f.newDocumentBuilder().parse(new ByteArrayInputStream(xml.getBytes(UTF8)));
            org.w3c.dom.Element root = doc.getDocumentElement();
            if (!"vector".equals(root.getLocalName() != null ? root.getLocalName() : root.getNodeName()))
                return "root is not vector";
            String vw = root.getAttributeNS(ANDROID_URI, "viewportWidth");
            String vh = root.getAttributeNS(ANDROID_URI, "viewportHeight");
            if (!String.valueOf(r.width).equals(vw) || !String.valueOf(r.height).equals(vh)) return "viewport mismatch";
            if (parseDim(root.getAttributeNS(ANDROID_URI, "width")) == null) return "bad width";
            if (parseDim(root.getAttributeNS(ANDROID_URI, "height")) == null) return "bad height";
            org.w3c.dom.NodeList nl = root.getElementsByTagName("path");
            if (nl.getLength() != r.layers.size()) return "path count mismatch";
            for (int i = 0; i < nl.getLength(); i++) {
                org.w3c.dom.Element p = (org.w3c.dom.Element) nl.item(i);
                String pd = p.getAttributeNS(ANDROID_URI, "pathData");
                if (!pd.equals(r.layers.get(i).pathData)) return "pathData mismatch at " + i;
                String fc = p.getAttributeNS(ANDROID_URI, "fillColor");
                if (!fc.equalsIgnoreCase(String.format(Locale.US, "#%08X", r.layers.get(i).color))) return "color mismatch";
            }
            return null;
        } catch (Throwable t) {
            return "xml parse failed: " + t;
        }
    }
}
