package com.imgvec.core;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;
import java.util.Locale;

/**
 * Raster -> layered vector converter. Pure Java (no Android / AWT) so it can be unit-tested anywhere.
 *
 * Pipeline: area downscale -> optional 3x3 median denoise -> median-cut + k-means palette ->
 * speckle removal -> stacked layer masks (biggest colour first) -> boundary tracing ->
 * Douglas-Peucker simplification -> rounded-corner quadratic path output.
 */
public final class VectorEngine {
    private VectorEngine() {}

    public static final class Options {
        public int maxDim = 256;
        public int colors = 32;
        public float tolerance = 0.85f;
        public int minArea = 4;
        public boolean denoise = true;
        public float corner = 2.0f;
    }

    public static final class Layer {
        public final int color;          // 0xFFRRGGBB
        public final String pathData;
        Layer(int color, String pathData) { this.color = color; this.pathData = pathData; }
    }

    public static final class Result {
        public final int width, height;
        public final List<Layer> layers;
        public final int totalChars;
        Result(int w, int h, List<Layer> l, int total) { width = w; height = h; layers = l; totalChars = total; }
    }

    public interface Progress { void onProgress(float fraction); }

    /** Converts ARGB pixels into a vector model. Throws IllegalArgumentException for unusable input. */
    public static Result convert(int[] argb, int w, int h, Options o, Progress progress) {
        if (argb == null || w <= 0 || h <= 0 || argb.length < (long) w * h)
            throw new IllegalArgumentException("invalid image");
        if (o == null) o = new Options();
        return run(argb, w, h, o, progress);
    }

    // ------------------------------------------------------------------------------------------
    private static Result run(int[] src, int sw, int sh, Options o, Progress pr) {
        report(pr, 0.02f);
        int maxDim = Math.max(16, Math.min(1024, o.maxDim));
        int nw = sw, nh = sh;
        int big = Math.max(sw, sh);
        if (big > maxDim) {
            double f = (double) maxDim / big;
            nw = Math.max(1, (int) Math.round(sw * f));
            nh = Math.max(1, (int) Math.round(sh * f));
        }
        final int w = nw, h = nh, n = w * h;
        int[] r = new int[n], g = new int[n], b = new int[n];
        boolean[] opaque = new boolean[n];
        downscale(src, sw, sh, w, h, r, g, b, opaque);
        boolean any = false;
        for (int i = 0; i < n; i++) if (opaque[i]) { any = true; break; }
        if (!any) throw new IllegalArgumentException("image is fully transparent");
        report(pr, 0.10f);

        if (o.denoise && w >= 3 && h >= 3) {
            r = median3(r, opaque, w, h);
            g = median3(g, opaque, w, h);
            b = median3(b, opaque, w, h);
        }
        report(pr, 0.18f);

        int[] pal = quantize(r, g, b, opaque, Math.max(2, Math.min(96, o.colors)));
        int[] idx = new int[n];
        mapToPalette(r, g, b, opaque, pal, idx);
        report(pr, 0.30f);

        removeSpeckles(idx, w, h, Math.max(1, o.minArea));
        removeSpeckles(idx, w, h, Math.max(1, o.minArea));
        report(pr, 0.38f);

        // area per palette entry, drawn biggest first
        int[] area = new int[pal.length];
        for (int i = 0; i < n; i++) if (idx[i] >= 0) area[idx[i]]++;
        Integer[] order = new Integer[pal.length];
        for (int i = 0; i < order.length; i++) order[i] = i;
        final int[] fa = area;
        Arrays.sort(order, (x, y) -> fa[y] != fa[x] ? Integer.compare(fa[y], fa[x]) : Integer.compare(x, y));
        int layersCount = 0;
        for (int i = 0; i < order.length; i++) if (area[order[i]] > 0) layersCount++;
        int[] rank = new int[pal.length];
        Arrays.fill(rank, -1);
        int k = 0;
        for (int i = 0; i < order.length; i++) if (area[order[i]] > 0) rank[order[i]] = k++;
        int[] rg = new int[n];
        for (int i = 0; i < n; i++) rg[i] = idx[i] < 0 ? -1 : rank[idx[i]];

        List<Layer> layers = new ArrayList<Layer>();
        int total = 0;
        boolean[] mask = new boolean[n];
        byte[] edges = new byte[(w + 1) * (h + 1)];
        for (int L = 0; L < layersCount; L++) {
            for (int i = 0; i < n; i++) mask[i] = rg[i] >= L;
            String d = tracePath(mask, w, h, edges, o);
            int col = 0;
            for (int p = 0; p < pal.length; p++) if (rank[p] == L) { col = pal[p]; break; }
            if (d.length() > 0) {
                layers.add(new Layer(0xFF000000 | col, d));
                total += d.length();
            }
            report(pr, 0.38f + 0.60f * (L + 1) / Math.max(1, layersCount));
        }
        if (layers.isEmpty()) throw new IllegalArgumentException("nothing to draw");
        report(pr, 1f);
        return new Result(w, h, layers, total);
    }

    private static void report(Progress p, float f) {
        if (p != null) { try { p.onProgress(f); } catch (RuntimeException ignored) { } }
    }

    // ---- scaling ----------------------------------------------------------------------------
    private static void downscale(int[] s, int sw, int sh, int w, int h,
                                  int[] r, int[] g, int[] b, boolean[] op) {
        for (int y = 0; y < h; y++) {
            int y0 = (int) ((long) y * sh / h);
            int y1 = Math.max(y0 + 1, (int) ((long) (y + 1) * sh / h));
            for (int x = 0; x < w; x++) {
                int x0 = (int) ((long) x * sw / w);
                int x1 = Math.max(x0 + 1, (int) ((long) (x + 1) * sw / w));
                long sa = 0, sr = 0, sg = 0, sb = 0;
                int cnt = 0;
                for (int yy = y0; yy < y1 && yy < sh; yy++) {
                    for (int xx = x0; xx < x1 && xx < sw; xx++) {
                        int p = s[yy * sw + xx];
                        int a = p >>> 24;
                        cnt++;
                        sa += a;
                        sr += (long) ((p >> 16) & 255) * a;
                        sg += (long) ((p >> 8) & 255) * a;
                        sb += (long) (p & 255) * a;
                    }
                }
                int i = y * w + x;
                if (cnt == 0 || sa == 0) { op[i] = false; continue; }
                double avgA = (double) sa / cnt;
                if (avgA < 128.0) { op[i] = false; continue; }
                op[i] = true;
                r[i] = (int) (sr / sa);
                g[i] = (int) (sg / sa);
                b[i] = (int) (sb / sa);
            }
        }
    }

    private static int[] median3(int[] c, boolean[] op, int w, int h) {
        int[] out = c.clone();
        int[] v = new int[9];
        for (int y = 0; y < h; y++) {
            for (int x = 0; x < w; x++) {
                int i = y * w + x;
                if (!op[i]) continue;
                int m = 0;
                for (int dy = -1; dy <= 1; dy++) {
                    int yy = y + dy;
                    if (yy < 0 || yy >= h) continue;
                    for (int dx = -1; dx <= 1; dx++) {
                        int xx = x + dx;
                        if (xx < 0 || xx >= w) continue;
                        int j = yy * w + xx;
                        if (!op[j]) continue;
                        int val = c[j];
                        int q = m++;
                        while (q > 0 && v[q - 1] > val) { v[q] = v[q - 1]; q--; }
                        v[q] = val;
                    }
                }
                out[i] = v[m / 2];
            }
        }
        return out;
    }

    // ---- quantisation -----------------------------------------------------------------------
    private static int[] quantize(int[] r, int[] g, int[] b, boolean[] op, int k) {
        final int BINS = 32768;
        int[] cnt = new int[BINS];
        long[] sr = new long[BINS], sg = new long[BINS], sb = new long[BINS];
        for (int i = 0; i < r.length; i++) {
            if (!op[i]) continue;
            int bin = ((r[i] >> 3) << 10) | ((g[i] >> 3) << 5) | (b[i] >> 3);
            cnt[bin]++;
            sr[bin] += r[i]; sg[bin] += g[i]; sb[bin] += b[i];
        }
        int used = 0;
        for (int i = 0; i < BINS; i++) if (cnt[i] > 0) used++;
        int[] bins = new int[used];
        int[] mr = new int[used], mg = new int[used], mb = new int[used], mc = new int[used];
        int q = 0;
        for (int i = 0; i < BINS; i++) {
            if (cnt[i] == 0) continue;
            bins[q] = i;
            mc[q] = cnt[i];
            mr[q] = (int) (sr[i] / cnt[i]);
            mg[q] = (int) (sg[i] / cnt[i]);
            mb[q] = (int) (sb[i] / cnt[i]);
            q++;
        }
        // median cut over distinct bin colours
        List<int[]> boxes = new ArrayList<int[]>(); // each: array of entry indices
        int[] all = new int[used];
        for (int i = 0; i < used; i++) all[i] = i;
        boxes.add(all);
        while (boxes.size() < k) {
            int best = -1;
            double bestScore = 0;
            int bestCh = 0;
            for (int bi = 0; bi < boxes.size(); bi++) {
                int[] bx = boxes.get(bi);
                if (bx.length < 2) continue;
                int rmin = 255, rmax = 0, gmin = 255, gmax = 0, bmin = 255, bmax = 0;
                long pop = 0;
                for (int e : bx) {
                    rmin = Math.min(rmin, mr[e]); rmax = Math.max(rmax, mr[e]);
                    gmin = Math.min(gmin, mg[e]); gmax = Math.max(gmax, mg[e]);
                    bmin = Math.min(bmin, mb[e]); bmax = Math.max(bmax, mb[e]);
                    pop += mc[e];
                }
                double dr = (rmax - rmin) * 0.9, dg = (gmax - gmin) * 1.2, db = (bmax - bmin) * 0.7;
                double rng = Math.max(dr, Math.max(dg, db));
                if (rng <= 0) continue;
                double score = rng * Math.sqrt((double) pop);
                if (score > bestScore) {
                    bestScore = score; best = bi;
                    bestCh = (dg >= dr && dg >= db) ? 1 : (dr >= db ? 0 : 2);
                }
            }
            if (best < 0) break;
            int[] bx = boxes.get(best);
            final int ch = bestCh;
            final int[] fr = mr, fg = mg, fb = mb;
            Integer[] sorted = new Integer[bx.length];
            for (int i = 0; i < bx.length; i++) sorted[i] = bx[i];
            Arrays.sort(sorted, (a, c) -> {
                int va = ch == 0 ? fr[a] : (ch == 1 ? fg[a] : fb[a]);
                int vc = ch == 0 ? fr[c] : (ch == 1 ? fg[c] : fb[c]);
                return va != vc ? Integer.compare(va, vc) : Integer.compare(a, c);
            });
            long pop = 0;
            for (int e : bx) pop += mc[e];
            long half = pop / 2, run = 0;
            int cut = 1;
            for (int i = 0; i < sorted.length; i++) {
                run += mc[sorted[i]];
                if (run >= half) { cut = i + 1; break; }
            }
            cut = Math.max(1, Math.min(sorted.length - 1, cut));
            int[] a1 = new int[cut], a2 = new int[sorted.length - cut];
            for (int i = 0; i < cut; i++) a1[i] = sorted[i];
            for (int i = cut; i < sorted.length; i++) a2[i - cut] = sorted[i];
            boxes.set(best, a1);
            boxes.add(a2);
        }
        int pk = boxes.size();
        double[] pr = new double[pk], pg = new double[pk], pb = new double[pk];
        for (int bi = 0; bi < pk; bi++) {
            double wr = 0, wg = 0, wb = 0, wt = 0;
            for (int e : boxes.get(bi)) {
                wr += (double) mr[e] * mc[e]; wg += (double) mg[e] * mc[e]; wb += (double) mb[e] * mc[e];
                wt += mc[e];
            }
            pr[bi] = wr / wt; pg[bi] = wg / wt; pb[bi] = wb / wt;
        }
        // k-means refinement on distinct colours (weighted)
        int[] assign = new int[used];
        for (int it = 0; it < 5; it++) {
            for (int e = 0; e < used; e++) {
                int bestP = 0;
                double bd = Double.MAX_VALUE;
                for (int p = 0; p < pk; p++) {
                    double d = dist(mr[e], mg[e], mb[e], pr[p], pg[p], pb[p]);
                    if (d < bd) { bd = d; bestP = p; }
                }
                assign[e] = bestP;
            }
            double[] ar = new double[pk], ag = new double[pk], ab = new double[pk], aw = new double[pk];
            for (int e = 0; e < used; e++) {
                int p = assign[e];
                ar[p] += (double) mr[e] * mc[e]; ag[p] += (double) mg[e] * mc[e]; ab[p] += (double) mb[e] * mc[e];
                aw[p] += mc[e];
            }
            for (int p = 0; p < pk; p++) {
                if (aw[p] > 0) { pr[p] = ar[p] / aw[p]; pg[p] = ag[p] / aw[p]; pb[p] = ab[p] / aw[p]; }
            }
        }
        // drop unused / duplicate entries
        List<Integer> out = new ArrayList<Integer>();
        boolean[] usedP = new boolean[pk];
        for (int e = 0; e < used; e++) usedP[assign[e]] = true;
        for (int p = 0; p < pk; p++) {
            if (!usedP[p]) continue;
            int c = (clamp((int) Math.round(pr[p])) << 16) | (clamp((int) Math.round(pg[p])) << 8) | clamp((int) Math.round(pb[p]));
            if (!out.contains(c)) out.add(c);
        }
        int[] pal = new int[out.size()];
        for (int i = 0; i < pal.length; i++) pal[i] = out.get(i);
        return pal;
    }

    private static int clamp(int v) { return v < 0 ? 0 : Math.min(255, v); }

    private static double dist(double r1, double g1, double b1, double r2, double g2, double b2) {
        double rm = (r1 + r2) * 0.5;
        double dr = r1 - r2, dg = g1 - g2, db = b1 - b2;
        return (2.0 + rm / 256.0) * dr * dr + 4.0 * dg * dg + (2.0 + (255.0 - rm) / 256.0) * db * db;
    }

    private static void mapToPalette(int[] r, int[] g, int[] b, boolean[] op, int[] pal, int[] idx) {
        int[] cache = new int[32768];
        Arrays.fill(cache, -1);
        for (int i = 0; i < r.length; i++) {
            if (!op[i]) { idx[i] = -1; continue; }
            int bin = ((r[i] >> 3) << 10) | ((g[i] >> 3) << 5) | (b[i] >> 3);
            int c = cache[bin];
            if (c < 0) {
                double bd = Double.MAX_VALUE;
                c = 0;
                for (int p = 0; p < pal.length; p++) {
                    double d = dist(r[i], g[i], b[i], (pal[p] >> 16) & 255, (pal[p] >> 8) & 255, pal[p] & 255);
                    if (d < bd) { bd = d; c = p; }
                }
                cache[bin] = c;
            }
            idx[i] = c;
        }
    }

    // ---- speckle removal --------------------------------------------------------------------
    private static void removeSpeckles(int[] idx, int w, int h, int minArea) {
        int n = w * h;
        boolean[] seen = new boolean[n];
        int[] queue = new int[n];
        for (int s = 0; s < n; s++) {
            if (seen[s]) continue;
            int label = idx[s];
            int head = 0, tail = 0;
            queue[tail++] = s;
            seen[s] = true;
            while (head < tail) {
                int p = queue[head++];
                int x = p % w, y = p / w;
                if (x > 0 && !seen[p - 1] && idx[p - 1] == label) { seen[p - 1] = true; queue[tail++] = p - 1; }
                if (x < w - 1 && !seen[p + 1] && idx[p + 1] == label) { seen[p + 1] = true; queue[tail++] = p + 1; }
                if (y > 0 && !seen[p - w] && idx[p - w] == label) { seen[p - w] = true; queue[tail++] = p - w; }
                if (y < h - 1 && !seen[p + w] && idx[p + w] == label) { seen[p + w] = true; queue[tail++] = p + w; }
            }
            if (tail >= minArea) continue;
            // find most common neighbouring label
            int bestLabel = Integer.MIN_VALUE, bestCount = 0;
            int[] labs = new int[tail * 4];
            int ln = 0;
            for (int q = 0; q < tail; q++) {
                int p = queue[q];
                int x = p % w, y = p / w;
                if (x > 0 && idx[p - 1] != label) labs[ln++] = idx[p - 1];
                if (x < w - 1 && idx[p + 1] != label) labs[ln++] = idx[p + 1];
                if (y > 0 && idx[p - w] != label) labs[ln++] = idx[p - w];
                if (y < h - 1 && idx[p + w] != label) labs[ln++] = idx[p + w];
            }
            if (ln == 0) continue;
            Arrays.sort(labs, 0, ln);
            int run = 1;
            for (int i = 1; i <= ln; i++) {
                if (i < ln && labs[i] == labs[i - 1]) { run++; continue; }
                if (run > bestCount) { bestCount = run; bestLabel = labs[i - 1]; }
                run = 1;
            }
            for (int q = 0; q < tail; q++) idx[queue[q]] = bestLabel;
        }
    }

    // ---- tracing ----------------------------------------------------------------------------
    private static final int[] DX = {1, 0, -1, 0};   // R, D, L, U  (y grows downwards)
    private static final int[] DY = {0, 1, 0, -1};

    private static String tracePath(boolean[] m, int w, int h, byte[] edges, Options o) {
        Arrays.fill(edges, (byte) 0);
        int W1 = w + 1;
        for (int y = 0; y < h; y++) {
            for (int x = 0; x < w; x++) {
                if (!m[y * w + x]) continue;
                if (y == 0 || !m[(y - 1) * w + x]) edges[y * W1 + x] |= 1;            // R along top
                if (x == w - 1 || !m[y * w + x + 1]) edges[y * W1 + x + 1] |= 2;      // D along right
                if (y == h - 1 || !m[(y + 1) * w + x]) edges[(y + 1) * W1 + x + 1] |= 4; // L along bottom
                if (x == 0 || !m[y * w + x - 1]) edges[(y + 1) * W1 + x] |= 8;        // U along left
            }
        }
        StringBuilder sb = new StringBuilder();
        IntList pts = new IntList(256);
        for (int vy = 0; vy <= h; vy++) {
            for (int vx = 0; vx <= w; vx++) {
                while (edges[vy * W1 + vx] != 0) {
                    int bits = edges[vy * W1 + vx];
                    int d = 0;
                    while ((bits & (1 << d)) == 0) d++;
                    pts.clear();
                    int cx = vx, cy = vy, dir = d, prevDir = -1;
                    while (true) {
                        int cb = edges[cy * W1 + cx];
                        if ((cb & (1 << dir)) == 0) break;
                        edges[cy * W1 + cx] = (byte) (cb & ~(1 << dir));
                        if (dir != prevDir) { pts.add(cx); pts.add(cy); }
                        prevDir = dir;
                        cx += DX[dir]; cy += DY[dir];
                        int nb = edges[cy * W1 + cx];
                        int nd = (dir + 1) & 3;
                        if ((nb & (1 << nd)) == 0) {
                            nd = dir;
                            if ((nb & (1 << nd)) == 0) {
                                nd = (dir + 3) & 3;
                                if ((nb & (1 << nd)) == 0) break;
                            }
                        }
                        dir = nd;
                    }
                    emitLoop(sb, pts, w, h, o);
                }
            }
        }
        return sb.toString();
    }

    private static void emitLoop(StringBuilder sb, IntList pts, int w, int h, Options o) {
        int n = pts.size() / 2;
        if (n < 3) return;
        double[] xs = new double[n], ys = new double[n];
        for (int i = 0; i < n; i++) { xs[i] = pts.get(2 * i); ys[i] = pts.get(2 * i + 1); }
        // remove collinear points
        double[] cx = new double[n], cy = new double[n];
        int m = 0;
        for (int i = 0; i < n; i++) {
            int p = (i + n - 1) % n, q = (i + 1) % n;
            double cr = (xs[i] - xs[p]) * (ys[q] - ys[i]) - (ys[i] - ys[p]) * (xs[q] - xs[i]);
            if (cr != 0) { cx[m] = xs[i]; cy[m] = ys[i]; m++; }
        }
        if (m < 3) return;
        double area = 0;
        for (int i = 0; i < m; i++) { int j = (i + 1) % m; area += cx[i] * cy[j] - cx[j] * cy[i]; }
        if (Math.abs(area) < 1.0) return;

        double[] px, py;
        int pm;
        if (m <= 4) {
            px = Arrays.copyOf(cx, m); py = Arrays.copyOf(cy, m); pm = m;
        } else {
            boolean[] keep = new boolean[m];
            int far = 0;
            double fd = -1;
            for (int i = 1; i < m; i++) {
                double d = (cx[i] - cx[0]) * (cx[i] - cx[0]) + (cy[i] - cy[0]) * (cy[i] - cy[0]);
                if (d > fd) { fd = d; far = i; }
            }
            keep[0] = true; keep[far] = true;
            rdp(cx, cy, 0, far, o.tolerance, keep);
            rdpWrap(cx, cy, far, m, o.tolerance, keep);
            px = new double[m]; py = new double[m]; pm = 0;
            for (int i = 0; i < m; i++) if (keep[i]) { px[pm] = cx[i]; py[pm] = cy[i]; pm++; }
            if (pm < 3) {
                px = Arrays.copyOf(cx, m); py = Arrays.copyOf(cy, m); pm = m;
            }
        }
        writeSmooth(sb, px, py, pm, w, h, o.corner);
    }

    private static void rdp(double[] x, double[] y, int a, int b, double tol, boolean[] keep) {
        if (b - a < 2) return;
        double best = -1;
        int bi = -1;
        for (int i = a + 1; i < b; i++) {
            double d = segDist(x[i], y[i], x[a], y[a], x[b], y[b]);
            if (d > best) { best = d; bi = i; }
        }
        if (best > tol) {
            keep[bi] = true;
            rdp(x, y, a, bi, tol, keep);
            rdp(x, y, bi, b, tol, keep);
        }
    }

    /** Second half of a closed ring: indices far..m-1 then back to 0. */
    private static void rdpWrap(double[] x, double[] y, int a, int m, double tol, boolean[] keep) {
        int len = m - a + 1;
        double[] tx = new double[len], ty = new double[len];
        for (int i = 0; i < len; i++) { int j = (a + i) % m; tx[i] = x[j]; ty[i] = y[j]; }
        boolean[] k2 = new boolean[len];
        k2[0] = true; k2[len - 1] = true;
        rdp(tx, ty, 0, len - 1, tol, k2);
        for (int i = 0; i < len; i++) if (k2[i]) keep[(a + i) % m] = true;
    }

    private static double segDist(double px, double py, double ax, double ay, double bx, double by) {
        double dx = bx - ax, dy = by - ay;
        double l2 = dx * dx + dy * dy;
        if (l2 == 0) return Math.hypot(px - ax, py - ay);
        double t = ((px - ax) * dx + (py - ay) * dy) / l2;
        t = t < 0 ? 0 : (t > 1 ? 1 : t);
        return Math.hypot(px - (ax + t * dx), py - (ay + t * dy));
    }

    private static void writeSmooth(StringBuilder sb, double[] x, double[] y, int n, int w, int h, double R) {
        // per vertex: start point (on incoming edge) and end point (on outgoing edge)
        double[] sx = new double[n], sy = new double[n], ex = new double[n], ey = new double[n];
        boolean[] round = new boolean[n];
        for (int i = 0; i < n; i++) {
            int p = (i + n - 1) % n, q = (i + 1) % n;
            double ax = x[i] - x[p], ay = y[i] - y[p];
            double bx = x[q] - x[i], by = y[q] - y[i];
            double la = Math.hypot(ax, ay), lb = Math.hypot(bx, by);
            boolean border = x[i] <= 0 || x[i] >= w || y[i] <= 0 || y[i] >= h;
            if (border || la == 0 || lb == 0) {
                sx[i] = ex[i] = x[i]; sy[i] = ey[i] = y[i];
                continue;
            }
            round[i] = true;
            double ra = Math.min(la / 2.0, R), rb = Math.min(lb / 2.0, R);
            sx[i] = x[i] - ax / la * ra; sy[i] = y[i] - ay / la * ra;
            ex[i] = x[i] + bx / lb * rb; ey[i] = y[i] + by / lb * rb;
        }
        // start at the end point of vertex 0
        appendCmd(sb, 'M', fmt(ex[0]), fmt(ey[0]));
        String lastX = fmt(ex[0]), lastY = fmt(ey[0]);
        for (int s = 1; s <= n; s++) {
            int i = s % n;
            String ssx = fmt(sx[i]), ssy = fmt(sy[i]);
            if (!(ssx.equals(lastX) && ssy.equals(lastY))) {
                appendCmd(sb, 'L', ssx, ssy);
            }
            if (round[i]) {
                String eex = fmt(ex[i]), eey = fmt(ey[i]);
                sb.append('Q').append(fmt(x[i])).append(',').append(fmt(y[i])).append(' ').append(eex).append(',').append(eey);
                lastX = eex; lastY = eey;
            } else {
                lastX = ssx; lastY = ssy;
            }
        }
        sb.append('Z');
    }

    private static void appendCmd(StringBuilder sb, char c, String a, String b) {
        sb.append(c).append(a).append(',').append(b);
    }

    static String fmt(double v) {
        double r = Math.round(v * 10.0) / 10.0;
        if (r == 0) return "0";
        if (r == Math.rint(r)) return Long.toString((long) r);
        return String.format(Locale.US, "%.1f", r);
    }

    // minimal growable int array
    private static final class IntList {
        private int[] a;
        private int n;
        IntList(int cap) { a = new int[cap]; }
        void add(int v) { if (n == a.length) a = Arrays.copyOf(a, n * 2); a[n++] = v; }
        int get(int i) { return a[i]; }
        int size() { return n; }
        void clear() { n = 0; }
    }
}
