package com.imgvec.core;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;
import java.util.Locale;

/**
 * Raster -> layered vector converter. Pure Java (no Android / AWT) so it can be unit-tested anywhere.
 *
 * Pipeline: area downscale (or bilinear upscale for small images) -> palette built from flat
 * (non anti-aliased) pixels only -> speckle removal -> stacked layer masks (biggest colour first) ->
 * sub-pixel contours (marching squares on a lightly blurred mask) -> corner detection ->
 * Schneider cubic Bezier fitting -> compact path output (L / C commands).
 */
public final class VectorEngine {
    private VectorEngine() {}

    public static final class Options {
        public int maxDim = 384;
        public int colors = 32;
        public float tolerance = 0.5f;   // max curve-fit error in pixels
        public int minArea = 4;
        public boolean denoise = false;   // a median filter erases thin lines, so it is off by default
        public float corner = 2.0f;       // (unused, kept for compatibility)
        public float cornerDeg = 55f;     // turning angle above which a vertex is kept sharp
    }

    public static final class Layer {
        public final int color;          // 0xFFRRGGBB
        public final String pathData;
        Layer(int color, String pathData) { this.color = color; this.pathData = pathData; }
    }

    public static final class Result {
        public final int width, height;
        public final List<Layer> layers;
        public final int totalChars;
        Result(int w, int h, List<Layer> l, int total) { width = w; height = h; layers = l; totalChars = total; }
    }

    public interface Progress { void onProgress(float fraction); }

    /** Converts ARGB pixels into a vector model. Throws IllegalArgumentException for unusable input. */
    public static Result convert(int[] argb, int w, int h, Options o, Progress progress) {
        if (argb == null || w <= 0 || h <= 0 || argb.length < (long) w * h)
            throw new IllegalArgumentException("invalid image");
        if (o == null) o = new Options();
        return run(argb, w, h, o, progress);
    }

    // ------------------------------------------------------------------------------------------
    private static Result run(int[] src, int sw, int sh, Options o, Progress pr) {
        report(pr, 0.02f);
        int maxDim = Math.max(16, Math.min(1024, o.maxDim));
        int nw = sw, nh = sh;
        int big = Math.max(sw, sh);
        boolean up = false;
        if (big > maxDim) {
            double f = (double) maxDim / big;
            nw = Math.max(1, (int) Math.round(sw * f));
            nh = Math.max(1, (int) Math.round(sh * f));
        } else if (big * 1.3 <= maxDim) {
            // small picture: enlarge it so edges can be located with sub-pixel accuracy
            double f = Math.min(4.0, (double) maxDim / big);
            nw = Math.max(1, (int) Math.round(sw * f));
            nh = Math.max(1, (int) Math.round(sh * f));
            up = true;
        }
        final int w = nw, h = nh, n = w * h;
        int[] r = new int[n], g = new int[n], b = new int[n];
        boolean[] opaque = new boolean[n];
        if (up) upscale(src, sw, sh, w, h, r, g, b, opaque);
        else downscale(src, sw, sh, w, h, r, g, b, opaque);
        boolean any = false;
        for (int i = 0; i < n; i++) if (opaque[i]) { any = true; break; }
        if (!any) throw new IllegalArgumentException("image is fully transparent");
        report(pr, 0.10f);

        if (o.denoise && w >= 3 && h >= 3) {
            r = median3(r, opaque, w, h);
            g = median3(g, opaque, w, h);
            b = median3(b, opaque, w, h);
        }
        report(pr, 0.18f);

        byte[] trans = findTransitional(r, g, b, opaque, w, h);
        int[] pal = quantize(r, g, b, opaque, trans, Math.max(2, Math.min(96, o.colors)));
        int[] idx = new int[n];
        mapToPalette(r, g, b, opaque, pal, idx);
        resolveTransitional(r, g, b, opaque, trans, idx, w, h);
        pruneBlendColors(r, g, b, opaque, pal, idx);
        report(pr, 0.30f);

        removeSpeckles(idx, w, h, Math.max(1, o.minArea));
        removeSpeckles(idx, w, h, Math.max(1, o.minArea));
        report(pr, 0.38f);

        // area per palette entry, drawn biggest first
        int[] area = new int[pal.length];
        for (int i = 0; i < n; i++) if (idx[i] >= 0) area[idx[i]]++;
        Integer[] order = new Integer[pal.length];
        for (int i = 0; i < order.length; i++) order[i] = i;
        final int[] fa = area;
        Arrays.sort(order, (x, y) -> fa[y] != fa[x] ? Integer.compare(fa[y], fa[x]) : Integer.compare(x, y));
        int layersCount = 0;
        for (int i = 0; i < order.length; i++) if (area[order[i]] > 0) layersCount++;
        int[] rank = new int[pal.length];
        Arrays.fill(rank, -1);
        int k = 0;
        for (int i = 0; i < order.length; i++) if (area[order[i]] > 0) rank[order[i]] = k++;
        int[] rg = new int[n];
        for (int i = 0; i < n; i++) rg[i] = idx[i] < 0 ? -1 : rank[idx[i]];

        List<Layer> layers = new ArrayList<Layer>();
        int total = 0;
        final int cells = (w + 2) * (h + 2);
        float[] fldA = new float[cells], fldB = new float[cells];
        int[] nxt = new int[cells * 2];
        IntList starts = new IntList(1024);
        for (int L = 0; L < layersCount; L++) {
            String d = traceLayer(rg, L, w, h, fldA, fldB, nxt, starts, o);
            int col = 0;
            for (int p = 0; p < pal.length; p++) if (rank[p] == L) { col = pal[p]; break; }
            if (d.length() > 0) {
                layers.add(new Layer(0xFF000000 | col, d));
                total += d.length();
            }
            report(pr, 0.38f + 0.60f * (L + 1) / Math.max(1, layersCount));
        }
        if (layers.isEmpty()) throw new IllegalArgumentException("nothing to draw");
        report(pr, 1f);
        return new Result(w, h, layers, total);
    }

    private static void report(Progress p, float f) {
        if (p != null) { try { p.onProgress(f); } catch (RuntimeException ignored) { } }
    }

    // ---- scaling ----------------------------------------------------------------------------
    private static void downscale(int[] s, int sw, int sh, int w, int h,
                                  int[] r, int[] g, int[] b, boolean[] op) {
        for (int y = 0; y < h; y++) {
            int y0 = (int) ((long) y * sh / h);
            int y1 = Math.max(y0 + 1, (int) ((long) (y + 1) * sh / h));
            for (int x = 0; x < w; x++) {
                int x0 = (int) ((long) x * sw / w);
                int x1 = Math.max(x0 + 1, (int) ((long) (x + 1) * sw / w));
                long sa = 0, sr = 0, sg = 0, sb = 0;
                int cnt = 0;
                for (int yy = y0; yy < y1 && yy < sh; yy++) {
                    for (int xx = x0; xx < x1 && xx < sw; xx++) {
                        int p = s[yy * sw + xx];
                        int a = p >>> 24;
                        cnt++;
                        sa += a;
                        sr += (long) ((p >> 16) & 255) * a;
                        sg += (long) ((p >> 8) & 255) * a;
                        sb += (long) (p & 255) * a;
                    }
                }
                int i = y * w + x;
                if (cnt == 0 || sa == 0) { op[i] = false; continue; }
                double avgA = (double) sa / cnt;
                if (avgA < 128.0) { op[i] = false; continue; }
                op[i] = true;
                r[i] = (int) (sr / sa);
                g[i] = (int) (sg / sa);
                b[i] = (int) (sb / sa);
            }
        }
    }


    /** Bilinear enlargement (alpha-weighted) used for small pictures. */
    private static void upscale(int[] s, int sw, int sh, int w, int h,
                                int[] r, int[] g, int[] b, boolean[] op) {
        for (int y = 0; y < h; y++) {
            double fy = (y + 0.5) * sh / h - 0.5;
            int y0 = (int) Math.floor(fy);
            double ty = fy - y0;
            int y1 = Math.min(sh - 1, y0 + 1);
            y0 = Math.max(0, y0);
            for (int x = 0; x < w; x++) {
                double fx = (x + 0.5) * sw / w - 0.5;
                int x0 = (int) Math.floor(fx);
                double tx = fx - x0;
                int x1 = Math.min(sw - 1, x0 + 1);
                x0 = Math.max(0, x0);
                double w00 = (1 - tx) * (1 - ty), w10 = tx * (1 - ty), w01 = (1 - tx) * ty, w11 = tx * ty;
                int p00 = s[y0 * sw + x0], p10 = s[y0 * sw + x1], p01 = s[y1 * sw + x0], p11 = s[y1 * sw + x1];
                double a00 = (p00 >>> 24) * w00, a10 = (p10 >>> 24) * w10, a01 = (p01 >>> 24) * w01, a11 = (p11 >>> 24) * w11;
                double sa = a00 + a10 + a01 + a11;
                int i = y * w + x;
                if (sa < 128.0) { op[i] = false; continue; }
                op[i] = true;
                r[i] = clamp((int) Math.round((((p00 >> 16) & 255) * a00 + ((p10 >> 16) & 255) * a10 + ((p01 >> 16) & 255) * a01 + ((p11 >> 16) & 255) * a11) / sa));
                g[i] = clamp((int) Math.round((((p00 >> 8) & 255) * a00 + ((p10 >> 8) & 255) * a10 + ((p01 >> 8) & 255) * a01 + ((p11 >> 8) & 255) * a11) / sa));
                b[i] = clamp((int) Math.round(((p00 & 255) * a00 + (p10 & 255) * a10 + (p01 & 255) * a01 + (p11 & 255) * a11) / sa));
            }
        }
    }

    /**
     * Marks anti-aliasing pixels: a pixel whose colour lies on the line between its two opposite
     * neighbours is only a blend of them. Such pixels must not create palette entries, otherwise
     * every edge gets a grey halo layer.
     */
    private static byte[] findTransitional(int[] r, int[] g, int[] b, boolean[] op, int w, int h) {
        byte[] t = new byte[w * h];   // 0 = flat, 1 = blend along x, 2 = blend along y
        for (int y = 1; y < h - 1; y++) {
            for (int x = 1; x < w - 1; x++) {
                int i = y * w + x;
                if (!op[i]) continue;
                if (op[i - 1] && op[i + 1] && blend(r, g, b, i - 1, i, i + 1)) t[i] = 1;
                else if (op[i - w] && op[i + w] && blend(r, g, b, i - w, i, i + w)) t[i] = 2;
            }
        }
        return t;
    }

    /**
     * Gives every anti-aliasing pixel the palette entry of the flat colour on the side it is
     * closer to (measured along the blend direction) instead of the globally nearest colour,
     * which would otherwise paint random-coloured halos around shapes.
     */
    private static void resolveTransitional(int[] r, int[] g, int[] b, boolean[] op, byte[] axis,
                                            int[] idx, int w, int h) {
        for (int y = 0; y < h; y++) {
            for (int x = 0; x < w; x++) {
                int i = y * w + x;
                if (axis[i] == 0 || !op[i]) continue;
                int step = axis[i] == 1 ? 1 : w;
                int ia = -1, ic = -1;
                int p = i;
                for (int k = 0; k < 8; k++) {
                    int nx = axis[i] == 1 ? x - 1 - k : x, ny = axis[i] == 1 ? y : y - 1 - k;
                    if (nx < 0 || ny < 0) break;
                    p = ny * w + nx;
                    if (!op[p]) break;
                    if (axis[p] == 0) { ia = p; break; }
                }
                for (int k = 0; k < 8; k++) {
                    int nx = axis[i] == 1 ? x + 1 + k : x, ny = axis[i] == 1 ? y : y + 1 + k;
                    if (nx >= w || ny >= h) break;
                    p = ny * w + nx;
                    if (!op[p]) break;
                    if (axis[p] == 0) { ic = p; break; }
                }
                if (ia < 0 || ic < 0 || idx[ia] < 0 || idx[ic] < 0) continue;   // keep nearest-colour fallback
                if (idx[ia] == idx[ic]) { idx[i] = idx[ia]; continue; }
                double dx = r[ic] - r[ia], dy = g[ic] - g[ia], dz = b[ic] - b[ia];
                double len2 = dx * dx + dy * dy + dz * dz;
                if (len2 < 1) continue;
                double t = ((r[i] - r[ia]) * dx + (g[i] - g[ia]) * dy + (b[i] - b[ia]) * dz) / len2;
                idx[i] = t < 0.5 ? idx[ia] : idx[ic];
            }
        }
    }

    private static boolean blend(int[] r, int[] g, int[] b, int a, int p, int c) {
        double dx = r[c] - r[a], dy = g[c] - g[a], dz = b[c] - b[a];
        double len2 = dx * dx + dy * dy + dz * dz;
        if (len2 < 48.0 * 48.0) return false;
        double px = r[p] - r[a], py = g[p] - g[a], pz = b[p] - b[a];
        double t = (px * dx + py * dy + pz * dz) / len2;
        if (t < 0.15 || t > 0.85) return false;
        double ex = px - t * dx, ey = py - t * dy, ez = pz - t * dz;
        return ex * ex + ey * ey + ez * ez < 14.0 * 14.0;
    }


    /**
     * Drops small palette entries that are just a mix of two bigger ones (leftover anti-aliasing
     * colours); their pixels go to the nearest remaining colour.
     */
    private static void pruneBlendColors(int[] r, int[] g, int[] b, boolean[] op, int[] pal, int[] idx) {
        int n = idx.length, total = 0;
        int[] area = new int[pal.length];
        for (int i = 0; i < n; i++) if (idx[i] >= 0) { area[idx[i]]++; total++; }
        boolean[] drop = new boolean[pal.length];
        boolean changed = false;
        for (int p = 0; p < pal.length; p++) {
            if (area[p] == 0 || area[p] >= total * 0.10) continue;
            double pr = (pal[p] >> 16) & 255, pg = (pal[p] >> 8) & 255, pb = pal[p] & 255;
            for (int a = 0; a < pal.length && !drop[p]; a++) {
                if (a == p || drop[a] || area[a] < area[p] * 2) continue;
                for (int c = a + 1; c < pal.length; c++) {
                    if (c == p || drop[c] || area[c] < area[p] * 2) continue;
                    double ar = (pal[a] >> 16) & 255, ag = (pal[a] >> 8) & 255, ab = pal[a] & 255;
                    double dx = ((pal[c] >> 16) & 255) - ar, dy = ((pal[c] >> 8) & 255) - ag, dz = (pal[c] & 255) - ab;
                    double len2 = dx * dx + dy * dy + dz * dz;
                    if (len2 < 60.0 * 60.0) continue;
                    double t = ((pr - ar) * dx + (pg - ag) * dy + (pb - ab) * dz) / len2;
                    if (t < 0.1 || t > 0.9) continue;
                    double ex = pr - ar - t * dx, ey = pg - ag - t * dy, ez = pb - ab - t * dz;
                    if (ex * ex + ey * ey + ez * ez < 16.0 * 16.0) { drop[p] = true; changed = true; break; }
                }
            }
        }
        if (!changed) return;
        for (int i = 0; i < n; i++) {
            if (idx[i] < 0 || !drop[idx[i]]) continue;
            double bd = Double.MAX_VALUE;
            int best = idx[i];
            for (int p = 0; p < pal.length; p++) {
                if (drop[p]) continue;
                double d = dist(r[i], g[i], b[i], (pal[p] >> 16) & 255, (pal[p] >> 8) & 255, pal[p] & 255);
                if (d < bd) { bd = d; best = p; }
            }
            idx[i] = best;
        }
    }

    private static int[] median3(int[] c, boolean[] op, int w, int h) {
        int[] out = c.clone();
        int[] v = new int[9];
        for (int y = 0; y < h; y++) {
            for (int x = 0; x < w; x++) {
                int i = y * w + x;
                if (!op[i]) continue;
                int m = 0;
                for (int dy = -1; dy <= 1; dy++) {
                    int yy = y + dy;
                    if (yy < 0 || yy >= h) continue;
                    for (int dx = -1; dx <= 1; dx++) {
                        int xx = x + dx;
                        if (xx < 0 || xx >= w) continue;
                        int j = yy * w + xx;
                        if (!op[j]) continue;
                        int val = c[j];
                        int q = m++;
                        while (q > 0 && v[q - 1] > val) { v[q] = v[q - 1]; q--; }
                        v[q] = val;
                    }
                }
                out[i] = v[m / 2];
            }
        }
        return out;
    }

    // ---- quantisation -----------------------------------------------------------------------
    private static int[] quantize(int[] r, int[] g, int[] b, boolean[] op, byte[] skip, int k) {
        final int BINS = 32768;
        int[] cnt = new int[BINS];
        long[] sr = new long[BINS], sg = new long[BINS], sb = new long[BINS];
        int opaqueCount = 0, flatCount = 0;
        for (int i = 0; i < r.length; i++) if (op[i]) { opaqueCount++; if (skip[i] == 0) flatCount++; }
        final boolean useFlat = flatCount * 10 >= opaqueCount && flatCount > 0;
        for (int i = 0; i < r.length; i++) {
            if (!op[i]) continue;
            if (useFlat && skip[i] != 0) continue;
            int bin = ((r[i] >> 3) << 10) | ((g[i] >> 3) << 5) | (b[i] >> 3);
            cnt[bin]++;
            sr[bin] += r[i]; sg[bin] += g[i]; sb[bin] += b[i];
        }
        int used = 0;
        for (int i = 0; i < BINS; i++) if (cnt[i] > 0) used++;
        int[] bins = new int[used];
        int[] mr = new int[used], mg = new int[used], mb = new int[used], mc = new int[used];
        int q = 0;
        for (int i = 0; i < BINS; i++) {
            if (cnt[i] == 0) continue;
            bins[q] = i;
            mc[q] = cnt[i];
            mr[q] = (int) (sr[i] / cnt[i]);
            mg[q] = (int) (sg[i] / cnt[i]);
            mb[q] = (int) (sb[i] / cnt[i]);
            q++;
        }
        // median cut over distinct bin colours
        List<int[]> boxes = new ArrayList<int[]>(); // each: array of entry indices
        int[] all = new int[used];
        for (int i = 0; i < used; i++) all[i] = i;
        boxes.add(all);
        while (boxes.size() < k) {
            int best = -1;
            double bestScore = 0;
            int bestCh = 0;
            for (int bi = 0; bi < boxes.size(); bi++) {
                int[] bx = boxes.get(bi);
                if (bx.length < 2) continue;
                int rmin = 255, rmax = 0, gmin = 255, gmax = 0, bmin = 255, bmax = 0;
                long pop = 0;
                for (int e : bx) {
                    rmin = Math.min(rmin, mr[e]); rmax = Math.max(rmax, mr[e]);
                    gmin = Math.min(gmin, mg[e]); gmax = Math.max(gmax, mg[e]);
                    bmin = Math.min(bmin, mb[e]); bmax = Math.max(bmax, mb[e]);
                    pop += mc[e];
                }
                double dr = (rmax - rmin) * 0.9, dg = (gmax - gmin) * 1.2, db = (bmax - bmin) * 0.7;
                double rng = Math.max(dr, Math.max(dg, db));
                if (rng <= 16) continue;   // already a tight cluster: splitting it only makes near-duplicate layers
                double score = rng * Math.sqrt((double) pop);
                if (score > bestScore) {
                    bestScore = score; best = bi;
                    bestCh = (dg >= dr && dg >= db) ? 1 : (dr >= db ? 0 : 2);
                }
            }
            if (best < 0) break;
            int[] bx = boxes.get(best);
            final int ch = bestCh;
            final int[] fr = mr, fg = mg, fb = mb;
            Integer[] sorted = new Integer[bx.length];
            for (int i = 0; i < bx.length; i++) sorted[i] = bx[i];
            Arrays.sort(sorted, (a, c) -> {
                int va = ch == 0 ? fr[a] : (ch == 1 ? fg[a] : fb[a]);
                int vc = ch == 0 ? fr[c] : (ch == 1 ? fg[c] : fb[c]);
                return va != vc ? Integer.compare(va, vc) : Integer.compare(a, c);
            });
            long pop = 0;
            for (int e : bx) pop += mc[e];
            long half = pop / 2, run = 0;
            int cut = 1;
            for (int i = 0; i < sorted.length; i++) {
                run += mc[sorted[i]];
                if (run >= half) { cut = i + 1; break; }
            }
            cut = Math.max(1, Math.min(sorted.length - 1, cut));
            int[] a1 = new int[cut], a2 = new int[sorted.length - cut];
            for (int i = 0; i < cut; i++) a1[i] = sorted[i];
            for (int i = cut; i < sorted.length; i++) a2[i - cut] = sorted[i];
            boxes.set(best, a1);
            boxes.add(a2);
        }
        int pk = boxes.size();
        double[] pr = new double[pk], pg = new double[pk], pb = new double[pk];
        for (int bi = 0; bi < pk; bi++) {
            double wr = 0, wg = 0, wb = 0, wt = 0;
            for (int e : boxes.get(bi)) {
                wr += (double) mr[e] * mc[e]; wg += (double) mg[e] * mc[e]; wb += (double) mb[e] * mc[e];
                wt += mc[e];
            }
            pr[bi] = wr / wt; pg[bi] = wg / wt; pb[bi] = wb / wt;
        }
        // k-means refinement on distinct colours (weighted)
        int[] assign = new int[used];
        for (int it = 0; it < 5; it++) {
            for (int e = 0; e < used; e++) {
                int bestP = 0;
                double bd = Double.MAX_VALUE;
                for (int p = 0; p < pk; p++) {
                    double d = dist(mr[e], mg[e], mb[e], pr[p], pg[p], pb[p]);
                    if (d < bd) { bd = d; bestP = p; }
                }
                assign[e] = bestP;
            }
            double[] ar = new double[pk], ag = new double[pk], ab = new double[pk], aw = new double[pk];
            for (int e = 0; e < used; e++) {
                int p = assign[e];
                ar[p] += (double) mr[e] * mc[e]; ag[p] += (double) mg[e] * mc[e]; ab[p] += (double) mb[e] * mc[e];
                aw[p] += mc[e];
            }
            for (int p = 0; p < pk; p++) {
                if (aw[p] > 0) { pr[p] = ar[p] / aw[p]; pg[p] = ag[p] / aw[p]; pb[p] = ab[p] / aw[p]; }
            }
        }
        // drop unused / duplicate entries
        List<Integer> out = new ArrayList<Integer>();
        boolean[] usedP = new boolean[pk];
        for (int e = 0; e < used; e++) usedP[assign[e]] = true;
        for (int p = 0; p < pk; p++) {
            if (!usedP[p]) continue;
            int c = (clamp((int) Math.round(pr[p])) << 16) | (clamp((int) Math.round(pg[p])) << 8) | clamp((int) Math.round(pb[p]));
            if (!out.contains(c)) out.add(c);
        }
        // merge entries that are visually the same colour (keep the more popular one).
        // Flat graphics (few distinct colours) merge aggressively, photos keep their subtle shades.
        final double mergeDist = used < 40 ? 36.0 : 16.0;
        long[] pop = new long[pk];
        for (int e = 0; e < used; e++) pop[assign[e]] += mc[e];
        List<Integer> kept = new ArrayList<Integer>();
        Integer[] byPop = new Integer[pk];
        for (int p = 0; p < pk; p++) byPop[p] = p;
        final long[] fpop = pop;
        Arrays.sort(byPop, (x1, x2) -> Long.compare(fpop[x2], fpop[x1]));
        for (int bi2 = 0; bi2 < pk; bi2++) {
            int p = byPop[bi2];
            if (!usedP[p]) continue;
            boolean dup = false;
            for (int q2 : kept) {
                double dr2 = pr[p] - pr[q2], dg2 = pg[p] - pg[q2], db2 = pb[p] - pb[q2];
                if (dr2 * dr2 + dg2 * dg2 + db2 * db2 < mergeDist * mergeDist) { dup = true; break; }
            }
            if (!dup) kept.add(p);
        }
        int[] pal = new int[kept.size()];
        for (int i = 0; i < pal.length; i++) {
            int p = kept.get(i);
            pal[i] = (clamp((int) Math.round(pr[p])) << 16) | (clamp((int) Math.round(pg[p])) << 8) | clamp((int) Math.round(pb[p]));
        }
        return pal;
    }

    private static int clamp(int v) { return v < 0 ? 0 : Math.min(255, v); }

    private static double dist(double r1, double g1, double b1, double r2, double g2, double b2) {
        double rm = (r1 + r2) * 0.5;
        double dr = r1 - r2, dg = g1 - g2, db = b1 - b2;
        return (2.0 + rm / 256.0) * dr * dr + 4.0 * dg * dg + (2.0 + (255.0 - rm) / 256.0) * db * db;
    }

    private static void mapToPalette(int[] r, int[] g, int[] b, boolean[] op, int[] pal, int[] idx) {
        int[] cache = new int[32768];
        Arrays.fill(cache, -1);
        for (int i = 0; i < r.length; i++) {
            if (!op[i]) { idx[i] = -1; continue; }
            int bin = ((r[i] >> 3) << 10) | ((g[i] >> 3) << 5) | (b[i] >> 3);
            int c = cache[bin];
            if (c < 0) {
                double bd = Double.MAX_VALUE;
                c = 0;
                for (int p = 0; p < pal.length; p++) {
                    double d = dist(r[i], g[i], b[i], (pal[p] >> 16) & 255, (pal[p] >> 8) & 255, pal[p] & 255);
                    if (d < bd) { bd = d; c = p; }
                }
                cache[bin] = c;
            }
            idx[i] = c;
        }
    }

    // ---- speckle removal --------------------------------------------------------------------
    private static void removeSpeckles(int[] idx, int w, int h, int minArea) {
        int n = w * h;
        boolean[] seen = new boolean[n];
        int[] queue = new int[n];
        for (int s = 0; s < n; s++) {
            if (seen[s]) continue;
            int label = idx[s];
            int head = 0, tail = 0;
            queue[tail++] = s;
            seen[s] = true;
            while (head < tail) {
                int p = queue[head++];
                int x = p % w, y = p / w;
                if (x > 0 && !seen[p - 1] && idx[p - 1] == label) { seen[p - 1] = true; queue[tail++] = p - 1; }
                if (x < w - 1 && !seen[p + 1] && idx[p + 1] == label) { seen[p + 1] = true; queue[tail++] = p + 1; }
                if (y > 0 && !seen[p - w] && idx[p - w] == label) { seen[p - w] = true; queue[tail++] = p - w; }
                if (y < h - 1 && !seen[p + w] && idx[p + w] == label) { seen[p + w] = true; queue[tail++] = p + w; }
                // diagonals: a 1px diagonal line is a single object, not a row of specks
                if (x > 0 && y > 0 && !seen[p - w - 1] && idx[p - w - 1] == label) { seen[p - w - 1] = true; queue[tail++] = p - w - 1; }
                if (x < w - 1 && y > 0 && !seen[p - w + 1] && idx[p - w + 1] == label) { seen[p - w + 1] = true; queue[tail++] = p - w + 1; }
                if (x > 0 && y < h - 1 && !seen[p + w - 1] && idx[p + w - 1] == label) { seen[p + w - 1] = true; queue[tail++] = p + w - 1; }
                if (x < w - 1 && y < h - 1 && !seen[p + w + 1] && idx[p + w + 1] == label) { seen[p + w + 1] = true; queue[tail++] = p + w + 1; }
            }
            if (tail >= minArea) continue;
            // find most common neighbouring label
            int bestLabel = Integer.MIN_VALUE, bestCount = 0;
            int[] labs = new int[tail * 4];
            int ln = 0;
            for (int q = 0; q < tail; q++) {
                int p = queue[q];
                int x = p % w, y = p / w;
                if (x > 0 && idx[p - 1] != label) labs[ln++] = idx[p - 1];
                if (x < w - 1 && idx[p + 1] != label) labs[ln++] = idx[p + 1];
                if (y > 0 && idx[p - w] != label) labs[ln++] = idx[p - w];
                if (y < h - 1 && idx[p + w] != label) labs[ln++] = idx[p + w];
            }
            if (ln == 0) continue;
            Arrays.sort(labs, 0, ln);
            int run = 1;
            for (int i = 1; i <= ln; i++) {
                if (i < ln && labs[i] == labs[i - 1]) { run++; continue; }
                if (run > bestCount) { bestCount = run; bestLabel = labs[i - 1]; }
                run = 1;
            }
            for (int q = 0; q < tail; q++) idx[queue[q]] = bestLabel;
        }
    }

    // ---- tracing (marching squares on a lightly blurred mask + Bezier fitting) ----------------
    private static String traceLayer(int[] rg, int L, int w, int h, float[] fa, float[] fb,
                                     int[] nxt, IntList starts, Options o) {
        final int Wp = w + 2, Hp = h + 2;
        Arrays.fill(fa, 0f);
        boolean any = false;
        for (int y = 0; y < h; y++) {
            int row = (y + 1) * Wp + 1, ro = y * w;
            for (int x = 0; x < w; x++) if (rg[ro + x] >= L) { fa[row + x] = 1f; any = true; }
        }
        if (!any) return "";
        // [1 6 1]/8 blur, horizontal then vertical: smooth enough for sub-pixel edges, keeps 1px lines alive
        for (int y = 0; y < Hp; y++) {
            int row = y * Wp;
            for (int x = 0; x < Wp; x++) {
                float l = x > 0 ? fa[row + x - 1] : 0f;
                float rr = x < Wp - 1 ? fa[row + x + 1] : 0f;
                fb[row + x] = (l + 6f * fa[row + x] + rr) * 0.125f;
            }
        }
        for (int y = 0; y < Hp; y++) {
            for (int x = 0; x < Wp; x++) {
                float u = y > 0 ? fb[(y - 1) * Wp + x] : 0f;
                float d = y < Hp - 1 ? fb[(y + 1) * Wp + x] : 0f;
                fa[y * Wp + x] = (u + 6f * fb[y * Wp + x] + d) * 0.125f;
            }
        }
        Arrays.fill(nxt, -1);
        starts.clear();
        final float T = 0.5f;
        int[] ks = new int[4];
        boolean[] in = new boolean[4];
        for (int cy = 0; cy < Hp - 1; cy++) {
            for (int cx = 0; cx < Wp - 1; cx++) {
                int i0 = cy * Wp + cx;
                float v0 = fa[i0], v1 = fa[i0 + 1], v2 = fa[i0 + Wp + 1], v3 = fa[i0 + Wp];
                boolean a0 = v0 >= T, a1 = v1 >= T, a2 = v2 >= T, a3 = v3 >= T;
                if (a0 == a1 && a1 == a2 && a2 == a3) continue;
                ks[0] = i0 * 2;              // top    (horizontal edge)
                ks[1] = (i0 + 1) * 2 + 1;    // right  (vertical edge)
                ks[2] = (i0 + Wp) * 2;       // bottom (horizontal edge)
                ks[3] = i0 * 2 + 1;          // left   (vertical edge)
                in[0] = a0; in[1] = a1; in[2] = a2; in[3] = a3;
                int cnt = (a0 != a1 ? 1 : 0) + (a1 != a2 ? 1 : 0) + (a2 != a3 ? 1 : 0) + (a3 != a0 ? 1 : 0);
                if (cnt == 2) {
                    int ex = -1, en = -1;
                    for (int e = 0; e < 4; e++) {
                        if (in[e] == in[(e + 1) & 3]) continue;
                        if (in[e]) ex = ks[e]; else en = ks[e];
                    }
                    nxt[ex] = en;
                    starts.add(ex);
                } else { // saddle: decide by the centre value
                    boolean joined = (v0 + v1 + v2 + v3) * 0.25f >= T;
                    for (int e = 0; e < 4; e++) {
                        if (!in[e]) continue;
                        int target = joined ? ks[(e + 1) & 3] : ks[(e + 3) & 3];
                        nxt[ks[e]] = target;
                        starts.add(ks[e]);
                    }
                }
            }
        }
        StringBuilder sb = new StringBuilder();
        IntList keys = new IntList(512);
        double[] px = new double[1024], py = new double[1024];
        double[] pt = new double[2];
        for (int si = 0; si < starts.size(); si++) {
            int s = starts.get(si);
            if (nxt[s] < 0) continue;
            keys.clear();
            int cur = s;
            boolean closed = false;
            while (true) {
                int nx = nxt[cur];
                if (nx < 0) break;
                keys.add(cur);
                nxt[cur] = -1;
                cur = nx;
                if (cur == s) { closed = true; break; }
            }
            int n = keys.size();
            if (!closed || n < 4) continue;
            if (px.length < n) { px = new double[n * 2]; py = new double[n * 2]; }
            for (int i = 0; i < n; i++) {
                pointOf(keys.get(i), fa, Wp, pt);
                px[i] = Math.max(0, Math.min(w, pt[0]));
                py[i] = Math.max(0, Math.min(h, pt[1]));
            }
            emitLoop(sb, px, py, n, o);
        }
        return sb.toString();
    }

    /** Position (image pixels) where the 0.5 iso-line crosses the grid edge identified by key. */
    private static void pointOf(int key, float[] f, int Wp, double[] out) {
        int idx = key >> 1;
        int gx = idx % Wp, gy = idx / Wp;
        if ((key & 1) == 0) {
            float a = f[idx], b = f[idx + 1];
            out[0] = gx + (0.5 - a) / (b - a) - 0.5;
            out[1] = gy - 0.5;
        } else {
            float a = f[idx], b = f[idx + Wp];
            out[0] = gx - 0.5;
            out[1] = gy + (0.5 - a) / (b - a) - 0.5;
        }
    }

    private static void emitLoop(StringBuilder sb, double[] vx, double[] vy, int n0, Options o) {
        // drop (almost) duplicate points
        double[] x = new double[n0], y = new double[n0];
        int n = 0;
        for (int i = 0; i < n0; i++) {
            if (n > 0 && Math.abs(vx[i] - x[n - 1]) < 1e-4 && Math.abs(vy[i] - y[n - 1]) < 1e-4) continue;
            x[n] = vx[i]; y[n] = vy[i]; n++;
        }
        while (n > 1 && Math.abs(x[0] - x[n - 1]) < 1e-4 && Math.abs(y[0] - y[n - 1]) < 1e-4) n--;
        if (n < 3) return;
        double area = 0, perim = 0;
        double[] cum = new double[n + 1];
        for (int i = 0; i < n; i++) {
            int j = (i + 1) % n;
            area += x[i] * y[j] - x[j] * y[i];
            double seg = Math.hypot(x[j] - x[i], y[j] - y[i]);
            perim += seg;
            cum[i + 1] = perim;
        }
        if (Math.abs(area) * 0.5 < 1.5 || perim < 3.0) return;

        // uniform resampling (about 1px apart)
        double step = perim >= 24 ? 1.0 : perim / 24.0;
        int m = (int) Math.max(8, Math.round(perim / step));
        double sl = perim / m;
        double[] rx = new double[m], ry = new double[m];
        int seg = 0;
        for (int j = 0; j < m; j++) {
            double target = j * sl;
            while (seg < n - 1 && cum[seg + 1] < target) seg++;
            double len = cum[seg + 1] - cum[seg];
            double t = len > 1e-12 ? (target - cum[seg]) / len : 0;
            int a = seg, b = (seg + 1) % n;
            rx[j] = x[a] + (x[b] - x[a]) * t;
            ry[j] = y[a] + (y[b] - y[a]) * t;
        }

        // corner detection
        int k = Math.max(1, Math.min((int) Math.round(2.0 / sl), m / 4));
        double[] turn = new double[m];
        for (int i = 0; i < m; i++) {
            int p = ((i - k) % m + m) % m, q = (i + k) % m;
            double ax = rx[i] - rx[p], ay = ry[i] - ry[p], bx = rx[q] - rx[i], by = ry[q] - ry[i];
            double la = Math.hypot(ax, ay), lb = Math.hypot(bx, by);
            if (la < 1e-9 || lb < 1e-9) { turn[i] = 0; continue; }
            double c = (ax * bx + ay * by) / (la * lb);
            c = Math.max(-1, Math.min(1, c));
            turn[i] = Math.toDegrees(Math.acos(c));
        }
        IntList corners = new IntList(16);
        for (int i = 0; i < m; i++) {
            if (turn[i] <= o.cornerDeg) continue;
            boolean best = true;
            for (int d = 1; d <= k && best; d++) {
                if (turn[((i - d) % m + m) % m] >= turn[i]) best = false;
                if (turn[(i + d) % m] > turn[i]) best = false;
            }
            if (best) corners.add(i);
        }

        // smooth the staircase noise of the contour; corners stay anchored
        boolean[] anchor = new boolean[m];
        for (int ci = 0; ci < corners.size(); ci++) anchor[corners.get(ci)] = true;
        int passes = Math.min(4, m / 14);
        double[] tx2 = new double[m], ty2 = new double[m];
        for (int ps = 0; ps < passes; ps++) {
            for (int i = 0; i < m; i++) {
                if (anchor[i]) { tx2[i] = rx[i]; ty2[i] = ry[i]; continue; }
                int p = (i + m - 1) % m, q = (i + 1) % m;
                tx2[i] = 0.25 * rx[p] + 0.5 * rx[i] + 0.25 * rx[q];
                ty2[i] = 0.25 * ry[p] + 0.5 * ry[i] + 0.25 * ry[q];
            }
            System.arraycopy(tx2, 0, rx, 0, m);
            System.arraycopy(ty2, 0, ry, 0, m);
        }

        List<double[]> beziers = new ArrayList<double[]>();
        double err = Math.max(0.15, o.tolerance);
        if (corners.size() == 0) {
            double[] sx = new double[m + 1], sy = new double[m + 1];
            for (int i = 0; i <= m; i++) { sx[i] = rx[i % m]; sy[i] = ry[i % m]; }
            double tx = rx[1] - rx[m - 1], ty = ry[1] - ry[m - 1];
            double tl = Math.hypot(tx, ty);
            if (tl < 1e-12) return;
            tx /= tl; ty /= tl;
            fitCubic(sx, sy, 0, m, tx, ty, -tx, -ty, err, beziers, 0);
        } else {
            int q = corners.size();
            for (int c = 0; c < q; c++) {
                int from = corners.get(c), to = corners.get((c + 1) % q);
                int len = ((to - from) % m + m) % m + 1;
                if (q == 1 || len == 1) len = m + 1;
                double[] sx = new double[len], sy = new double[len];
                for (int i = 0; i < len; i++) { sx[i] = rx[(from + i) % m]; sy[i] = ry[(from + i) % m]; }
                int kk = Math.min(3, len - 1);
                double[] t1 = unit(sx[kk] - sx[0], sy[kk] - sy[0]);
                double[] t2 = unit(sx[len - 1 - kk] - sx[len - 1], sy[len - 1 - kk] - sy[len - 1]);
                fitCubic(sx, sy, 0, len - 1, t1[0], t1[1], t2[0], t2[1], err, beziers, 0);
            }
        }
        if (beziers.isEmpty()) return;
        double[] b0 = beziers.get(0);
        sb.append('M').append(fmt(b0[0])).append(',').append(fmt(b0[1]));
        for (double[] bz : beziers) {
            if (isStraight(bz)) {
                sb.append('L').append(fmt(bz[6])).append(',').append(fmt(bz[7]));
            } else {
                sb.append('C').append(fmt(bz[2])).append(',').append(fmt(bz[3])).append(' ')
                  .append(fmt(bz[4])).append(',').append(fmt(bz[5])).append(' ')
                  .append(fmt(bz[6])).append(',').append(fmt(bz[7]));
            }
        }
        sb.append('Z');
    }

    private static double[] unit(double x, double y) {
        double l = Math.hypot(x, y);
        if (l < 1e-12) return new double[]{0, 0};
        return new double[]{x / l, y / l};
    }

    private static boolean isStraight(double[] b) {
        double dx = b[6] - b[0], dy = b[7] - b[1];
        double l = Math.hypot(dx, dy);
        if (l < 1e-9) return true;
        double d1 = Math.abs((b[2] - b[0]) * dy - (b[3] - b[1]) * dx) / l;
        double d2 = Math.abs((b[4] - b[0]) * dy - (b[5] - b[1]) * dx) / l;
        return d1 < 0.06 && d2 < 0.06;
    }

    // ---- Schneider cubic Bezier fitting (Graphics Gems I) -------------------------------------
    private static void fitCubic(double[] x, double[] y, int first, int last,
                                 double t1x, double t1y, double t2x, double t2y,
                                 double err, List<double[]> out, int depth) {
        if (last - first == 1) {
            double dist = Math.hypot(x[last] - x[first], y[last] - y[first]) / 3.0;
            out.add(new double[]{x[first], y[first],
                    x[first] + t1x * dist, y[first] + t1y * dist,
                    x[last] + t2x * dist, y[last] + t2y * dist,
                    x[last], y[last]});
            return;
        }
        double[] u = chordParam(x, y, first, last);
        double[] bez = generateBezier(x, y, first, last, u, t1x, t1y, t2x, t2y);
        int[] split = new int[1];
        double maxErr = maxError(x, y, first, last, bez, u, split);
        double e2 = err * err;
        if (maxErr < e2) { out.add(bez); return; }
        if (maxErr < e2 * 4.0) {
            for (int it = 0; it < 4; it++) {
                double[] u2 = reparam(x, y, first, last, u, bez);
                bez = generateBezier(x, y, first, last, u2, t1x, t1y, t2x, t2y);
                maxErr = maxError(x, y, first, last, bez, u2, split);
                if (maxErr < e2) { out.add(bez); return; }
                u = u2;
            }
        }
        if (depth > 48) { out.add(bez); return; }
        int sp = Math.max(first + 1, Math.min(last - 1, split[0]));
        double cx = x[sp - 1] - x[sp + 1], cy = y[sp - 1] - y[sp + 1];
        double[] c = unit(cx, cy);
        fitCubic(x, y, first, sp, t1x, t1y, c[0], c[1], err, out, depth + 1);
        fitCubic(x, y, sp, last, -c[0], -c[1], t2x, t2y, err, out, depth + 1);
    }

    private static double[] chordParam(double[] x, double[] y, int first, int last) {
        int n = last - first + 1;
        double[] u = new double[n];
        for (int i = 1; i < n; i++)
            u[i] = u[i - 1] + Math.hypot(x[first + i] - x[first + i - 1], y[first + i] - y[first + i - 1]);
        double tot = u[n - 1];
        if (tot < 1e-12) { for (int i = 0; i < n; i++) u[i] = (double) i / (n - 1); return u; }
        for (int i = 1; i < n; i++) u[i] /= tot;
        return u;
    }

    private static double[] generateBezier(double[] x, double[] y, int first, int last, double[] u,
                                           double t1x, double t1y, double t2x, double t2y) {
        int n = last - first + 1;
        double c00 = 0, c01 = 0, c11 = 0, x0 = 0, x1 = 0;
        double p0x = x[first], p0y = y[first], p3x = x[last], p3y = y[last];
        for (int i = 0; i < n; i++) {
            double t = u[i], mt = 1 - t;
            double b0 = mt * mt * mt, b1 = 3 * t * mt * mt, b2 = 3 * t * t * mt, b3 = t * t * t;
            double a1x = t1x * b1, a1y = t1y * b1, a2x = t2x * b2, a2y = t2y * b2;
            c00 += a1x * a1x + a1y * a1y;
            c01 += a1x * a2x + a1y * a2y;
            c11 += a2x * a2x + a2y * a2y;
            double tx = x[first + i] - (p0x * (b0 + b1) + p3x * (b2 + b3));
            double ty = y[first + i] - (p0y * (b0 + b1) + p3y * (b2 + b3));
            x0 += a1x * tx + a1y * ty;
            x1 += a2x * tx + a2y * ty;
        }
        double det = c00 * c11 - c01 * c01;
        double detC0X = c00 * x1 - c01 * x0;
        double detXC1 = x0 * c11 - x1 * c01;
        double al = det == 0 ? 0 : detXC1 / det;
        double ar = det == 0 ? 0 : detC0X / det;
        double segLen = Math.hypot(p3x - p0x, p3y - p0y);
        double eps = 1e-6 * segLen;
        if (al < eps || ar < eps || al > segLen * 3 || ar > segLen * 3) { al = ar = segLen / 3.0; }
        return new double[]{p0x, p0y, p0x + t1x * al, p0y + t1y * al, p3x + t2x * ar, p3y + t2y * ar, p3x, p3y};
    }

    private static double maxError(double[] x, double[] y, int first, int last, double[] b, double[] u, int[] split) {
        double maxD = 0;
        split[0] = (last - first + 1) / 2 + first;
        for (int i = 1; i < last - first; i++) {
            double t = u[i], mt = 1 - t;
            double b0 = mt * mt * mt, b1 = 3 * t * mt * mt, b2 = 3 * t * t * mt, b3 = t * t * t;
            double qx = b[0] * b0 + b[2] * b1 + b[4] * b2 + b[6] * b3;
            double qy = b[1] * b0 + b[3] * b1 + b[5] * b2 + b[7] * b3;
            double dx = qx - x[first + i], dy = qy - y[first + i];
            double d = dx * dx + dy * dy;
            if (d >= maxD) { maxD = d; split[0] = first + i; }
        }
        return maxD;
    }

    private static double[] reparam(double[] x, double[] y, int first, int last, double[] u, double[] b) {
        int n = last - first + 1;
        double[] r = new double[n];
        for (int i = 0; i < n; i++) {
            double t = u[i], mt = 1 - t;
            double b0 = mt * mt * mt, b1 = 3 * t * mt * mt, b2 = 3 * t * t * mt, b3 = t * t * t;
            double qx = b[0] * b0 + b[2] * b1 + b[4] * b2 + b[6] * b3;
            double qy = b[1] * b0 + b[3] * b1 + b[5] * b2 + b[7] * b3;
            double d1x = 3 * (mt * mt * (b[2] - b[0]) + 2 * mt * t * (b[4] - b[2]) + t * t * (b[6] - b[4]));
            double d1y = 3 * (mt * mt * (b[3] - b[1]) + 2 * mt * t * (b[5] - b[3]) + t * t * (b[7] - b[5]));
            double d2x = 6 * (mt * (b[4] - 2 * b[2] + b[0]) + t * (b[6] - 2 * b[4] + b[2]));
            double d2y = 6 * (mt * (b[5] - 2 * b[3] + b[1]) + t * (b[7] - 2 * b[5] + b[3]));
            double ex = qx - x[first + i], ey = qy - y[first + i];
            double num = ex * d1x + ey * d1y;
            double den = d1x * d1x + d1y * d1y + ex * d2x + ey * d2y;
            double nt = Math.abs(den) < 1e-12 ? t : t - num / den;
            r[i] = Math.max(0, Math.min(1, nt));
        }
        r[0] = 0; r[n - 1] = 1;
        return r;
    }

    /** Two-decimal number without trailing zeros (fast, no String.format). */
    static String fmt(double v) {
        long q = Math.round(v * 100.0);
        if (q == 0) return "0";
        boolean neg = q < 0;
        if (neg) q = -q;
        long ip = q / 100;
        int fp = (int) (q % 100);
        StringBuilder s = new StringBuilder(8);
        if (neg) s.append('-');
        s.append(ip);
        if (fp != 0) {
            s.append('.');
            if (fp % 10 == 0) s.append(fp / 10);
            else { if (fp < 10) s.append('0'); s.append(fp); }
        }
        return s.toString();
    }

    // minimal growable int array
    private static final class IntList {
        private int[] a;
        private int n;
        IntList(int cap) { a = new int[cap]; }
        void add(int v) { if (n == a.length) a = Arrays.copyOf(a, n * 2); a[n++] = v; }
        int get(int i) { return a[i]; }
        int size() { return n; }
        void clear() { n = 0; }
    }
}
