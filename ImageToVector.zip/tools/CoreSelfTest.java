import com.imgvec.core.*;
import java.awt.*;
import java.awt.geom.*;
import java.awt.image.BufferedImage;
import java.io.*;
import java.nio.file.*;
import java.util.*;
import java.util.List;
import javax.imageio.ImageIO;

/** Run: java CoreSelfTest <template.xml> <image.png> <outDir> */
public class CoreSelfTest {
    static int fails = 0;
    static void check(String what, boolean ok) {
        System.out.println((ok ? "PASS  " : "FAIL  ") + what);
        if (!ok) fails++;
    }

    // very small path renderer (M L Q Z) used only for testing
    static Path2D parse(String d) {
        Path2D.Double p = new Path2D.Double(Path2D.WIND_NON_ZERO);
        String[] tok = d.replace("M", " M ").replace("L", " L ").replace("Q", " Q ").replace("Z", " Z ").trim().split("\\s+");
        for (int i = 0; i < tok.length; i++) {
            String t = tok[i];
            if (t.equals("M")) { double[] a = xy(tok[++i]); p.moveTo(a[0], a[1]); }
            else if (t.equals("L")) { double[] a = xy(tok[++i]); p.lineTo(a[0], a[1]); }
            else if (t.equals("Q")) { double[] a = xy(tok[++i]); double[] b = xy(tok[++i]); p.quadTo(a[0], a[1], b[0], b[1]); }
            else if (t.equals("Z")) p.closePath();
        }
        return p;
    }
    static double[] xy(String s) { String[] a = s.split(","); return new double[]{Double.parseDouble(a[0]), Double.parseDouble(a[1])}; }

    static BufferedImage render(VectorEngine.Result r, int scale) {
        BufferedImage img = new BufferedImage(r.width * scale, r.height * scale, BufferedImage.TYPE_INT_ARGB);
        Graphics2D g = img.createGraphics();
        g.setRenderingHint(RenderingHints.KEY_ANTIALIASING, RenderingHints.VALUE_ANTIALIAS_ON);
        g.scale(scale, scale);
        for (VectorEngine.Layer l : r.layers) { g.setColor(new Color(l.color, true)); g.fill(parse(l.pathData)); }
        g.dispose();
        return img;
    }

    public static void main(String[] a) throws Exception {
        System.setProperty("java.awt.headless", "true");
        byte[] tplBytes = Files.readAllBytes(Paths.get(a[0]));
        File outDir = new File(a[2]); outDir.mkdirs();
        TemplateData tpl = new TemplateData(tplBytes, new File(a[0]).getName());
        tpl.validate();
        check("template detected as binary AXML", tpl.binary);

        // 1. writer reproduces the template byte-for-byte when fed its own content
        Axml.Doc d = Axml.parse(tplBytes);
        Axml.Template t = Axml.readTemplate(tplBytes);
        List<Axml.PathSpec> ps = new ArrayList<>();
        for (List<Axml.Attr> pa : d.pathAttrs) {
            int col = 0; String pd = null;
            for (Axml.Attr x : pa) { if (x.resId == Axml.ATTR_FILLCOLOR) col = x.data; if (x.resId == Axml.ATTR_PATHDATA) pd = x.str; }
            ps.add(new Axml.PathSpec(col, pd));
        }
        byte[] rebuilt = Axml.build(t.rootAttrs, ps, t);
        check("round-trip rebuild == original template (" + rebuilt.length + " bytes)", Arrays.equals(rebuilt, tplBytes));

        // 2. dimension encoder
        check("dimension 24dp encodes to 0x1801", Axml.createComplexDimension(24f, 1) == 0x1801);
        check("dimension decode 0x1801 == 24", Axml.complexToFloat(0x1801) == 24f);
        float v = Axml.complexToFloat(Axml.createComplexDimension(18.5f, 1));
        check("dimension 18.5dp round trip (" + v + ")", Math.abs(v - 18.5f) < 0.01f);

        // 3. real conversion
        BufferedImage src = ImageIO.read(new File(a[1]));
        int w = src.getWidth(), h = src.getHeight();
        int[] px = new int[w * h];
        src.getRGB(0, 0, w, h, px, 0, w);
        for (int[] cfg : new int[][]{{128, 16}, {256, 32}, {384, 48}}) {
            Converter.Settings s = new Converter.Settings();
            s.maxDim = cfg[0]; s.colors = cfg[1];
            long t0 = System.currentTimeMillis();
            Converter.Output o = Converter.convert(px, w, h, s, tpl, null);
            long ms = System.currentTimeMillis() - t0;
            VectorEngine.Result r = o.model;
            check("convert " + cfg[0] + "px/" + cfg[1] + "c: " + r.layers.size() + " layers, " + r.totalChars + " chars, "
                    + ms + " ms, attempts=" + o.attempts, o.binary && Converter.verifyBinary(o.fileBytes, r) == null);
            check("   text variant verifies", VectorXml.verifyText(o.text, r) == null);
            // mean abs error vs. source
            BufferedImage rr = render(r, 1);
            BufferedImage ref = new BufferedImage(r.width, r.height, BufferedImage.TYPE_INT_ARGB);
            Graphics2D g = ref.createGraphics();
            g.setRenderingHint(RenderingHints.KEY_INTERPOLATION, RenderingHints.VALUE_INTERPOLATION_BILINEAR);
            g.drawImage(src.getScaledInstance(r.width, r.height, Image.SCALE_AREA_AVERAGING), 0, 0, null); g.dispose();
            double err = 0; long n = 0;
            for (int y = 0; y < r.height; y++) for (int x = 0; x < r.width; x++) {
                int p = rr.getRGB(x, y), q = ref.getRGB(x, y);
                if ((q >>> 24) < 128) continue;
                err += Math.abs(((p >> 16) & 255) - ((q >> 16) & 255)) + Math.abs(((p >> 8) & 255) - ((q >> 8) & 255)) + Math.abs((p & 255) - (q & 255));
                n++;
            }
            double mae = err / (3.0 * n);
            check(String.format("   mean colour error %.1f / 255", mae), mae < 25);
            ImageIO.write(render(r, 2), "png", new File(outDir, "render_" + cfg[0] + ".png"));
            Files.write(Paths.get(outDir.getPath(), "out_" + cfg[0] + ".xml"), o.fileBytes);
            Files.write(Paths.get(outDir.getPath(), "out_" + cfg[0] + "_text.xml"), o.text.getBytes("UTF-8"));
        }

        // 4. transparent PNG + tiny + single colour + fully transparent
        int[] tr = new int[64 * 64];
        for (int y = 0; y < 64; y++) for (int x = 0; x < 64; x++) {
            double dx = x - 32, dy = y - 32;
            tr[y * 64 + x] = dx * dx + dy * dy < 400 ? 0xFFE03020 : 0x00000000;
        }
        Converter.Output o2 = Converter.convert(tr, 64, 64, new Converter.Settings(), tpl, null);
        check("transparent circle: " + o2.model.layers.size() + " layer(s)", Converter.verifyBinary(o2.fileBytes, o2.model) == null);
        int[] one = new int[10 * 10]; Arrays.fill(one, 0xFF123456);
        Converter.Output o3 = Converter.convert(one, 10, 10, new Converter.Settings(), tpl, null);
        check("single colour 10x10", Converter.verifyBinary(o3.fileBytes, o3.model) == null);
        int[] none = new int[16 * 16];
        boolean threw = false;
        try { Converter.convert(none, 16, 16, new Converter.Settings(), tpl, null); } catch (IllegalArgumentException e) { threw = true; }
        check("fully transparent image rejected cleanly", threw);
        int[] wide = new int[300 * 40]; Arrays.fill(wide, 0xFF00AA00);
        Converter.Output o4 = Converter.convert(wide, 300, 40, new Converter.Settings(), tpl, null);
        Axml.Doc d4 = Axml.parse(o4.fileBytes);
        float ww = 0, hh = 0;
        for (Axml.Attr x : d4.rootAttrs) { if (x.resId == Axml.ATTR_WIDTH) ww = Axml.complexToFloat(x.data); if (x.resId == Axml.ATTR_HEIGHT) hh = Axml.complexToFloat(x.data); }
        check(String.format("wide image keeps aspect: %.2fdp x %.2fdp", ww, hh), Math.abs(ww / hh - 300f / 40f) < 0.05);
        boolean tint = false;
        for (Axml.Attr x : d4.rootAttrs) if (x.resId == Axml.ATTR_TINT) tint = true;
        check("tint removed by default", !tint);

        // 5. text template path
        String txt = "<?xml version=\"1.0\" encoding=\"utf-8\"?>\n<vector xmlns:android=\"http://schemas.android.com/apk/res/android\"\n android:width=\"24dp\" android:height=\"24dp\" android:viewportWidth=\"24\" android:viewportHeight=\"24\" android:tint=\"?attr/colorControlNormal\">\n<path android:fillColor=\"#FF000000\" android:pathData=\"M0,0L1,1Z\"/></vector>";
        TemplateData tt = new TemplateData(txt.getBytes("UTF-8"), "ic_text.xml");
        tt.validate();
        Converter.Output o5 = Converter.convert(px, w, h, new Converter.Settings(), tt, null);
        check("text template -> text output verifies", !o5.binary && VectorXml.verifyText(o5.text, o5.model) == null && !o5.text.contains("tint"));

        // 6. garbage template rejected
        boolean bad = false;
        try { new TemplateData("hello".getBytes(), "x.xml").validate(); } catch (IllegalArgumentException e) { bad = true; }
        check("garbage template rejected", bad);
        bad = false;
        try { byte[] c = tplBytes.clone(); c[40] ^= 0x7f; c[200] ^= 0x55; new TemplateData(Arrays.copyOf(c, c.length - 8), "x.xml").validate(); } catch (RuntimeException e) { bad = true; }
        check("truncated/corrupt binary template rejected without crash", bad);

        // 7. big path string forces UTF-16 pool and still parses
        StringBuilder big = new StringBuilder("M0,0");
        for (int i = 0; i < 12000; i++) big.append("L").append(i % 100).append(",").append((i * 7) % 100);
        big.append("Z");
        List<Axml.PathSpec> bp = new ArrayList<>(); bp.add(new Axml.PathSpec(0xFF112233, big.toString()));
        byte[] bb = Axml.build(t.rootAttrs, bp, t);
        Axml.Doc bd = Axml.parse(bb);
        String back = null;
        for (Axml.Attr x : bd.pathAttrs.get(0)) if (x.resId == Axml.ATTR_PATHDATA) back = x.str;
        check("pathData of " + big.length() + " chars survives binary round trip (utf16 pool=" + !bd.utf8 + ")", big.toString().equals(back));

        System.out.println(fails == 0 ? "\nALL TESTS PASSED" : "\n" + fails + " TEST(S) FAILED");
        System.exit(fails == 0 ? 0 : 1);
    }
}
