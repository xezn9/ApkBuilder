package com.apkbuilder

import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.compose.setContent
import androidx.activity.enableEdgeToEdge
import androidx.activity.result.contract.ActivityResultContracts
import androidx.activity.viewModels
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.darkColorScheme
import androidx.compose.runtime.CompositionLocalProvider
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalLayoutDirection
import androidx.compose.ui.unit.LayoutDirection
import com.apkbuilder.ui.AppRoot

class MainActivity : ComponentActivity() {

    private val vm: BuildViewModel by viewModels()

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        enableEdgeToEdge()
        setContent {
            val ymlPicker = rememberLauncherForActivityResult(ActivityResultContracts.OpenDocument()) { vm.pickYml(it) }
            val projectPicker = rememberLauncherForActivityResult(ActivityResultContracts.OpenMultipleDocuments()) { vm.pickProject(it) }

            MaterialTheme(colorScheme = darkColorScheme(primary = Color(0xFF4F7BFF))) {
                CompositionLocalProvider(LocalLayoutDirection provides LayoutDirection.Rtl) {
                    AppRoot(
                        vm = vm,
                        pickYml = { ymlPicker.launch(arrayOf("*/*")) },
                        pickProject = { projectPicker.launch(arrayOf("application/zip", "application/x-zip-compressed", "application/octet-stream", "*/*")) }
                    )
                }
            }
        }
    }
}
