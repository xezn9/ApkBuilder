package com.apkbuilder.engine

import android.util.Base64
import org.json.JSONArray
import org.json.JSONObject
import java.io.File
import java.net.HttpURLConnection
import java.net.ProtocolException
import java.net.URL

class GitHubException(val code: Int, message: String) : Exception(message)

/** عميل GitHub REST API بدون أي مكتبات خارجية (HttpURLConnection + org.json). */
class GitHubApi(private val token: String) {

    private val base = "https://api.github.com"

    private fun open(url: String, method: String, hasBody: Boolean): HttpURLConnection {
        val c = URL(url).openConnection() as HttpURLConnection
        try {
            c.requestMethod = method
        } catch (e: ProtocolException) {
            // بعض إصدارات HttpURLConnection لا تدعم PATCH
            c.requestMethod = "POST"
            c.setRequestProperty("X-HTTP-Method-Override", method)
        }
        c.setRequestProperty("Authorization", "Bearer $token")
        c.setRequestProperty("Accept", "application/vnd.github+json")
        c.setRequestProperty("X-GitHub-Api-Version", "2022-11-28")
        c.setRequestProperty("User-Agent", "ApkBuilder-Android")
        c.connectTimeout = 20_000
        c.readTimeout = 60_000
        if (hasBody) {
            c.doOutput = true
            c.setRequestProperty("Content-Type", "application/json")
        }
        return c
    }

    private fun friendly(code: Int, body: String): String {
        val msg = runCatching { JSONObject(body).optString("message") }.getOrNull().orEmpty()
        return when (code) {
            401 -> "التوكن غير صالح أو منتهي"
            403 -> if (msg.isNotBlank()) "ممنوع: $msg" else "ممنوع — تحقق من صلاحيات التوكن (repo + workflow)"
            404 -> "غير موجود — تحقق من اسم المستودع وصلاحيات التوكن"
            else -> if (msg.isNotBlank()) msg else "خطأ HTTP $code"
        }
    }

    private fun call(method: String, path: String, body: JSONObject? = null): String {
        val bytes = body?.toString()?.toByteArray(Charsets.UTF_8)
        val c = open(if (path.startsWith("http")) path else base + path, method, bytes != null)
        try {
            if (bytes != null) {
                c.setFixedLengthStreamingMode(bytes.size)
                c.outputStream.use { it.write(bytes) }
            }
            val code = c.responseCode
            val stream = if (code in 200..299) c.inputStream else c.errorStream
            val text = stream?.bufferedReader()?.use { it.readText() }.orEmpty()
            if (code !in 200..299) throw GitHubException(code, friendly(code, text))
            return text
        } finally {
            c.disconnect()
        }
    }

    // ------------------------------------------------------------- الحساب والمستودعات

    fun user(): String = JSONObject(call("GET", "/user")).getString("login")

    /** المستودعات (الأحدث دفعاً أولاً) حتى 300 مستودع. */
    fun repos(): List<String> {
        val out = ArrayList<String>()
        for (page in 1..3) {
            val arr = JSONArray(
                call("GET", "/user/repos?per_page=100&sort=pushed&affiliation=owner,collaborator,organization_member&page=$page")
            )
            for (i in 0 until arr.length()) out.add(arr.getJSONObject(i).getString("full_name"))
            if (arr.length() < 100) break
        }
        return out
    }

    fun defaultBranch(repo: String): String =
        JSONObject(call("GET", "/repos/$repo")).getString("default_branch")

    fun workflows(repo: String): List<GhWorkflow> {
        val arr = JSONObject(call("GET", "/repos/$repo/actions/workflows?per_page=100")).getJSONArray("workflows")
        val out = ArrayList<GhWorkflow>()
        for (i in 0 until arr.length()) {
            val w = arr.getJSONObject(i)
            if (w.optString("state") == "active") out.add(GhWorkflow(w.getLong("id"), w.getString("name"), w.getString("path")))
        }
        return out
    }

    // ------------------------------------------------------------------ رفع الملفات

    /** يرفع الملفات في commit واحد (Git Data API) ويعيد sha الخاص به. */
    fun commitFiles(repo: String, branch: String, files: Map<String, ByteArray>, message: String): String {
        val parentSha = JSONObject(call("GET", "/repos/$repo/git/ref/heads/$branch"))
            .getJSONObject("object").getString("sha")
        val baseTree = JSONObject(call("GET", "/repos/$repo/git/commits/$parentSha"))
            .getJSONObject("tree").getString("sha")

        val tree = JSONArray()
        for ((path, data) in files) {
            val blob = JSONObject()
                .put("content", Base64.encodeToString(data, Base64.NO_WRAP))
                .put("encoding", "base64")
            val sha = JSONObject(call("POST", "/repos/$repo/git/blobs", blob)).getString("sha")
            tree.put(JSONObject().put("path", path).put("mode", "100644").put("type", "blob").put("sha", sha))
        }
        val newTree = JSONObject(
            call("POST", "/repos/$repo/git/trees", JSONObject().put("base_tree", baseTree).put("tree", tree))
        ).getString("sha")
        val commit = JSONObject(
            call(
                "POST", "/repos/$repo/git/commits",
                JSONObject().put("message", message).put("tree", newTree).put("parents", JSONArray().put(parentSha))
            )
        ).getString("sha")
        call("PATCH", "/repos/$repo/git/refs/heads/$branch", JSONObject().put("sha", commit))
        return commit
    }

    // ------------------------------------------------------------------ تشغيل البناء

    fun dispatch(repo: String, workflowId: Long, ref: String) {
        try {
            call("POST", "/repos/$repo/actions/workflows/$workflowId/dispatches", JSONObject().put("ref", ref))
        } catch (e: GitHubException) {
            if (e.code == 422) throw GitHubException(
                422,
                "الـ workflow لا يدعم التشغيل اليدوي — أضف workflow_dispatch: تحت on: في ملف build.yml"
            )
            throw e
        }
    }

    private fun parseRun(o: JSONObject) = GhRun(
        id = o.getLong("id"),
        status = o.optString("status"),
        conclusion = o.optString("conclusion").takeIf { it.isNotBlank() && it != "null" },
        headSha = o.optString("head_sha"),
        htmlUrl = o.optString("html_url"),
        runNumber = o.optInt("run_number")
    )

    fun runs(repo: String, workflowId: Long): List<GhRun> {
        val arr = JSONObject(call("GET", "/repos/$repo/actions/workflows/$workflowId/runs?per_page=10"))
            .getJSONArray("workflow_runs")
        return (0 until arr.length()).map { parseRun(arr.getJSONObject(it)) }
    }

    fun run(repo: String, runId: Long): GhRun =
        parseRun(JSONObject(call("GET", "/repos/$repo/actions/runs/$runId")))

    /** وصف الخطوة الجارية، مثل: «Build debug APK (3/7)». */
    fun currentStep(repo: String, runId: Long): String? {
        val jobs = JSONObject(call("GET", "/repos/$repo/actions/runs/$runId/jobs")).getJSONArray("jobs")
        for (i in 0 until jobs.length()) {
            val j = jobs.getJSONObject(i)
            if (j.optString("status") != "in_progress") continue
            val steps = j.optJSONArray("steps") ?: continue
            for (k in 0 until steps.length()) {
                val s = steps.getJSONObject(k)
                if (s.optString("status") == "in_progress") return "${s.optString("name")} (${k + 1}/${steps.length()})"
            }
            return j.optString("name")
        }
        return null
    }

    fun cancel(repo: String, runId: Long) {
        runCatching { call("POST", "/repos/$repo/actions/runs/$runId/cancel") }
    }

    fun artifacts(repo: String, runId: Long): List<GhArtifact> {
        val arr = JSONObject(call("GET", "/repos/$repo/actions/runs/$runId/artifacts?per_page=100"))
            .getJSONArray("artifacts")
        return (0 until arr.length()).map {
            val a = arr.getJSONObject(it)
            GhArtifact(a.getLong("id"), a.getString("name"), a.optLong("size_in_bytes"), a.optBoolean("expired"))
        }
    }

    fun downloadArtifact(repo: String, artifactId: Long, dest: File) =
        download("$base/repos/$repo/actions/artifacts/$artifactId/zip", dest)

    fun downloadLogs(repo: String, runId: Long, dest: File) =
        download("$base/repos/$repo/actions/runs/$runId/logs", dest)

    /** GitHub يرد بتحويل (302) إلى رابط مؤقت — لا نرسل التوكن إلى الرابط الثاني. */
    private fun download(url: String, dest: File) {
        dest.parentFile?.mkdirs()
        val first = open(url, "GET", false)
        first.instanceFollowRedirects = false
        try {
            val code = first.responseCode
            if (code in 300..399) {
                val loc = first.getHeaderField("Location") ?: throw GitHubException(code, "تحويل بدون عنوان")
                val second = URL(loc).openConnection() as HttpURLConnection
                second.connectTimeout = 20_000
                second.readTimeout = 120_000
                try {
                    if (second.responseCode !in 200..299) throw GitHubException(second.responseCode, "فشل التنزيل (${second.responseCode})")
                    second.inputStream.use { i -> dest.outputStream().use { o -> i.copyTo(o) } }
                } finally {
                    second.disconnect()
                }
            } else if (code in 200..299) {
                first.inputStream.use { i -> dest.outputStream().use { o -> i.copyTo(o) } }
            } else {
                val text = first.errorStream?.bufferedReader()?.use { it.readText() }.orEmpty()
                throw GitHubException(code, friendly(code, text))
            }
        } finally {
            first.disconnect()
        }
    }
}
