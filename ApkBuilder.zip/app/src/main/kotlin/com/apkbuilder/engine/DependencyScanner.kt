package com.apkbuilder.engine

import java.io.File

data class Coord(val group: String, val artifact: String, val version: String?) {
    val ga: String get() = "$group:$artifact"
    override fun toString() = if (version != null) "$group:$artifact:$version" else "$group:$artifact"
}

data class ScanResult(
    val libs: List<Coord>,
    val boms: List<Coord>,
    val repos: List<String>,
    val unresolvedVersions: Int
)

/** يقرأ ملفات gradle / toml في المشروع ويستخرج المكتبات والـ plugins ومستودعات maven. */
object DependencyScanner {

    private val skipDirs = setOf("build", ".gradle", ".git", ".idea", "node_modules")

    private val depLine = Regex(
        """(?:implementation|api|compileOnly|runtimeOnly|debugImplementation|releaseImplementation|""" +
            """testImplementation|androidTestImplementation|kapt|ksp|annotationProcessor|classpath|""" +
            """coreLibraryDesugaring|lintChecks|testRuntimeOnly|testCompileOnly)\s*\(?\s*""" +
            """(platform\(|enforcedPlatform\()?\s*["']([^"']+)["']"""
    )
    private val pluginLine = Regex("""id\s*\(?\s*["']([^"']+)["']\s*\)?\s*version\s*\(?\s*["']([^"']+)["']""")
    private val urlLine = Regex("""url\s*=?\s*(?:uri\()?\s*["'](https?://[^"']+)["']""")
    private val varDef = Regex("""(?:val|var|def|ext\.)?\s*(\w+)\s*=\s*["'](\d[^"']*)["']""")

    fun scan(root: File): ScanResult {
        val libs = LinkedHashMap<String, Coord>()
        val boms = LinkedHashMap<String, Coord>()
        val repos = LinkedHashSet<String>()
        var unresolved = 0

        val vars = HashMap<String, String>()
        val files = root.walkTopDown()
            .onEnter { it.name !in skipDirs }
            .filter { it.isFile }
            .filter {
                val n = it.name
                n.endsWith(".gradle") || n.endsWith(".gradle.kts") || n.endsWith(".toml") || n == "gradle.properties"
            }
            .toList()

        // 1) متغيرات الإصدارات
        for (f in files) {
            if (f.name.endsWith(".toml")) continue
            f.readLines().forEach { l -> varDef.find(l)?.let { vars[it.groupValues[1]] = it.groupValues[2] } }
        }

        fun subst(v: String): String? {
            var out = v
            val ref = Regex("""\$\{?(\w+)\}?""")
            out = ref.replace(out) { m -> vars[m.groupValues[1]] ?: m.value }
            return if (out.contains('$')) null else out
        }

        fun add(into: MutableMap<String, Coord>, c: Coord) {
            into.putIfAbsent("${c.group}:${c.artifact}:${c.version}", c)
        }

        for (f in files) {
            val lines = f.readLines()
            if (f.name.endsWith(".toml")) {
                parseToml(lines, libs)
                continue
            }
            for (l in lines) {
                urlLine.find(l)?.let { repos += it.groupValues[1].trimEnd('/') }
                if (l.contains("jitpack.io")) repos += "https://jitpack.io"

                depLine.find(l)?.let { m ->
                    val isBom = m.groupValues[1].isNotEmpty()
                    val parts = m.groupValues[2].split(":")
                    if (parts.size >= 2 && parts[0].contains('.') && !parts[0].contains(' ')) {
                        val rawV = parts.getOrNull(2)?.takeIf { it.isNotBlank() }
                        val v = rawV?.let { subst(it) }
                        if (rawV != null && v == null) {
                            unresolved++
                        } else {
                            val c = Coord(parts[0], parts[1], v)
                            add(if (isBom) boms else libs, c)
                        }
                    }
                }
                pluginLine.find(l)?.let { m ->
                    val id = m.groupValues[1]
                    val v = subst(m.groupValues[2])
                    if (v != null && !id.startsWith("org.gradle.")) {
                        add(libs, Coord(id, "$id.gradle.plugin", v))
                    }
                }
            }
        }
        return ScanResult(libs.values.toList(), boms.values.toList(), repos.toList(), unresolved)
    }

    private fun parseToml(lines: List<String>, libs: MutableMap<String, Coord>) {
        var section = ""
        val versions = HashMap<String, String>()
        // مرور أول للإصدارات
        for (raw in lines) {
            val l = raw.trim()
            if (l.startsWith("[")) { section = l.trim('[', ']'); continue }
            if (section == "versions") {
                Regex("""([\w.\-]+)\s*=\s*"([^"]+)"""").find(l)?.let { versions[it.groupValues[1]] = it.groupValues[2] }
            }
        }
        section = ""
        fun first(l: String, key: String) = Regex("""\b$key\s*=\s*"([^"]+)"""").find(l)?.groupValues?.get(1)
        for (raw in lines) {
            val l = raw.trim()
            if (l.startsWith("[")) { section = l.trim('[', ']'); continue }
            if (l.isEmpty() || l.startsWith("#") || !l.contains("=")) continue
            if (section != "libraries" && section != "plugins" && section != "bundles") continue
            if (section == "bundles") continue

            val ref = first(l, """version\.ref""")
            val version = ref?.let { versions[it] }
                ?: first(l, "version")
                ?: first(l, "strictly") ?: first(l, "require") ?: first(l, "prefer")

            if (section == "libraries") {
                val module = first(l, "module")
                val group = first(l, "group")
                val name = first(l, "name")
                val plain = Regex("""=\s*"([^":]+):([^":]+)(?::([^"]+))?"""").find(l)
                when {
                    module != null && module.contains(':') -> {
                        val (g, a) = module.split(":", limit = 2)
                        libs.putIfAbsent("$g:$a:$version", Coord(g, a, version))
                    }
                    group != null && name != null ->
                        libs.putIfAbsent("$group:$name:$version", Coord(group, name, version))
                    plain != null && !l.contains("{") ->
                        libs.putIfAbsent(
                            "${plain.groupValues[1]}:${plain.groupValues[2]}:${plain.groupValues[3]}",
                            Coord(plain.groupValues[1], plain.groupValues[2], plain.groupValues[3].ifEmpty { null })
                        )
                }
            } else if (section == "plugins") {
                val id = first(l, "id")
                if (id != null && version != null) {
                    libs.putIfAbsent("$id:$id.gradle.plugin:$version", Coord(id, "$id.gradle.plugin", version))
                }
            }
        }
    }
}
