package com.apkbuilder.engine

import android.content.Context
import android.net.Uri
import android.provider.OpenableColumns
import java.io.File
import java.io.FileOutputStream
import java.util.zip.ZipInputStream

/** يستورد ملف build.yml وملفات المشروع (zip أو ملفات منفصلة) إلى مساحة عمل التطبيق. */
class ProjectImporter(private val context: Context) {

    fun displayName(uri: Uri): String {
        runCatching {
            context.contentResolver.query(uri, null, null, null, null)?.use { c ->
                val idx = c.getColumnIndex(OpenableColumns.DISPLAY_NAME)
                if (idx >= 0 && c.moveToFirst()) return c.getString(idx)
            }
        }
        return uri.lastPathSegment?.substringAfterLast('/') ?: "file"
    }

    fun importWorkflow(uri: Uri, dest: File): String {
        dest.parentFile?.mkdirs()
        context.contentResolver.openInputStream(uri)?.use { input ->
            FileOutputStream(dest).use { input.copyTo(it) }
        } ?: error("تعذر فتح ملف build.yml")
        return dest.readText()
    }

    /** يعيد جذر المشروع (المجلد الذي يحوي settings.gradle). */
    fun importProject(uris: List<Uri>, destDir: File, log: (String) -> Unit): File {
        destDir.deleteRecursively()
        destDir.mkdirs()
        for (uri in uris) {
            val name = displayName(uri)
            if (name.endsWith(".zip", ignoreCase = true)) {
                log("فك ضغط $name …")
                val count = extractZip(uri, destDir)
                log("تم استخراج $count ملف من $name")
            } else {
                val target = File(destDir, name)
                context.contentResolver.openInputStream(uri)?.use { input ->
                    FileOutputStream(target).use { input.copyTo(it) }
                }
                log("نُسخ الملف $name")
            }
        }
        val root = findProjectRoot(destDir)
        File(root, "gradlew").takeIf { it.exists() }?.setExecutable(true, false)
        return root
    }

    private fun extractZip(uri: Uri, destDir: File): Int {
        var count = 0
        val destCanonical = destDir.canonicalPath
        val stream = context.contentResolver.openInputStream(uri) ?: error("تعذر فتح الملف")
        ZipInputStream(stream.buffered()).use { zip ->
            var entry = zip.nextEntry
            while (entry != null) {
                val out = File(destDir, entry.name.replace('\\', '/'))
                // حماية من Zip Slip
                if (!out.canonicalPath.startsWith(destCanonical + File.separator)) {
                    entry = zip.nextEntry
                    continue
                }
                if (entry.isDirectory) {
                    out.mkdirs()
                } else {
                    out.parentFile?.mkdirs()
                    FileOutputStream(out).use { zip.copyTo(it) }
                    count++
                }
                zip.closeEntry()
                entry = zip.nextEntry
            }
        }
        return count
    }

    private fun findProjectRoot(dir: File): File {
        val queue = ArrayDeque<Pair<File, Int>>()
        queue.add(dir to 0)
        while (queue.isNotEmpty()) {
            val (d, depth) = queue.removeFirst()
            val files = d.listFiles() ?: continue
            if (files.any { it.name == "settings.gradle" || it.name == "settings.gradle.kts" }) return d
            if (depth < 4) files.filter { it.isDirectory && !it.name.startsWith(".") }
                .forEach { queue.add(it to depth + 1) }
        }
        // لا يوجد settings.gradle: إذا كان هناك مجلد واحد فقط فهو الجذر
        val children = dir.listFiles().orEmpty()
        return if (children.size == 1 && children[0].isDirectory) children[0] else dir
    }
}
