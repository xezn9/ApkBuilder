package com.apkbuilder.engine

import kotlinx.coroutines.CancellationException
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.currentCoroutineContext
import kotlinx.coroutines.ensureActive
import kotlinx.coroutines.isActive
import kotlinx.coroutines.withContext
import java.io.BufferedReader
import java.io.File
import java.io.InputStreamReader

class BuildResult(val success: Boolean, val artifacts: List<File>)

/**
 * ينفّذ خطوات الـ workflow بنفس منطق GitHub Actions المبسّط:
 *  - `run:`  → يُنفَّذ بالشيل داخل مجلد المشروع
 *  - `uses:` → الإجراءات المعروفة (checkout, setup-java, cache, upload-artifact...) تُعالَج داخل التطبيق
 */
class BuildEngine(
    private val filesRoot: File,        // مجلد التطبيق الخاص
    private val logger: BuildLogger
) {
    val mavenCacheDir = File(filesRoot, "maven-cache")      // دائم ومشترك بين كل المشاريع
    val gradleHomeDir = File(filesRoot, "gradle-home")      // دائم: توزيعات gradle + كاش plugins
    private val tmpDir = File(filesRoot, "tmp")

    private val parser = ErrorParser { logger.error(it) }
    private var failedSoFar = false

    suspend fun resolveLibraries(projectRoot: File) = withContext(Dispatchers.IO) {
        val scan = DependencyScanner.scan(projectRoot)
        logger.log(
            LogLevel.INFO,
            "تم العثور على ${scan.libs.size} مكتبة/plugin و ${scan.boms.size} BOM" +
                if (scan.unresolvedVersions > 0) " (${scan.unresolvedVersions} بإصدار غير مقروء)" else ""
        )
        val cache = MavenCache(mavenCacheDir, scan.repos, logger)
        val ctx = currentCoroutineContext()
        cache.resolveAll(scan) { !ctx.isActive }
        logger.log(
            LogLevel.OK,
            "المكتبات: نُزِّل ${cache.downloaded} ملف جديد، واستُخدم ${cache.reused} من الكاش" +
                (if (cache.failed > 0) "، تعذّر ${cache.failed}" else "") +
                " — حجم الكاش ${cache.sizeBytes() / 1024 / 1024} MB"
        )
        writeGradleInit()
    }

    /** يجعل Gradle يقرأ من كاش التطبيق أولاً (مستودع محلي بأعلى أولوية). */
    private fun writeGradleInit() {
        val initDir = File(gradleHomeDir, "init.d").apply { mkdirs() }
        val path = mavenCacheDir.absolutePath.replace("\\", "/")
        File(initDir, "apkbuilder-cache.gradle").writeText(
            """
            // يُنشأ تلقائياً بواسطة ApkBuilder — كاش المكتبات المشترك
            def apkCache = new File("$path").toURI()
            beforeSettings { settings ->
                settings.pluginManagement.repositories { maven { url apkCache } }
                settings.dependencyResolutionManagement.repositories { maven { url apkCache } }
            }
            allprojects {
                buildscript.repositories { maven { url apkCache } }
                try {
                    def mode = gradle.settings.dependencyResolutionManagement.repositoriesMode.get()
                    if (mode.toString() == "PREFER_PROJECT") { repositories { maven { url apkCache } } }
                } catch (Throwable ignored) { }
            }
            """.trimIndent()
        )
    }

    suspend fun run(workflow: Workflow, projectRoot: File): BuildResult = withContext(Dispatchers.IO) {
        tmpDir.mkdirs()
        val artifacts = ArrayList<File>()
        failedSoFar = false

        checkJava()

        for (step in workflow.steps) {
            currentCoroutineContext().ensureActive()
            if (!shouldRun(step)) {
                logger.log(LogLevel.INFO, "⏭ تخطي: ${step.title} (if: ${step.condition})")
                continue
            }
            logger.status("(${step.index}/${workflow.steps.size}) ${step.title}")
            logger.log(LogLevel.CMD, "▶ ${step.title}")

            val env = baseEnv(projectRoot) + workflow.env + step.env
            val ok = when {
                step.uses != null -> handleUses(step, env, projectRoot, artifacts)
                step.run != null -> runScript(step, env, projectRoot)
                else -> { logger.log(LogLevel.WARN, "خطوة بدون run أو uses"); true }
            }
            if (!ok) {
                failedSoFar = true
                logger.log(LogLevel.ERROR, "✖ فشلت الخطوة: ${step.title}")
                // الخطوات بشرط always()/failure() تستمر، البقية تتوقف
            }
        }
        parser.finish()
        BuildResult(!failedSoFar, artifacts)
    }

    private fun shouldRun(step: WfStep): Boolean {
        val c = step.condition?.trim() ?: return !failedSoFar
        return when {
            c.contains("always()") -> true
            c.contains("failure()") -> failedSoFar
            c.contains("cancelled()") -> false
            c == "false" -> false
            else -> !failedSoFar
        }
    }

    private fun baseEnv(projectRoot: File): Map<String, String> = mapOf(
        "GITHUB_WORKSPACE" to projectRoot.absolutePath,
        "GITHUB_ACTIONS" to "true",
        "CI" to "true",
        "GRADLE_USER_HOME" to gradleHomeDir.absolutePath,
        "APKBUILDER_MAVEN_CACHE" to mavenCacheDir.absolutePath,
        "TMPDIR" to tmpDir.absolutePath,
        "RUNNER_TEMP" to tmpDir.absolutePath
    )

    private fun checkJava() {
        val p = ProcessBuilder("sh", "-c", "command -v java || echo MISSING").redirectErrorStream(true).start()
        val out = p.inputStream.bufferedReader().readText().trim()
        p.waitFor()
        if (out.contains("MISSING") || out.isBlank()) {
            logger.log(
                LogLevel.WARN,
                "لا يوجد JDK في بيئة الجهاز. أوامر gradle/java ستفشل ما لم يتوفر JDK و Android SDK في PATH " +
                    "(مثلاً عبر بيئة Linux/Termux أو خادم بناء). راجع README."
            )
        } else logger.log(LogLevel.INFO, "java: $out")
    }

    // ------------------------------------------------------------ uses:

    private fun handleUses(step: WfStep, env: Map<String, String>, root: File, artifacts: MutableList<File>): Boolean {
        val uses = step.uses!!.substringBefore('@').lowercase()
        when {
            uses == "actions/checkout" ->
                logger.log(LogLevel.INFO, "المشروع موجود مسبقاً في مجلد العمل (تم فك الضغط).")
            uses == "actions/setup-java" ->
                logger.log(LogLevel.INFO, "setup-java: يُستخدم JDK المتوفر في البيئة (المطلوب: ${step.with["java-version"] ?: "?"}).")
            uses.startsWith("gradle/") || uses.startsWith("android-actions/") || uses == "actions/cache" ->
                logger.log(LogLevel.INFO, "${step.uses}: مُعالَج بواسطة كاش التطبيق (maven-cache + gradle-home).")
            uses == "actions/upload-artifact" -> {
                val patterns = step.with["path"].orEmpty().lines().map { it.trim() }.filter { it.isNotEmpty() }
                val found = patterns.flatMap { globFiles(root, it) }
                if (found.isEmpty()) {
                    logger.log(LogLevel.WARN, "upload-artifact: لا توجد ملفات مطابقة لـ ${patterns.joinToString()}")
                } else {
                    artifacts += found
                    found.forEach { logger.log(LogLevel.OK, "ناتج: ${it.relativeTo(root).path}") }
                }
            }
            else -> logger.log(LogLevel.WARN, "الإجراء ${step.uses} غير مدعوم داخل التطبيق — تم تجاوزه.")
        }
        return true
    }

    fun globFiles(root: File, pattern: String): List<File> {
        val pat = pattern.removePrefix("./")
        val regex = Regex(
            pat.replace(".", "\\.").replace("**/", "\u0000").replace("**", ".*")
                .replace("*", "[^/]*").replace("?", "[^/]").replace("\u0000", "(?:.*/)?")
        )
        return root.walkTopDown().filter { it.isFile }
            .filter { regex.matches(it.relativeTo(root).path.replace(File.separatorChar, '/')) }
            .toList()
    }

    // -------------------------------------------------------------- run:

    private suspend fun runScript(step: WfStep, env: Map<String, String>, root: File): Boolean {
        val ws = root.absolutePath
        var script = WorkflowParser.expand(step.run!!, env, ws, tmpDir.absolutePath)
        // لا يمكن تنفيذ ملفات من مجلد التطبيق مباشرة على أندرويد الحديث، لذا نمرّر gradlew عبر sh
        script = script.replace(Regex("""(^|[\s;&|(])\./gradlew\b"""), "$1sh ./gradlew")

        val dir = step.workingDirectory?.let { File(root, WorkflowParser.expand(it, env, ws, tmpDir.absolutePath)) } ?: root
        dir.mkdirs()
        val scriptFile = File(tmpDir, "step_${step.index}.sh").apply { writeText("set -e\n$script\n") }

        val pb = ProcessBuilder("sh", scriptFile.absolutePath)
            .directory(dir)
            .redirectErrorStream(true)
        pb.environment().putAll(env.mapValues { WorkflowParser.expand(it.value, env, ws, tmpDir.absolutePath) })

        val process = try { pb.start() } catch (e: Exception) {
            logger.error(BuildError("تعذر تشغيل الشيل: ${e.message}", scriptFile.absolutePath, null, null, "Shell"))
            return false
        }
        try {
            BufferedReader(InputStreamReader(process.inputStream)).use { r ->
                while (true) {
                    val line = r.readLine() ?: break
                    currentCoroutineContext().ensureActive()
                    val level = when {
                        line.startsWith("e: ") || line.contains("error:", true) || line.startsWith("FAILURE") -> LogLevel.ERROR
                        line.startsWith("w: ") || line.contains("warning:", true) -> LogLevel.WARN
                        line.startsWith("BUILD SUCCESSFUL") -> LogLevel.OK
                        else -> LogLevel.INFO
                    }
                    logger.log(level, line)
                    parser.feed(line)
                }
            }
            val code = process.waitFor()
            parser.finish()
            if (code != 0) logger.log(LogLevel.ERROR, "رمز الخروج: $code")
            return code == 0
        } catch (e: CancellationException) {
            process.destroyForcibly()
            throw e
        }
    }

    /** يجمع ملفات APK الناتجة تلقائياً إن لم يحدد الـ workflow upload-artifact. */
    fun findApks(root: File): List<File> =
        root.walkTopDown().filter { it.isFile && it.extension == "apk" && "build/outputs" in it.path.replace('\\', '/') }.toList()
}
