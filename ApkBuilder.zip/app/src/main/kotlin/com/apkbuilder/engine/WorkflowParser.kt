package com.apkbuilder.engine

import org.snakeyaml.engine.v2.api.Load
import org.snakeyaml.engine.v2.api.LoadSettings
import org.snakeyaml.engine.v2.exceptions.MarkedYamlEngineException
import org.snakeyaml.engine.v2.exceptions.YamlEngineException

data class WfStep(
    val index: Int,
    val job: String,
    val name: String?,
    val run: String?,
    val uses: String?,
    val with: Map<String, String>,
    val env: Map<String, String>,
    val workingDirectory: String?,
    val condition: String?
) {
    val title: String get() = name ?: uses ?: run?.lineSequence()?.firstOrNull()?.take(60) ?: "step $index"
}

data class Workflow(val name: String, val env: Map<String, String>, val steps: List<WfStep>)

class WorkflowParseException(
    message: String,
    val line: Int?,
    val column: Int?
) : Exception(message)

object WorkflowParser {

    fun parse(text: String): Workflow {
        val root: Any? = try {
            Load(LoadSettings.builder().build()).loadFromString(text)
        } catch (e: MarkedYamlEngineException) {
            val mark = e.problemMark.orElse(null) ?: e.contextMark.orElse(null)
            throw WorkflowParseException(
                e.problem ?: e.message ?: "YAML غير صالح",
                mark?.line?.plus(1),
                mark?.column?.plus(1)
            )
        } catch (e: YamlEngineException) {
            throw WorkflowParseException(e.message ?: "YAML غير صالح", null, null)
        }

        val map = root as? Map<*, *>
            ?: throw WorkflowParseException("ملف build.yml فارغ أو ليس بصيغة YAML صحيحة (المطلوب: mapping)", 1, 1)

        val jobs = map["jobs"] as? Map<*, *>
            ?: throw WorkflowParseException("لا يوجد قسم jobs: في ملف build.yml", null, null)

        val globalEnv = stringMap(map["env"])
        val steps = ArrayList<WfStep>()
        var i = 0
        for ((jobId, jobAny) in jobs) {
            val job = jobAny as? Map<*, *> ?: continue
            val jobEnv = globalEnv + stringMap(job["env"])
            val jobSteps = job["steps"] as? List<*> ?: continue
            for (s in jobSteps) {
                val st = s as? Map<*, *> ?: continue
                i++
                steps += WfStep(
                    index = i,
                    job = jobId.toString(),
                    name = st["name"]?.toString(),
                    run = st["run"]?.toString(),
                    uses = st["uses"]?.toString(),
                    with = stringMap(st["with"]),
                    env = jobEnv + stringMap(st["env"]),
                    workingDirectory = st["working-directory"]?.toString(),
                    condition = st["if"]?.toString()
                )
            }
        }
        if (steps.isEmpty()) {
            throw WorkflowParseException("لا توجد خطوات steps: داخل الـ jobs", null, null)
        }
        return Workflow(map["name"]?.toString() ?: "workflow", globalEnv, steps)
    }

    private fun stringMap(any: Any?): Map<String, String> {
        val m = any as? Map<*, *> ?: return emptyMap()
        return m.entries.associate { it.key.toString() to (it.value?.toString() ?: "") }
    }

    private val expr = Regex("""\$\{\{\s*(.*?)\s*\}\}""")

    /** يستبدل تعابير ${{ }} البسيطة. غير المعروف يصبح نصاً فارغاً. */
    fun expand(text: String, env: Map<String, String>, workspace: String, tmp: String): String =
        expr.replace(text) { m ->
            val key = m.groupValues[1]
            when {
                key == "github.workspace" -> workspace
                key == "runner.os" -> "Linux"
                key == "runner.temp" -> tmp
                key == "github.run_number" -> "1"
                key.startsWith("env.") -> env[key.removePrefix("env.")] ?: ""
                else -> ""
            }
        }
}
