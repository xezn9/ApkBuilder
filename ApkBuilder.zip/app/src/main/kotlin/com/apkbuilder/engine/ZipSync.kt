package com.apkbuilder.engine

import org.json.JSONObject
import java.io.ByteArrayOutputStream
import java.security.MessageDigest
import java.util.zip.ZipEntry
import java.util.zip.ZipOutputStream

/**
 * خطة رفع مشروع مختار كـ zip.
 *
 * @param upload كل ما يجب أن يكون في المستودع (المسار الكامل ← المحتوى). الملفات التي لم تتغير تبقى هنا
 *   (حتى لا تُحذف) لكنها لا تُرسل فعلياً: [GitHubApi.commitFiles] يتخطاها بمقارنة الـ sha.
 * @param replaceDirs مجلدات يُحذف منها أي ملف قديم غير موجود في [upload].
 * @param incremental true = الأساس (zip) موجود أصلاً في المستودع ونرفع الفروقات فقط.
 */
class ZipPlan(
    val upload: Map<String, ByteArray>,
    val replaceDirs: List<String>,
    val incremental: Boolean,
    val total: Int,
    val changed: Int,
    val deleted: Int,
    val pendingFiles: Int,
    val pendingBytes: Long
)

/** بصمة المشروع المحفوظ كأساس في المستودع: مسار كل ملف ← sha (بنفس صيغة git blob). */
class BaseManifest(val files: Map<String, String>, val parts: Int, val bytes: Long) {
    fun toJson(): String = JSONObject()
        .put("v", 1).put("parts", parts).put("bytes", bytes)
        .put("files", JSONObject(files))
        .toString()
}

/**
 * يرفع المشروع كملف zip (مقسوم إلى أجزاء) ويُفك أثناء البناء على GitHub، وفي البناءات التالية
 * يقارن الملفات بما هو موجود في المستودع ويرفع **الملفات المتغيرة فقط** (مثل git).
 *
 * التخطيط داخل المستودع:
 *   .apkbuilder/base/part-000, part-001 …   أجزاء الـ zip الأساسي (4MB لكل جزء ليمكن الاستئناف)
 *   .apkbuilder/state/base.json             بصمة الأساس (path ← sha)
 *   .apkbuilder/overlay/<path>              الملفات التي تغيرت/أُضيفت بعد الأساس
 *   .apkbuilder/state/deleted.txt           الملفات التي حُذفت بعد الأساس
 * وأثناء البناء: الأساس يُفك في project/ ثم يُنسخ overlay فوقه وتُحذف الملفات المذكورة في deleted.txt.
 */
object ZipSync {

    const val BASE_DIR = ".apkbuilder/base"
    const val OVERLAY_DIR = ".apkbuilder/overlay"
    const val STATE_DIR = ".apkbuilder/state"
    const val MANIFEST_PATH = "$STATE_DIR/base.json"
    const val DELETED_PATH = "$STATE_DIR/deleted.txt"

    /** حجم الجزء الواحد — الاستئناف بعد انقطاع الإنترنت يكون على مستوى الجزء. */
    const val PART_SIZE = 4 * 1024 * 1024

    /** إن زادت الفروقات عن هذا الحد (عدداً أو حجماً) نستبدل الأساس بدل تكديس overlay ضخم. */
    private const val MAX_OVERLAY_FILES = 1500

    /** تاريخ ثابت داخل الـ zip ليخرج الأرشيف نفسه كل مرة لنفس المحتوى (مهم للاستئناف). */
    private const val FIXED_TIME = 315_532_800_000L

    /** sha بنفس طريقة git: SHA-1 لـ "blob <size>\0<content>". */
    fun gitSha(data: ByteArray): String {
        val md = MessageDigest.getInstance("SHA-1")
        md.update("blob ${data.size}\u0000".toByteArray(Charsets.US_ASCII))
        md.update(data)
        return md.digest().joinToString("") { "%02x".format(it) }
    }

    fun partPath(i: Int) = "$BASE_DIR/part-${i.toString().padStart(3, '0')}"

    fun buildZip(files: Map<String, ByteArray>): ByteArray {
        val bos = ByteArrayOutputStream()
        ZipOutputStream(bos).use { z ->
            for (path in files.keys.sorted()) {
                val e = ZipEntry(path)
                e.time = FIXED_TIME
                z.putNextEntry(e)
                z.write(files.getValue(path))
                z.closeEntry()
            }
        }
        return bos.toByteArray()
    }

    private fun split(b: ByteArray): List<ByteArray> {
        if (b.size <= PART_SIZE) return listOf(b)
        return (0 until b.size step PART_SIZE).map { b.copyOfRange(it, minOf(it + PART_SIZE, b.size)) }
    }

    fun parseManifest(text: String): BaseManifest? = runCatching {
        val o = JSONObject(text)
        if (o.optInt("v") != 1) return@runCatching null
        val f = o.getJSONObject("files")
        val map = LinkedHashMap<String, String>()
        f.keys().forEach { k -> map[k] = f.getString(k) }
        BaseManifest(map, o.getInt("parts"), o.optLong("bytes"))
    }.getOrNull()

    /**
     * @param files محتوى المشروع الحالي (بعد التنظيف) — مساراته نسبية لجذر المشروع.
     * @param remoteTree كل ملفات المستودع (مسار ← sha) أو null إن تعذر معرفتها (مستودع ضخم).
     * @param remoteManifestText نص بصمة الأساس الموجودة في المستودع إن وُجدت.
     * @param legacyDir مجلد قديم (project) كانت النسخ السابقة من التطبيق ترفع المشروع المفكوك فيه — نحذفه.
     */
    fun plan(
        files: Map<String, ByteArray>,
        remoteTree: Map<String, String>?,
        remoteManifestText: String?,
        legacyDir: String
    ): ZipPlan {
        val localShas = LinkedHashMap<String, String>()
        for ((p, d) in files) localShas[p] = gitSha(d)

        val manifest = remoteManifestText?.let { parseManifest(it) }
        val baseOk = manifest != null && remoteTree != null &&
            remoteTree.containsKey(MANIFEST_PATH) &&
            (0 until manifest.parts).all { remoteTree.containsKey(partPath(it)) }

        var changed = emptyList<String>()
        var deleted = emptyList<String>()
        var incremental = false
        if (baseOk && manifest != null) {
            changed = files.keys.filter { manifest.files[it] != localShas[it] }
            deleted = manifest.files.keys.filter { it !in files }
            val changedBytes = changed.sumOf { files.getValue(it).size.toLong() }
            incremental = changed.size <= MAX_OVERLAY_FILES && changedBytes * 2 <= maxOf(manifest.bytes, 1L)
        }

        val out = LinkedHashMap<String, ByteArray>()
        val dirs: List<String>
        if (incremental && remoteManifestText != null) {
            out[MANIFEST_PATH] = remoteManifestText.toByteArray(Charsets.UTF_8)
            for (p in changed) out["$OVERLAY_DIR/$p"] = files.getValue(p)
            if (deleted.isNotEmpty()) out[DELETED_PATH] = deleted.joinToString("\n").toByteArray(Charsets.UTF_8)
            dirs = listOf(OVERLAY_DIR, STATE_DIR, legacyDir)
        } else {
            val parts = split(buildZip(files))
            parts.forEachIndexed { i, b -> out[partPath(i)] = b }
            val m = BaseManifest(localShas, parts.size, files.values.sumOf { it.size.toLong() })
            out[MANIFEST_PATH] = m.toJson().toByteArray(Charsets.UTF_8)
            dirs = listOf(BASE_DIR, OVERLAY_DIR, STATE_DIR, legacyDir)
        }

        var pf = 0
        var pb = 0L
        for ((p, d) in out) {
            if (remoteTree == null || remoteTree[p] != gitSha(d)) { pf++; pb += d.size }
        }
        return ZipPlan(
            upload = out, replaceDirs = dirs, incremental = incremental,
            total = files.size, changed = if (incremental) changed.size else files.size,
            deleted = deleted.size, pendingFiles = pf, pendingBytes = pb
        )
    }
}
