package com.apkbuilder.engine

import org.json.JSONObject
import org.w3c.dom.Element
import org.w3c.dom.Node
import java.io.File
import java.net.HttpURLConnection
import java.net.URL
import javax.xml.parsers.DocumentBuilderFactory

/**
 * كاش مكتبات دائم بصيغة Maven repository.
 * أي مكتبة تُنزَّل مرة واحدة وتبقى في [root]، ثم تُستخدم مباشرة من أي مشروع آخر.
 * الملفات الناقصة فقط هي التي تُنزَّل.
 */
class MavenCache(
    val root: File,
    extraRepos: List<String>,
    private val logger: BuildLogger
) {
    var downloaded = 0; private set
    var reused = 0; private set
    var failed = 0; private set

    private val repos: List<String> = (
        listOf(
            "https://dl.google.com/dl/android/maven2",
            "https://repo1.maven.org/maven2",
            "https://plugins.gradle.org/m2"
        ) + extraRepos
        ).distinct()

    private val managed = HashMap<String, String>() // "group:artifact" -> version (من BOM)
    private val visited = HashSet<String>()

    init { root.mkdirs() }

    // ------------------------------------------------------------------ API

    fun resolveAll(scan: ScanResult, isCancelled: () -> Boolean) {
        // BOM أولاً حتى تُحَل المكتبات بدون إصدار
        for (bom in scan.boms) {
            if (isCancelled()) return
            val v = bom.version ?: continue
            loadManagedVersions(bom.group, bom.artifact, v)
            resolve(Coord(bom.group, bom.artifact, v), 0)
        }
        for (lib in scan.libs) {
            if (isCancelled()) return
            val v = lib.version ?: managed[lib.ga]
            if (v == null) {
                logger.log(LogLevel.WARN, "تخطي ${lib.ga}: لا يوجد إصدار محدد")
                continue
            }
            resolve(Coord(lib.group, lib.artifact, v), 0)
        }
    }

    fun sizeBytes(): Long = root.walkTopDown().filter { it.isFile }.sumOf { it.length() }

    // ------------------------------------------------------------ resolution

    private fun resolve(c: Coord, depth: Int) {
        val version = cleanVersion(c.version ?: managed[c.ga]) ?: return
        val key = "${c.group}:${c.artifact}:$version"
        if (!visited.add(key) || depth > 6) return

        val pom = ensure(c.group, c.artifact, version, "pom", optional = false)
        val module = ensure(c.group, c.artifact, version, "module", optional = true)
        if (pom == null && module == null) {
            failed++
            logger.log(LogLevel.WARN, "تعذر إيجاد $key في أي مستودع")
            return
        }

        val info = pom?.let { loadPom(c.group, c.artifact, version) }
        if (info != null) {
            when (info.packaging) {
                "aar" -> ensure(c.group, c.artifact, version, "aar", optional = false)
                "pom" -> Unit
                else -> ensure(c.group, c.artifact, version, "jar", optional = module != null)
            }
        }

        if (module != null) resolveModule(module, depth)

        info?.deps?.forEach { d ->
            if (d.optional || (d.scope != null && d.scope != "compile" && d.scope != "runtime")) return@forEach
            resolve(Coord(d.group, d.artifact, d.version), depth + 1)
        }
    }

    private fun resolveModule(moduleFile: File, depth: Int) {
        val json = runCatching { JSONObject(moduleFile.readText()) }.getOrNull() ?: return
        val variants = json.optJSONArray("variants") ?: return
        val dir = moduleFile.parentFile!!
        val coordDir = relativeDir(dir)

        for (i in 0 until variants.length()) {
            val v = variants.getJSONObject(i)
            val name = v.optString("name").lowercase()
            if (name.contains("sources") || name.contains("javadoc")) continue
            val attrs = v.optJSONObject("attributes")
            val platform = attrs?.optString("org.jetbrains.kotlin.platform.type").orEmpty()
            val relevantPlatform = platform.isEmpty() || platform == "jvm" || platform == "androidJvm"
            if (!relevantPlatform) continue

            v.optJSONObject("available-at")?.let { at ->
                resolve(Coord(at.getString("group"), at.getString("module"), at.getString("version")), depth + 1)
            }

            val files = v.optJSONArray("files")
            if (files != null) for (j in 0 until files.length()) {
                val f = files.getJSONObject(j)
                val url = f.optString("url")
                if (url.endsWith(".aar") || url.endsWith(".jar")) {
                    ensurePath("$coordDir/$url", optional = true)
                }
            }

            val deps = v.optJSONArray("dependencies")
            if (deps != null && (name.contains("api") || name.contains("runtime"))) {
                for (j in 0 until deps.length()) {
                    val d = deps.getJSONObject(j)
                    val ver = d.optJSONObject("version")
                    val vv = ver?.optString("requires")?.ifEmpty { null }
                        ?: ver?.optString("strictly")?.ifEmpty { null }
                        ?: ver?.optString("prefer")?.ifEmpty { null }
                    resolve(Coord(d.getString("group"), d.getString("module"), vv), depth + 1)
                }
            }
        }
    }

    // -------------------------------------------------------------- POM

    private data class PomDep(
        val group: String, val artifact: String, val version: String?,
        val scope: String?, val optional: Boolean
    )

    private data class PomInfo(
        val packaging: String,
        val props: Map<String, String>,
        val mgmt: Map<String, String>,
        val deps: List<PomDep>
    )

    private val pomCache = HashMap<String, PomInfo?>()

    private fun loadPom(g: String, a: String, v: String, depth: Int = 0): PomInfo? {
        val key = "$g:$a:$v"
        if (pomCache.containsKey(key)) return pomCache[key]
        val file = ensure(g, a, v, "pom", optional = true)
        if (file == null || depth > 5) { pomCache[key] = null; return null }
        val result = runCatching { parsePom(file, g, a, v, depth) }.getOrNull()
        pomCache[key] = result
        return result
    }

    private fun parsePom(file: File, g: String, a: String, v: String, depth: Int): PomInfo {
        val dbf = DocumentBuilderFactory.newInstance()
        val doc = dbf.newDocumentBuilder().parse(file)
        val project = doc.documentElement

        var parentProps = emptyMap<String, String>()
        var parentMgmt = emptyMap<String, String>()
        child(project, "parent")?.let { p ->
            val pg = text(p, "groupId"); val pa = text(p, "artifactId"); val pv = text(p, "version")
            if (pg != null && pa != null && pv != null) {
                loadPom(pg, pa, pv, depth + 1)?.let { parentProps = it.props; parentMgmt = it.mgmt }
            }
        }

        val props = HashMap(parentProps)
        props["project.version"] = text(project, "version") ?: v
        props["project.groupId"] = text(project, "groupId") ?: g
        props["project.artifactId"] = a
        child(project, "properties")?.let { pr ->
            elements(pr).forEach { props[it.tagName] = it.textContent.trim() }
        }
        fun sub(s: String?): String? {
            if (s == null) return null
            var out = s.trim()
            repeat(3) { out = Regex("""\$\{([^}]+)\}""").replace(out) { m -> props[m.groupValues[1]] ?: m.value } }
            return out
        }

        val mgmt = HashMap(parentMgmt)
        child(child(project, "dependencyManagement"), "dependencies")?.let { ds ->
            for (d in elements(ds, "dependency")) {
                val dg = sub(text(d, "groupId")); val da = sub(text(d, "artifactId")); val dv = sub(text(d, "version"))
                if (dg != null && da != null && dv != null) {
                    mgmt["$dg:$da"] = dv
                    if (text(d, "scope") == "import") {
                        // BOM مستورد
                        loadPom(dg, da, dv, depth + 1)?.let { mgmt.putAll(it.mgmt) }
                    }
                }
            }
        }

        val deps = ArrayList<PomDep>()
        child(project, "dependencies")?.let { ds ->
            for (d in elements(ds, "dependency")) {
                val dg = sub(text(d, "groupId")) ?: continue
                val da = sub(text(d, "artifactId")) ?: continue
                val dv = sub(text(d, "version")) ?: mgmt["$dg:$da"]
                deps += PomDep(dg, da, dv, text(d, "scope"), text(d, "optional") == "true")
            }
        }
        val packaging = text(project, "packaging") ?: "jar"
        return PomInfo(if (packaging == "bundle") "jar" else packaging, props, mgmt, deps)
    }

    private fun loadManagedVersions(g: String, a: String, v: String) {
        loadPom(g, a, v)?.mgmt?.forEach { (k, ver) -> managed.putIfAbsent(k, ver) }
    }

    // --------------------------------------------------------- XML helpers

    private fun child(parent: Element?, name: String): Element? {
        if (parent == null) return null
        var n: Node? = parent.firstChild
        while (n != null) {
            if (n is Element && n.tagName == name) return n
            n = n.nextSibling
        }
        return null
    }

    private fun elements(parent: Element, name: String? = null): List<Element> {
        val out = ArrayList<Element>()
        var n: Node? = parent.firstChild
        while (n != null) {
            if (n is Element && (name == null || n.tagName == name)) out += n
            n = n.nextSibling
        }
        return out
    }

    private fun text(parent: Element, name: String): String? =
        child(parent, name)?.textContent?.trim()?.ifEmpty { null }

    // ---------------------------------------------------------- download

    private fun relativeDir(dir: File): String = dir.relativeTo(root).path.replace(File.separatorChar, '/')

    private fun ensure(g: String, a: String, v: String, ext: String, optional: Boolean): File? =
        ensurePath("${g.replace('.', '/')}/$a/$v/$a-$v.$ext", optional)

    private fun ensurePath(path: String, optional: Boolean): File? {
        val dest = File(root, path)
        if (dest.exists() && dest.length() > 0) { reused++; return dest }
        val missing = File(root, "$path.missing")
        if (missing.exists()) return null

        dest.parentFile?.mkdirs()
        for (repo in repos) {
            if (download("$repo/$path", dest)) {
                downloaded++
                logger.log(LogLevel.INFO, "⬇ $path")
                return dest
            }
        }
        if (optional) runCatching { missing.writeText("") }
        else logger.log(LogLevel.WARN, "غير موجود: $path")
        return null
    }

    private fun download(url: String, dest: File): Boolean {
        val tmp = File(dest.parentFile, dest.name + ".part")
        return try {
            var current = url
            var conn: HttpURLConnection
            var hops = 0
            while (true) {
                conn = URL(current).openConnection() as HttpURLConnection
                conn.connectTimeout = 15_000
                conn.readTimeout = 30_000
                conn.instanceFollowRedirects = false
                conn.setRequestProperty("User-Agent", "ApkBuilder/1.0")
                val code = conn.responseCode
                if (code in 300..399 && hops < 5) {
                    current = URL(URL(current), conn.getHeaderField("Location")).toString()
                    conn.disconnect(); hops++; continue
                }
                if (code != 200) { conn.disconnect(); return false }
                break
            }
            conn.inputStream.use { input -> tmp.outputStream().use { input.copyTo(it) } }
            conn.disconnect()
            tmp.renameTo(dest)
        } catch (e: Exception) {
            tmp.delete()
            false
        }
    }

    private fun cleanVersion(v: String?): String? {
        if (v == null) return null
        val t = v.trim()
        if (t.isEmpty() || t.endsWith("+")) return null
        if (t.startsWith("[") || t.startsWith("(")) {
            return t.trim('[', ']', '(', ')').split(",").firstOrNull()?.trim()?.ifEmpty { null }
        }
        return t
    }
}
