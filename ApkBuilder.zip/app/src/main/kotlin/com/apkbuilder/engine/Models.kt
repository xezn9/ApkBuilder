package com.apkbuilder.engine

enum class LogLevel { INFO, OK, WARN, ERROR, CMD }

data class LogLine(
    val level: LogLevel,
    val text: String,
    val time: Long = System.currentTimeMillis()
)

/** خطأ بناء مُحلَّل: نص الخطأ + مكانه (الملف) + السطر + العمود إن وُجد. */
data class BuildError(
    val message: String,
    val file: String?,
    val line: Int?,
    val column: Int?,
    val source: String
) {
    val key: String get() = "$file:$line:$column:$message"

    val location: String
        get() = buildString {
            append(file ?: "—")
            if (line != null) append(":").append(line)
            if (column != null) append(":").append(column)
        }
}

enum class Phase { IDLE, IMPORTING, RESOLVING, BUILDING, SUCCESS, FAILED, CANCELLED }

interface BuildLogger {
    fun log(level: LogLevel, text: String)
    fun error(error: BuildError)
    fun status(text: String)
}
