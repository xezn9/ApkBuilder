package com.apkbuilder.ui

import android.content.ClipData
import android.content.ClipboardManager
import android.content.Context
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.interaction.MutableInteractionSource
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.navigationBarsPadding
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.statusBarsPadding
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.lazy.rememberLazyListState
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.BugReport
import androidx.compose.material.icons.filled.Build
import androidx.compose.material.icons.filled.ContentCopy
import androidx.compose.material.icons.filled.DeleteSweep
import androidx.compose.material.icons.filled.Description
import androidx.compose.material.icons.filled.FolderZip
import androidx.compose.material.icons.filled.PlayArrow
import androidx.compose.material.icons.filled.Stop
import androidx.compose.material3.CircularProgressIndicator
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.font.FontFamily
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.apkbuilder.BuildViewModel
import com.apkbuilder.engine.LogLevel
import com.apkbuilder.engine.Phase
import com.kyant.backdrop.Backdrop

private enum class Tab { BUILD, LOG }
private enum class LogView { ERRORS, FULL }

private val Ok = Color(0xFF3DDC97)
private val Bad = Color(0xFFFF5C6C)
private val Warn = Color(0xFFFFC857)
private val Blue = Color(0xFF4F7BFF)

@Composable
fun AppRoot(
    vm: BuildViewModel,
    pickYml: () -> Unit,
    pickProject: () -> Unit
) {
    var tab by remember { mutableStateOf(Tab.BUILD) }

    // عند الفشل ننتقل تلقائياً لصفحة السجل
    LaunchedEffect(vm.phase) { if (vm.phase == Phase.FAILED) tab = Tab.LOG }

    GlassScene { backdrop ->
        Box(Modifier.fillMaxSize()) {
            when (tab) {
                Tab.BUILD -> BuildScreen(vm, backdrop, pickYml, pickProject)
                Tab.LOG -> LogScreen(vm, backdrop)
            }
            BottomBar(
                backdrop = backdrop,
                selected = tab,
                errorCount = vm.errors.size,
                onSelect = { tab = it },
                modifier = Modifier.align(Alignment.BottomCenter)
            )
        }
    }
}

@Composable
private fun BottomBar(
    backdrop: Backdrop,
    selected: Tab,
    errorCount: Int,
    onSelect: (Tab) -> Unit,
    modifier: Modifier = Modifier
) {
    Row(
        modifier
            .navigationBarsPadding()
            .padding(horizontal = 40.dp, vertical = 14.dp)
            .fillMaxWidth()
            .liquidGlass(backdrop, radius = 36.dp, tint = Color.White.copy(alpha = 0.06f), blurRadius = 10.dp)
            .padding(6.dp),
        horizontalArrangement = Arrangement.spacedBy(6.dp)
    ) {
        BarItem(backdrop, "البناء", Icons.Filled.Build, selected == Tab.BUILD, Modifier.weight(1f)) { onSelect(Tab.BUILD) }
        BarItem(
            backdrop,
            if (errorCount > 0) "السجل ($errorCount)" else "السجل",
            Icons.Filled.BugReport,
            selected == Tab.LOG,
            Modifier.weight(1f)
        ) { onSelect(Tab.LOG) }
    }
}

@Composable
private fun BarItem(
    backdrop: Backdrop,
    label: String,
    icon: androidx.compose.ui.graphics.vector.ImageVector,
    active: Boolean,
    modifier: Modifier,
    onClick: () -> Unit
) {
    Box(
        modifier
            .liquidGlass(
                backdrop, radius = 30.dp,
                tint = if (active) Blue.copy(alpha = 0.40f) else Color.Transparent,
                refraction = active, blurRadius = 4.dp
            )
            .clickable(interactionSource = remember { MutableInteractionSource() }, indication = null, onClick = onClick)
            .padding(vertical = 12.dp),
        contentAlignment = Alignment.Center
    ) {
        Row(verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.spacedBy(8.dp)) {
            androidx.compose.material3.Icon(icon, null, tint = Color.White, modifier = Modifier.height(20.dp))
            Text(label, color = Color.White, fontSize = 14.sp, fontWeight = FontWeight.SemiBold)
        }
    }
}

// =============================================================== صفحة البناء

@Composable
private fun BuildScreen(
    vm: BuildViewModel,
    backdrop: Backdrop,
    pickYml: () -> Unit,
    pickProject: () -> Unit
) {
    Column(
        Modifier
            .fillMaxSize()
            .statusBarsPadding()
            .verticalScroll(rememberScrollState())
            .padding(horizontal = 20.dp)
            .padding(top = 20.dp, bottom = 120.dp),
        verticalArrangement = Arrangement.spacedBy(16.dp)
    ) {
        Column {
            Text("ApkBuilder", color = Color.White, fontSize = 34.sp, fontWeight = FontWeight.Bold)
            Text("ابنِ تطبيقات أندرويد من build.yml وملفات المشروع", color = Color.White.copy(alpha = 0.7f), fontSize = 14.sp)
        }

        GlassButton(
            backdrop, "اختيار ملف build.yml", Icons.Filled.Description, pickYml,
            Modifier.fillMaxWidth(), enabled = !vm.isRunning
        )
        PickedLabel(vm.ymlName?.let { "✓ $it" } ?: "لم يُختر ملف بعد")

        GlassButton(
            backdrop, "اختيار ملفات المشروع (zip)", Icons.Filled.FolderZip, pickProject,
            Modifier.fillMaxWidth(), enabled = !vm.isRunning
        )
        PickedLabel(
            if (vm.projectNames.isEmpty()) "لم تُختر ملفات بعد"
            else "✓ " + vm.projectNames.take(3).joinToString("، ") +
                if (vm.projectNames.size > 3) " (+${vm.projectNames.size - 3})" else ""
        )

        if (vm.isRunning) {
            GlassButton(backdrop, "إيقاف البناء", Icons.Filled.Stop, vm::cancel, Modifier.fillMaxWidth(), accent = Bad)
        } else {
            GlassButton(
                backdrop, "ابدأ البناء", Icons.Filled.PlayArrow, vm::start, Modifier.fillMaxWidth(),
                accent = Blue, enabled = vm.ymlUri != null && vm.projectUris.isNotEmpty()
            )
        }

        StatusCard(vm, backdrop)

        if (vm.savedApks.isNotEmpty()) {
            GlassCard(backdrop, Modifier.fillMaxWidth(), tint = Ok.copy(alpha = 0.16f)) {
                Text("ملفات APK الناتجة", color = Color.White, fontWeight = FontWeight.Bold, fontSize = 16.sp)
                vm.savedApks.forEach {
                    Text(it, color = Color.White.copy(alpha = 0.85f), fontSize = 13.sp, fontFamily = FontFamily.Monospace, modifier = Modifier.padding(top = 6.dp))
                }
            }
        }

        GlassCard(backdrop, Modifier.fillMaxWidth()) {
            Text("كاش المكتبات المشترك", color = Color.White, fontWeight = FontWeight.Bold, fontSize = 16.sp)
            Text(
                "الحجم الحالي: ${vm.cacheMb} MB — المكتبة تُنزَّل مرة واحدة فقط ثم تُستخدم في كل مشروع.",
                color = Color.White.copy(alpha = 0.75f), fontSize = 13.sp, modifier = Modifier.padding(vertical = 8.dp)
            )
            GlassButton(
                backdrop, "مسح الكاش", Icons.Filled.DeleteSweep, vm::clearCache,
                Modifier.fillMaxWidth(), enabled = !vm.isRunning, radius = 20.dp
            )
        }
    }
}

@Composable
private fun PickedLabel(text: String) {
    Text(text, color = Color.White.copy(alpha = 0.75f), fontSize = 13.sp, modifier = Modifier.padding(horizontal = 8.dp))
}

@Composable
private fun StatusCard(vm: BuildViewModel, backdrop: Backdrop) {
    val (tint, title) = when (vm.phase) {
        Phase.IDLE -> Color.White.copy(alpha = 0.08f) to "الحالة"
        Phase.SUCCESS -> Ok.copy(alpha = 0.22f) to "نجح البناء"
        Phase.FAILED -> Bad.copy(alpha = 0.22f) to "فشل البناء"
        Phase.CANCELLED -> Warn.copy(alpha = 0.18f) to "أُلغي"
        else -> Blue.copy(alpha = 0.18f) to "جاري العمل"
    }
    GlassCard(backdrop, Modifier.fillMaxWidth(), tint = tint) {
        Row(verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.spacedBy(12.dp)) {
            if (vm.isRunning) CircularProgressIndicator(color = Color.White, strokeWidth = 2.5.dp, modifier = Modifier.height(22.dp))
            Column {
                Text(title, color = Color.White, fontWeight = FontWeight.Bold, fontSize = 16.sp)
                Text(vm.statusText, color = Color.White.copy(alpha = 0.85f), fontSize = 14.sp)
            }
        }
        if (vm.errors.isNotEmpty()) {
            Text(
                "${vm.errors.size} خطأ — افتح تبويب «السجل» للتفاصيل",
                color = Bad.copy(alpha = 1f), fontSize = 13.sp, fontWeight = FontWeight.SemiBold,
                modifier = Modifier.padding(top = 10.dp)
            )
        }
    }
}

// ============================================================== صفحة السجل

@Composable
private fun LogScreen(vm: BuildViewModel, backdrop: Backdrop) {
    var view by remember { mutableStateOf(LogView.ERRORS) }
    val ctx = LocalContext.current

    Column(
        Modifier
            .fillMaxSize()
            .statusBarsPadding()
            .padding(horizontal = 20.dp)
            .padding(top = 20.dp)
    ) {
        Text("السجل", color = Color.White, fontSize = 30.sp, fontWeight = FontWeight.Bold)

        Row(Modifier.padding(vertical = 14.dp), horizontalArrangement = Arrangement.spacedBy(10.dp)) {
            GlassButton(
                backdrop, "الأخطاء (${vm.errors.size})", null, { view = LogView.ERRORS },
                Modifier.weight(1f), accent = if (view == LogView.ERRORS) Bad else null, radius = 22.dp,
                contentPadding = androidx.compose.foundation.layout.PaddingValues(12.dp)
            )
            GlassButton(
                backdrop, "السجل الكامل", null, { view = LogView.FULL },
                Modifier.weight(1f), accent = if (view == LogView.FULL) Blue else null, radius = 22.dp,
                contentPadding = androidx.compose.foundation.layout.PaddingValues(12.dp)
            )
            GlassButton(
                backdrop, "نسخ", Icons.Filled.ContentCopy,
                { copy(ctx, if (view == LogView.ERRORS) vm.errorsAsText() else vm.logAsText()) },
                radius = 22.dp, contentPadding = androidx.compose.foundation.layout.PaddingValues(horizontal = 14.dp, vertical = 12.dp)
            )
        }

        Box(Modifier.weight(1f)) {
            when (view) {
                LogView.ERRORS -> ErrorsList(vm, backdrop)
                LogView.FULL -> FullLog(vm, backdrop)
            }
        }
        Box(Modifier.height(96.dp))
    }
}

@Composable
private fun ErrorsList(vm: BuildViewModel, backdrop: Backdrop) {
    if (vm.errors.isEmpty()) {
        GlassCard(backdrop, Modifier.fillMaxWidth()) {
            Text(
                if (vm.phase == Phase.SUCCESS) "لا توجد أخطاء ✓" else "لا توجد أخطاء مسجلة حتى الآن.",
                color = Color.White, fontSize = 15.sp
            )
        }
        return
    }
    LazyColumn(verticalArrangement = Arrangement.spacedBy(12.dp)) {
        items(vm.errors) { e ->
            GlassCard(backdrop, Modifier.fillMaxWidth(), radius = 24.dp, tint = Bad.copy(alpha = 0.14f)) {
                Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                    GlassChip(backdrop, e.source, Blue.copy(alpha = 0.35f))
                    e.line?.let { GlassChip(backdrop, "سطر $it") }
                    e.column?.let { GlassChip(backdrop, "عمود $it") }
                }
                Text(
                    e.message, color = Color.White, fontSize = 15.sp, fontWeight = FontWeight.SemiBold,
                    modifier = Modifier.padding(top = 10.dp)
                )
                Text(
                    "📄 ${e.location}", color = Color.White.copy(alpha = 0.8f), fontSize = 12.sp,
                    fontFamily = FontFamily.Monospace, modifier = Modifier.padding(top = 8.dp)
                )
            }
        }
    }
}

@Composable
private fun FullLog(vm: BuildViewModel, backdrop: Backdrop) {
    val state = rememberLazyListState()
    LaunchedEffect(vm.logs.size) { if (vm.logs.isNotEmpty()) state.scrollToItem(vm.logs.size - 1) }
    GlassCard(backdrop, Modifier.fillMaxSize(), radius = 24.dp, tint = Color.Black.copy(alpha = 0.25f)) {
        if (vm.logs.isEmpty()) {
            Text("لا يوجد سجل بعد.", color = Color.White.copy(alpha = 0.7f))
        } else {
            LazyColumn(state = state) {
                items(vm.logs) { l ->
                    val c = when (l.level) {
                        LogLevel.ERROR -> Bad
                        LogLevel.WARN -> Warn
                        LogLevel.OK -> Ok
                        LogLevel.CMD -> Color(0xFF8FB0FF)
                        LogLevel.INFO -> Color.White.copy(alpha = 0.85f)
                    }
                    Text(l.text, color = c, fontSize = 11.5.sp, fontFamily = FontFamily.Monospace, lineHeight = 15.sp)
                }
            }
        }
    }
}

private fun copy(ctx: Context, text: String) {
    val cm = ctx.getSystemService(Context.CLIPBOARD_SERVICE) as ClipboardManager
    cm.setPrimaryClip(ClipData.newPlainText("ApkBuilder", text))
}
