package com.apkbuilder.settings

import android.content.Context
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableFloatStateOf
import androidx.compose.runtime.mutableIntStateOf
import androidx.compose.runtime.mutableLongStateOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.setValue
import androidx.compose.ui.graphics.Color
import com.apkbuilder.ui.AccentColors
import com.apkbuilder.ui.BarColors

object SaveMode {
    const val DEFAULT = 0   // Download/ApkBuilder
    const val CUSTOM = 1    // مجلد يختاره المستخدم
    const val ASK = 2       // سؤال في كل مرة
}

/** كل إعدادات التطبيق — حالة Compose + حفظ تلقائي في SharedPreferences. */
class AppSettings(context: Context) {
    private val p = context.getSharedPreferences("settings", Context.MODE_PRIVATE)

    // المظهر
    var accentIndex by mutableIntStateOf(p.getInt("accent", 0).coerceIn(0, 19)); private set
    val accent: Color get() = AccentColors[accentIndex].color

    // Liquid Glass
    var blur by mutableFloatStateOf(p.getFloat("blur", 8f)); private set             // dp
    var refraction by mutableFloatStateOf(p.getFloat("refraction", 24f)); private set // dp
    var transparency by mutableFloatStateOf(p.getFloat("transparency", 0.6f)); private set // 0..1
    var barColorIndex by mutableIntStateOf(p.getInt("barColor", 0).coerceIn(0, 19)); private set
    val barColor: Color get() = BarColors[barColorIndex].color

    // الحفظ
    var saveMode by mutableIntStateOf(p.getInt("saveMode", SaveMode.DEFAULT)); private set
    var folderUri by mutableStateOf(p.getString("folderUri", "") ?: ""); private set
    var useCustomName by mutableStateOf(p.getBoolean("useCustomName", false)); private set
    var customName by mutableStateOf(p.getString("customName", "") ?: ""); private set

    // GitHub
    var token by mutableStateOf(p.getString("token", "") ?: ""); private set
    var repo by mutableStateOf(p.getString("repo", "") ?: ""); private set
    var workflowId by mutableLongStateOf(p.getLong("workflowId", 0L)); private set
    var workflowName by mutableStateOf(p.getString("workflowName", "") ?: ""); private set

    fun setAccent(i: Int) { accentIndex = i; p.edit().putInt("accent", i).apply() }
    fun setBlur(v: Float) { blur = v; p.edit().putFloat("blur", v).apply() }
    fun setRefraction(v: Float) { refraction = v; p.edit().putFloat("refraction", v).apply() }
    fun setTransparency(v: Float) { transparency = v; p.edit().putFloat("transparency", v).apply() }
    fun setBarColor(i: Int) { barColorIndex = i; p.edit().putInt("barColor", i).apply() }

    fun resetGlass() {
        setBlur(8f); setRefraction(24f); setTransparency(0.6f); setBarColor(0)
    }

    fun setSaveMode(m: Int) { saveMode = m; p.edit().putInt("saveMode", m).apply() }
    fun setFolderUri(u: String) { folderUri = u; p.edit().putString("folderUri", u).apply() }
    fun setUseCustomName(v: Boolean) { useCustomName = v; p.edit().putBoolean("useCustomName", v).apply() }
    fun setCustomName(v: String) { customName = v; p.edit().putString("customName", v).apply() }

    fun setToken(v: String) { token = v; p.edit().putString("token", v).apply() }
    fun setRepo(v: String) { repo = v; p.edit().putString("repo", v).apply() }
    fun setWorkflow(id: Long, name: String) {
        workflowId = id; workflowName = name
        p.edit().putLong("workflowId", id).putString("workflowName", name).apply()
    }

    fun logout() {
        setToken(""); setRepo(""); setWorkflow(0L, "")
    }
}
