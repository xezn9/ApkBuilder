package com.apkbuilder

import android.app.Application
import android.content.ContentValues
import android.net.Uri
import android.os.Build
import android.os.Handler
import android.os.Looper
import android.provider.MediaStore
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateListOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.setValue
import androidx.lifecycle.AndroidViewModel
import androidx.lifecycle.viewModelScope
import com.apkbuilder.engine.BuildEngine
import com.apkbuilder.engine.BuildError
import com.apkbuilder.engine.BuildLogger
import com.apkbuilder.engine.LogLevel
import com.apkbuilder.engine.LogLine
import com.apkbuilder.engine.Phase
import com.apkbuilder.engine.ProjectImporter
import com.apkbuilder.engine.WorkflowParseException
import com.apkbuilder.engine.WorkflowParser
import kotlinx.coroutines.CancellationException
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.Job
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext
import java.io.File

class BuildViewModel(private val app: Application) : AndroidViewModel(app) {

    var ymlUri by mutableStateOf<Uri?>(null); private set
    var ymlName by mutableStateOf<String?>(null); private set
    var projectUris by mutableStateOf<List<Uri>>(emptyList()); private set
    var projectNames by mutableStateOf<List<String>>(emptyList()); private set

    var phase by mutableStateOf(Phase.IDLE); private set
    var statusText by mutableStateOf("جاهز"); private set
    var savedApks by mutableStateOf<List<String>>(emptyList()); private set
    var cacheMb by mutableStateOf(0L); private set

    val logs = mutableStateListOf<LogLine>()
    val errors = mutableStateListOf<BuildError>()

    private val main = Handler(Looper.getMainLooper())
    private var job: Job? = null
    private val importer = ProjectImporter(app)

    val isRunning: Boolean
        get() = phase == Phase.IMPORTING || phase == Phase.RESOLVING || phase == Phase.BUILDING

    private val logger = object : BuildLogger {
        override fun log(level: LogLevel, text: String) {
            main.post {
                logs.add(LogLine(level, text))
                if (logs.size > 6000) logs.removeRange(0, 1000)
            }
        }
        override fun error(error: BuildError) {
            main.post { errors.add(error) }
        }
        override fun status(text: String) {
            main.post { statusText = text }
        }
    }

    init { refreshCache() }

    fun pickYml(uri: Uri?) {
        uri ?: return
        ymlUri = uri
        ymlName = importer.displayName(uri)
    }

    fun pickProject(uris: List<Uri>) {
        if (uris.isEmpty()) return
        projectUris = uris
        projectNames = uris.map { importer.displayName(it) }
    }

    fun refreshCache() {
        viewModelScope.launch(Dispatchers.IO) {
            val mb = File(app.filesDir, "maven-cache").walkTopDown().filter { it.isFile }.sumOf { it.length() } / 1024 / 1024
            withContext(Dispatchers.Main) { cacheMb = mb }
        }
    }

    fun clearCache() {
        if (isRunning) return
        viewModelScope.launch(Dispatchers.IO) {
            File(app.filesDir, "maven-cache").deleteRecursively()
            File(app.filesDir, "gradle-home").deleteRecursively()
            refreshCache()
        }
    }

    fun cancel() {
        job?.cancel()
    }

    fun start() {
        val yml = ymlUri
        if (yml == null || projectUris.isEmpty() || isRunning) return
        logs.clear(); errors.clear(); savedApks = emptyList()

        job = viewModelScope.launch {
            val work = File(app.filesDir, "work")
            val engine = BuildEngine(app.filesDir, logger)
            try {
                phase = Phase.IMPORTING
                statusText = "استيراد الملفات…"
                val (text, root) = withContext(Dispatchers.IO) {
                    val t = importer.importWorkflow(yml, File(work, "build.yml"))
                    val r = importer.importProject(projectUris, File(work, "project")) {
                        logger.log(LogLevel.INFO, it)
                    }
                    t to r
                }
                logger.log(LogLevel.OK, "مجلد المشروع: ${root.name}")

                val workflow = try {
                    WorkflowParser.parse(text)
                } catch (e: WorkflowParseException) {
                    logger.error(BuildError(e.message ?: "YAML غير صالح", ymlName, e.line, e.column, "YAML"))
                    logger.log(LogLevel.ERROR, "خطأ في ${ymlName}: ${e.message} (سطر ${e.line ?: "?"})")
                    finish(Phase.FAILED, "خطأ في ملف build.yml")
                    return@launch
                }
                logger.log(LogLevel.OK, "الـ workflow «${workflow.name}» — ${workflow.steps.size} خطوة")

                phase = Phase.RESOLVING
                statusText = "تجهيز المكتبات (الكاش المشترك)…"
                engine.resolveLibraries(root)
                refreshCache()

                phase = Phase.BUILDING
                val result = engine.run(workflow, root)

                val apks = result.artifacts.filter { it.extension == "apk" }.ifEmpty { engine.findApks(root) }
                if (apks.isNotEmpty()) {
                    val saved = withContext(Dispatchers.IO) { apks.map { save(it) } }
                    main.post { savedApks = saved }
                }

                if (result.success) {
                    finish(Phase.SUCCESS, if (apks.isEmpty()) "اكتمل البناء (لا يوجد APK ناتج)" else "تم البناء بنجاح ✓")
                } else {
                    if (errors.isEmpty()) {
                        logger.error(BuildError("فشل البناء بدون رسالة خطأ محددة — راجع السجل الكامل", null, null, null, "Build"))
                    }
                    finish(Phase.FAILED, "فشل البناء")
                }
            } catch (e: CancellationException) {
                finish(Phase.CANCELLED, "أُلغي البناء")
                throw e
            } catch (e: Exception) {
                val top = e.stackTrace.firstOrNull()
                logger.error(BuildError(e.message ?: e.javaClass.simpleName, top?.fileName, top?.lineNumber, null, "ApkBuilder"))
                logger.log(LogLevel.ERROR, e.stackTraceToString().take(2000))
                finish(Phase.FAILED, "خطأ غير متوقع")
            }
        }
    }

    private fun finish(p: Phase, text: String) {
        main.post { phase = p; statusText = text }
    }

    /** يحفظ الـ APK في Downloads/ApkBuilder ويعيد وصف المكان. */
    private fun save(file: File): String {
        return try {
            if (Build.VERSION.SDK_INT >= 29) {
                val values = ContentValues().apply {
                    put(MediaStore.Downloads.DISPLAY_NAME, file.name)
                    put(MediaStore.Downloads.MIME_TYPE, "application/vnd.android.package-archive")
                    put(MediaStore.Downloads.RELATIVE_PATH, "Download/ApkBuilder")
                }
                val uri = app.contentResolver.insert(MediaStore.Downloads.EXTERNAL_CONTENT_URI, values)
                    ?: error("MediaStore insert failed")
                app.contentResolver.openOutputStream(uri)?.use { out -> file.inputStream().use { it.copyTo(out) } }
                "Download/ApkBuilder/${file.name}"
            } else {
                val dir = File(app.getExternalFilesDir(null), "outputs").apply { mkdirs() }
                file.copyTo(File(dir, file.name), overwrite = true)
                File(dir, file.name).absolutePath
            }
        } catch (e: Exception) {
            val dir = File(app.getExternalFilesDir(null), "outputs").apply { mkdirs() }
            file.copyTo(File(dir, file.name), overwrite = true).absolutePath
        }
    }

    fun logAsText(): String = logs.joinToString("\n") { "[${it.level}] ${it.text}" }

    fun errorsAsText(): String = errors.joinToString("\n\n") {
        "الخطأ: ${it.message}\nالمكان: ${it.file ?: "—"}\nالسطر: ${it.line ?: "—"}  العمود: ${it.column ?: "—"}\nالمصدر: ${it.source}"
    }
}
