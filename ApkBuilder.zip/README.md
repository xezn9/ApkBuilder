# ApkBuilder

تطبيق أندرويد (Kotlin + Jetpack Compose) يبني مشاريع أندرويد بنفس فكرة GitHub Actions:
تختار ملف `build.yml` وملفات المشروع (zip أو ملفات)، ويشغّل خطوات الـ workflow ويعرض الأخطاء.

## الميزات
- زر لاختيار `build.yml` وزر لاختيار ملفات المشروع (zip يُفك تلقائياً مع حماية Zip-Slip).
- يقرأ `jobs.*.steps` (`run:` و `uses:`) ويدعم `env` و `working-directory` و `if: always()/failure()` و `${{ github.workspace }}`.
- صفحة **السجل**: تبويب «الأخطاء» (نص الخطأ، الملف، السطر، العمود، المصدر) + تبويب «السجل الكامل» + نسخ.
  يحلل أخطاء Kotlin / javac / AAPT2 / سكربتات Gradle / فشل حل المكتبات / Stack traces / أخطاء YAML (بسطر وعمود).
- **كاش مكتبات دائم ومشترك**: يمسح ملفات gradle/toml، ينزّل كل مكتبة (pom + module + aar/jar + المعتمدات)
  إلى `filesDir/maven-cache` بصيغة Maven مرة واحدة فقط، ثم يعيد استخدامها في أي مشروع. ويُضاف الكاش إلى Gradle
  كمستودع بأعلى أولوية عبر `init.d` في `GRADLE_USER_HOME` (الذي هو أيضاً دائم، فلا يُعاد تنزيل توزيعة Gradle).
- واجهة Liquid Glass بمكتبة `io.github.kyant0:backdrop:2.0.0` في كل التطبيق (`liquidGlass()` في `GlassUi.kt`).

## قيود يجب معرفتها
- أندرويد نفسه لا يحتوي JDK ولا Android SDK. خطوات `run:` تُنفَّذ بشيل الجهاز، لذلك أوامر مثل `gradle assembleDebug`
  تحتاج JDK 17 + Android SDK في الـ PATH (بيئة Linux/Termux مثلاً). بدونها يعرض التطبيق الخطأ بوضوح في صفحة السجل.
- تأثير lens/vibrancy يحتاج Android 13+؛ في الإصدارات الأقدم يتدهور إلى blur/tint.

## البناء على GitHub
ارفع `ApkBuilder.zip` إلى جذر المستودع و `build.yml` إلى `.github/workflows/` — الـ workflow يفك الضغط ويبني ويرفع الـ APK كـ artifact.
