package com.kotlinide.app

import android.os.Bundle
import android.widget.Toast
import androidx.activity.ComponentActivity
import androidx.activity.compose.BackHandler
import androidx.activity.compose.setContent
import androidx.activity.enableEdgeToEdge
import androidx.compose.foundation.*
import androidx.compose.foundation.interaction.MutableInteractionSource
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.text.BasicTextField
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Text
import androidx.compose.material3.darkColorScheme
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.SolidColor
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.TextRange
import androidx.compose.ui.text.TextStyle
import androidx.compose.ui.text.font.FontFamily
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.input.TextFieldValue
import androidx.compose.ui.text.input.VisualTransformation
import androidx.compose.ui.platform.LocalLayoutDirection
import androidx.compose.ui.unit.Dp
import androidx.compose.ui.unit.LayoutDirection
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.kyant.backdrop.Backdrop
import com.kyant.backdrop.backdrops.LayerBackdrop
import com.kyant.backdrop.backdrops.layerBackdrop
import com.kyant.backdrop.backdrops.rememberLayerBackdrop
import com.kyant.backdrop.drawBackdrop
import com.kyant.backdrop.effects.blur
import com.kyant.backdrop.effects.lens
import com.kyant.backdrop.effects.vibrancy
import androidx.compose.animation.*
import androidx.compose.animation.core.*
import androidx.compose.foundation.interaction.collectIsPressedAsState
import androidx.compose.foundation.lazy.itemsIndexed
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.rounded.ArrowBack
import androidx.compose.material.icons.automirrored.rounded.ArrowForward
import androidx.compose.material.icons.rounded.*
import androidx.compose.material3.Icon
import androidx.compose.ui.composed
import androidx.compose.ui.focus.onFocusChanged
import androidx.compose.ui.graphics.graphicsLayer
import androidx.compose.ui.graphics.vector.ImageVector
import androidx.compose.ui.text.style.TextOverflow
import kotlin.math.cos
import kotlin.math.sin
import kotlinx.coroutines.delay
import java.io.File

class MainActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        enableEdgeToEdge()
        setContent { MaterialTheme(colorScheme = darkColorScheme()) { App() } }
    }
}

// ───────────── Liquid Glass (من مكتبة backdrop) ─────────────

fun Modifier.glass(backdrop: Backdrop, radius: Dp = 24.dp): Modifier = drawBackdrop(
    backdrop = backdrop,
    shape = { RoundedCornerShape(radius) },
    effects = {
        vibrancy()
        blur(6.dp.toPx())
        lens(12.dp.toPx(), 24.dp.toPx())
    },
    onDrawSurface = { drawRect(Color.White.copy(alpha = 0.14f)) }
)

// ───────────── أدوات الأنيميشن ─────────────

/** ضغطة بارتداد: الزر يصغّر وهو مضغوط ويرجع بنطّة زنبركية */
@OptIn(ExperimentalFoundationApi::class)
fun Modifier.bounceClick(
    enabled: Boolean = true,
    scaleDown: Float = 0.92f,
    onLongClick: (() -> Unit)? = null,
    onClick: () -> Unit
): Modifier = composed {
    val src = remember { MutableInteractionSource() }
    val pressed by src.collectIsPressedAsState()
    val s by animateFloatAsState(
        targetValue = if (pressed && enabled) scaleDown else 1f,
        animationSpec = spring(dampingRatio = Spring.DampingRatioMediumBouncy, stiffness = Spring.StiffnessMedium),
        label = "press"
    )
    this.graphicsLayer { scaleX = s; scaleY = s }
        .combinedClickable(
            interactionSource = src, indication = null, enabled = enabled,
            onLongClick = onLongClick, onClick = onClick
        )
}

/** دخول العناصر بالتتابع (تطلع من تحت مع فيد) */
@Composable
fun Modifier.staggerIn(index: Int): Modifier {
    val a = remember { Animatable(if (index < 12) 0f else 1f) }
    LaunchedEffect(Unit) {
        if (a.value < 1f) {
            delay(index * 35L)
            a.animateTo(1f, spring(dampingRatio = Spring.DampingRatioLowBouncy, stiffness = Spring.StiffnessLow))
        }
    }
    return this.graphicsLayer {
        alpha = a.value.coerceIn(0f, 1f)
        translationY = (1f - a.value) * 48.dp.toPx()
    }
}

@Composable
fun Wallpaper() {
    val inf = rememberInfiniteTransition(label = "wall")
    val t by inf.animateFloat(
        initialValue = 0f, targetValue = 1f,
        animationSpec = infiniteRepeatable(tween(30000, easing = LinearEasing)), label = "wallT"
    )
    Canvas(Modifier.fillMaxSize()) {
        val a = t * 2f * Math.PI.toFloat()
        drawRect(Color(0xFF0B0F1A))
        fun blob(c: Color, x: Float, y: Float, phase: Float) {
            val center = Offset(
                size.width * (x + 0.08f * sin(a + phase)),
                size.height * (y + 0.06f * cos(a + phase))
            )
            val r = size.width * 0.75f
            drawCircle(Brush.radialGradient(listOf(c, Color.Transparent), center, r), r, center)
        }
        blob(Color(0xFF7C4DFF), 0.15f, 0.12f, 0f)
        blob(Color(0xFF00BFA5), 0.95f, 0.45f, 2.1f)
        blob(Color(0xFFFF4081), 0.2f, 0.9f, 4.2f)
    }
}

@Composable
fun GlassScaffold(
    backdrop: LayerBackdrop,
    top: @Composable RowScope.() -> Unit,
    bottom: (@Composable RowScope.() -> Unit)? = null,
    dialog: (@Composable () -> Unit)? = null,
    content: @Composable (PaddingValues) -> Unit
) {
    val sb = WindowInsets.statusBars.asPaddingValues().calculateTopPadding()
    val nb = WindowInsets.navigationBars.asPaddingValues().calculateBottomPadding()
    val pad = PaddingValues(top = sb + 76.dp, bottom = nb + if (bottom != null) 84.dp else 16.dp)
    var appeared by remember { mutableStateOf(false) }
    LaunchedEffect(Unit) { appeared = true }
    val p by animateFloatAsState(
        targetValue = if (appeared) 1f else 0f,
        animationSpec = spring(dampingRatio = Spring.DampingRatioLowBouncy, stiffness = Spring.StiffnessLow),
        label = "bars"
    )
    Box(Modifier.fillMaxSize()) {
        Box(Modifier.fillMaxSize().layerBackdrop(backdrop)) { Wallpaper(); content(pad) }
        Row(
            Modifier.align(Alignment.TopCenter)
                .graphicsLayer { alpha = p.coerceIn(0f, 1f); translationY = -(1f - p) * 60.dp.toPx() }
                .statusBarsPadding().padding(12.dp, 8.dp)
                .fillMaxWidth().height(56.dp).glass(backdrop, 28.dp).padding(horizontal = 8.dp),
            verticalAlignment = Alignment.CenterVertically, content = top
        )
        if (bottom != null) Row(
            Modifier.align(Alignment.BottomCenter)
                .graphicsLayer { alpha = p.coerceIn(0f, 1f); translationY = (1f - p) * 60.dp.toPx() }
                .imePadding().navigationBarsPadding().padding(12.dp, 8.dp)
                .fillMaxWidth().height(60.dp).glass(backdrop, 30.dp)
                .horizontalScroll(rememberScrollState()).padding(horizontal = 8.dp),
            verticalAlignment = Alignment.CenterVertically, content = bottom
        )
        dialog?.invoke()
    }
}

@Composable
fun GlassButton(
    backdrop: Backdrop,
    text: String? = null,
    icon: ImageVector? = null,
    enabled: Boolean = true,
    onClick: () -> Unit
) {
    val a by animateFloatAsState(if (enabled) 1f else 0.4f, tween(200), label = "btnAlpha")
    Box(
        Modifier.padding(horizontal = 4.dp).height(44.dp).bounceClick(enabled, onClick = onClick)
            .glass(backdrop, 22.dp).padding(horizontal = if (text == null) 10.dp else 16.dp)
            .widthIn(min = if (text == null) 24.dp else 0.dp),
        contentAlignment = Alignment.Center
    ) {
        Row(verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.spacedBy(8.dp)) {
            if (icon != null) {
                AnimatedContent(
                    targetState = icon,
                    transitionSpec = { (fadeIn(tween(180)) + scaleIn(initialScale = 0.5f)) togetherWith (fadeOut(tween(120)) + scaleOut(targetScale = 0.5f)) },
                    label = "btnIcon"
                ) { ic -> Icon(imageVector = ic, contentDescription = text, tint = Color.White.copy(a), modifier = Modifier.size(20.dp)) }
            }
            if (text != null) Text(text, color = Color.White.copy(a), fontSize = 14.sp)
        }
    }
}

@Composable
fun BarTitle(text: String, modifier: Modifier = Modifier) {
    AnimatedContent(
        targetState = text,
        modifier = modifier.padding(horizontal = 8.dp),
        transitionSpec = { (slideInVertically { it / 2 } + fadeIn(tween(200))) togetherWith (slideOutVertically { -it / 2 } + fadeOut(tween(150))) },
        label = "title"
    ) { t ->
        Text(t, color = Color.White, fontSize = 17.sp, fontWeight = FontWeight.SemiBold, maxLines = 1, overflow = TextOverflow.Ellipsis)
    }
}

/** نافذة زجاجية: الخلفية تتعتّم تدريجياً والبطاقة تطلع بنطّة وتختفي بنعومة */
@Composable
fun DialogHost(backdrop: Backdrop, dlg: Dlg?, onDismiss: () -> Unit, content: @Composable ColumnScope.(Dlg) -> Unit) {
    val none = remember { MutableInteractionSource() }
    val scrim by animateFloatAsState(if (dlg != null) 0.45f else 0f, tween(220), label = "scrim")
    if (dlg != null || scrim > 0.001f) {
        Box(
            Modifier.fillMaxSize().background(Color.Black.copy(scrim)).clickable(none, null, enabled = dlg != null) { onDismiss() },
            contentAlignment = Alignment.Center
        ) {
            AnimatedContent(
                targetState = dlg,
                transitionSpec = {
                    (fadeIn(tween(220, delayMillis = 40)) + scaleIn(initialScale = 0.88f, animationSpec = spring(Spring.DampingRatioMediumBouncy, Spring.StiffnessMediumLow))) togetherWith
                        (fadeOut(tween(140)) + scaleOut(targetScale = 0.92f, animationSpec = tween(160)))
                },
                label = "dialog"
            ) { d ->
                if (d != null) {
                    Column(
                        Modifier.padding(24.dp).fillMaxWidth().glass(backdrop, 28.dp)
                            .clickable(none, null) {}.padding(20.dp),
                        verticalArrangement = Arrangement.spacedBy(12.dp)
                    ) { content(d) }
                }
            }
        }
    }
}

@Composable
fun PlainButton(text: String, icon: ImageVector? = null, tint: Color = Color.White, onClick: () -> Unit) = Row(
    Modifier.bounceClick(onClick = onClick).clip(RoundedCornerShape(14.dp)).background(tint.copy(0.16f))
        .padding(horizontal = 18.dp, vertical = 10.dp),
    verticalAlignment = Alignment.CenterVertically,
    horizontalArrangement = Arrangement.spacedBy(10.dp)
) {
    if (icon != null) Icon(imageVector = icon, contentDescription = null, tint = tint, modifier = Modifier.size(20.dp))
    Text(text, color = tint)
}

@Composable
fun Field(value: String, hint: String, onChange: (String) -> Unit) {
    var focused by remember { mutableStateOf(false) }
    val border by animateColorAsState(if (focused) Color.White.copy(0.7f) else Color.Transparent, tween(200), label = "fieldBorder")
    Box(
        Modifier.fillMaxWidth().clip(RoundedCornerShape(14.dp)).background(Color.White.copy(0.12f))
            .border(1.5.dp, border, RoundedCornerShape(14.dp)).padding(14.dp)
    ) {
        androidx.compose.animation.AnimatedVisibility(visible = value.isEmpty(), enter = fadeIn(), exit = fadeOut()) {
            Text(hint, color = Color.White.copy(0.5f))
        }
        CompositionLocalProvider(LocalLayoutDirection provides LayoutDirection.Ltr) {
            BasicTextField(value, onChange, singleLine = true, cursorBrush = SolidColor(Color.White),
                textStyle = TextStyle(color = Color.White, fontSize = 16.sp),
                modifier = Modifier.fillMaxWidth().onFocusChanged { focused = it.isFocused })
        }
    }
}

// ───────────── التنقل ─────────────

sealed interface Dlg {
    data object NewProject : Dlg
    data class NewEntry(val parent: File, val dir: Boolean) : Dlg
    data class Rename(val f: File) : Dlg
    data class Delete(val items: List<File>) : Dlg
    data class Pick(val items: List<File>, val move: Boolean) : Dlg
}

data class Route(val project: File?, val editing: File?) {
    val level: Int get() = if (project == null) 0 else if (editing == null) 1 else 2
}

@Composable
fun App() {
    val ctx = LocalContext.current
    val base = remember { File(ctx.filesDir, "projects").apply { mkdirs() } }
    var project by remember { mutableStateOf<File?>(null) }
    var editing by remember { mutableStateOf<File?>(null) }
    BackHandler(project != null) { if (editing != null) editing = null else project = null }
    val rtl = LocalLayoutDirection.current == LayoutDirection.Rtl
    val dir = if (rtl) -1 else 1
    AnimatedContent(
        targetState = Route(project, editing),
        transitionSpec = {
            val fwd = targetState.level > initialState.level
            val move = tween<androidx.compose.ui.unit.IntOffset>(380, easing = FastOutSlowInEasing)
            val fade = tween<Float>(300)
            val t = if (fwd)
                (slideInHorizontally(move) { dir * it } + fadeIn(fade)) togetherWith
                    (slideOutHorizontally(move) { -dir * it / 3 } + fadeOut(fade))
            else
                (slideInHorizontally(move) { -dir * it / 3 } + fadeIn(fade)) togetherWith
                    (slideOutHorizontally(move) { dir * it } + fadeOut(fade))
            t.apply { targetContentZIndex = if (fwd) 1f else -1f }
        },
        label = "nav"
    ) { r ->
        val backdrop = rememberLayerBackdrop()
        val p = r.project
        val e = r.editing
        when {
            p != null && e != null -> EditorScreen(e, backdrop) { editing = null }
            p != null -> ProjectScreen(p, backdrop, { project = null }) { editing = it }
            else -> ProjectsScreen(base, backdrop) { project = it }
        }
    }
}

fun toast(ctx: android.content.Context, s: String) = Toast.makeText(ctx, s, Toast.LENGTH_SHORT).show()

// ───────────── شاشة المشاريع ─────────────

@Composable
fun ProjectsScreen(base: File, backdrop: LayerBackdrop, onOpen: (File) -> Unit) {
    val ctx = LocalContext.current
    var tick by remember { mutableIntStateOf(0) }
    var dlg by remember { mutableStateOf<Dlg?>(null) }
    val projects = remember(tick) { sortedChildren(base).filter { it.isDirectory } }
    GlassScaffold(
        backdrop,
        top = {
            BarTitle("Kotlin IDE", Modifier.weight(1f))
            GlassButton(backdrop, "مشروع جديد", Icons.Rounded.Add) { dlg = Dlg.NewProject }
        },
        dialog = {
            DialogHost(backdrop, dlg, { dlg = null }) { d ->
                when (d) {
                    Dlg.NewProject -> {
                        var name by remember { mutableStateOf("") }
                        var pkg by remember { mutableStateOf("com.example.app") }
                        BarTitle("مشروع جديد")
                        Field(name, "اسم المشروع") { name = it }
                        Field(pkg, "اسم الحزمة (package)") { pkg = it }
                        PlainButton("إنشاء", Icons.Rounded.Check) {
                            val n = name.trim()
                            when {
                                !Regex("[A-Za-z0-9_-]+").matches(n) -> toast(ctx, "اسم المشروع: حروف انجليزية وأرقام فقط")
                                !Regex("[a-z][a-z0-9_]*(\\.[a-z][a-z0-9_]*)+").matches(pkg) -> toast(ctx, "اسم الحزمة غير صالح")
                                File(base, n).exists() -> toast(ctx, "المشروع موجود")
                                else -> { createProject(base, n, pkg); dlg = null; tick++ }
                            }
                        }
                    }
                    is Dlg.Delete -> {
                        BarTitle(d.items.first().name)
                        PlainButton("تصدير ZIP إلى التنزيلات/KotlinIDE", Icons.Rounded.Archive) {
                            toast(ctx, if (exportZip(ctx, d.items.first())) "تم التصدير: التنزيلات/KotlinIDE" else "فشل التصدير")
                            dlg = null
                        }
                        PlainButton("حذف المشروع نهائياً", Icons.Rounded.DeleteForever, Color(0xFFFF6B6B)) {
                            d.items.forEach { it.deleteRecursively() }; dlg = null; tick++
                        }
                    }
                    else -> {}
                }
            }
        }
    ) { pad ->
        LazyColumn(contentPadding = pad, modifier = Modifier.padding(horizontal = 16.dp), verticalArrangement = Arrangement.spacedBy(8.dp)) {
            if (projects.isEmpty()) item { Text("ماكو مشاريع. اضغط «مشروع جديد» حتى تبدي.", color = Color.White.copy(0.7f), modifier = Modifier.staggerIn(0)) }
            itemsIndexed(projects, key = { _, f -> f.path }) { index, f ->
                Row(
                    Modifier.fillMaxWidth().animateItem().staggerIn(index)
                        .bounceClick(scaleDown = 0.96f, onLongClick = { dlg = Dlg.Delete(listOf(f)) }, onClick = { onOpen(f) })
                        .clip(RoundedCornerShape(20.dp)).background(Color.White.copy(0.08f)).padding(20.dp),
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Icon(Icons.Rounded.Folder, contentDescription = null, tint = Color(0xFFFFC857), modifier = Modifier.size(28.dp))
                    Spacer(Modifier.width(14.dp))
                    Text(f.name, color = Color.White, fontSize = 18.sp, modifier = Modifier.weight(1f))
                    Icon(Icons.AutoMirrored.Rounded.ArrowForward, contentDescription = null, tint = Color.White.copy(0.4f), modifier = Modifier.size(20.dp))
                }
            }
            if (projects.isNotEmpty()) item { Text("اضغط مطوّلاً على مشروع لتصديره أو حذفه", color = Color.White.copy(0.5f), fontSize = 12.sp, modifier = Modifier.staggerIn(1)) }
        }
    }
}

// ───────────── شاشة ملفات المشروع ─────────────

@Composable
fun FileIcon(f: File, open: Boolean) {
    when {
        f.isDirectory -> Crossfade(targetState = open, label = "folderIcon") { o ->
            Icon(if (o) Icons.Rounded.FolderOpen else Icons.Rounded.Folder, contentDescription = null, tint = Color(0xFFFFC857), modifier = Modifier.size(22.dp))
        }
        f.extension == "kt" || f.extension == "kts" ->
            Icon(Icons.Rounded.Code, contentDescription = null, tint = Color(0xFFB388FF), modifier = Modifier.size(22.dp))
        else ->
            Icon(Icons.Rounded.Description, contentDescription = null, tint = Color.White.copy(0.7f), modifier = Modifier.size(22.dp))
    }
}

@Composable
fun ProjectScreen(root: File, backdrop: LayerBackdrop, onBack: () -> Unit, onOpen: (File) -> Unit) {
    val ctx = LocalContext.current
    var tick by remember { mutableIntStateOf(0) }
    var expanded by remember { mutableStateOf(setOf(File(root, "app").path)) }
    var selected by remember { mutableStateOf(setOf<File>()) }
    var dlg by remember { mutableStateOf<Dlg?>(null) }
    val rows = remember(tick, expanded) { buildList<Pair<File, Int>> { flatten(root, expanded, 0, this) } }
    val sel = selected.toList()
    val single = selected.singleOrNull()
    fun target(): File = when {
        single == null -> root
        single.isDirectory -> single
        else -> single.parentFile ?: root
    }
    fun done() { selected = emptySet(); dlg = null; tick++ }
    val fixedSel = sel.any { it.isFixed(root) }

    GlassScaffold(
        backdrop,
        top = {
            GlassButton(backdrop, icon = Icons.AutoMirrored.Rounded.ArrowBack) { onBack() }
            BarTitle(if (sel.isEmpty()) root.name else "${sel.size} محدد", Modifier.weight(1f))
            AnimatedContent(
                targetState = sel.isNotEmpty(),
                transitionSpec = { (fadeIn() + scaleIn(initialScale = 0.8f)) togetherWith (fadeOut() + scaleOut(targetScale = 0.8f)) },
                label = "topAction"
            ) { hasSel ->
                if (hasSel) {
                    GlassButton(backdrop, "إلغاء", Icons.Rounded.Close) { selected = emptySet() }
                } else {
                    GlassButton(backdrop, "ZIP", Icons.Rounded.Archive) {
                        toast(ctx, if (exportZip(ctx, root)) "تم التصدير: التنزيلات/KotlinIDE/${root.name}.zip" else "فشل التصدير")
                    }
                }
            }
        },
        bottom = {
            GlassButton(backdrop, "ملف", Icons.Rounded.NoteAdd) { dlg = Dlg.NewEntry(target(), false) }
            GlassButton(backdrop, "مجلد", Icons.Rounded.CreateNewFolder) { dlg = Dlg.NewEntry(target(), true) }
            GlassButton(backdrop, "نسخ", Icons.Rounded.ContentCopy, sel.isNotEmpty()) { dlg = Dlg.Pick(sel, false) }
            GlassButton(backdrop, "نقل", Icons.Rounded.DriveFileMove, sel.isNotEmpty() && !fixedSel) { dlg = Dlg.Pick(sel, true) }
            GlassButton(backdrop, "تسمية", Icons.Rounded.DriveFileRenameOutline, single != null && !fixedSel) { dlg = Dlg.Rename(single!!) }
            GlassButton(backdrop, "حذف", Icons.Rounded.Delete, sel.isNotEmpty() && !fixedSel) { dlg = Dlg.Delete(sel) }
        },
        dialog = {
            DialogHost(backdrop, dlg, { dlg = null }) { d ->
                when (d) {
                    is Dlg.NewEntry -> {
                        var name by remember { mutableStateOf("") }
                        BarTitle(if (d.dir) "مجلد جديد" else "ملف جديد")
                        Text("داخل: ${d.parent.relativeTo(root).path.ifEmpty { "/" }}", color = Color.White.copy(0.6f), fontSize = 12.sp)
                        Field(name, if (d.dir) "اسم المجلد" else "مثال: Utils.kt") { name = it }
                        PlainButton("إنشاء", Icons.Rounded.Check) {
                            val n = name.trim()
                            val f = File(d.parent, n)
                            when {
                                n.isEmpty() || n.contains("..") -> toast(ctx, "اسم غير صالح")
                                f.exists() -> toast(ctx, "موجود من قبل")
                                else -> {
                                    if (d.dir) f.mkdirs() else { f.parentFile?.mkdirs(); f.writeText(ktHeader(f)) }
                                    expanded = expanded + d.parent.path
                                    done()
                                }
                            }
                        }
                    }
                    is Dlg.Rename -> {
                        var name by remember { mutableStateOf(d.f.name) }
                        BarTitle("إعادة تسمية")
                        Field(name, "الاسم الجديد") { name = it }
                        PlainButton("تم", Icons.Rounded.Check) {
                            val t = File(d.f.parentFile, name.trim())
                            if (name.isBlank() || name.contains("/") || t.exists()) toast(ctx, "اسم غير صالح أو موجود")
                            else { d.f.renameTo(t); done() }
                        }
                    }
                    is Dlg.Delete -> {
                        BarTitle("حذف ${d.items.size} عنصر؟")
                        PlainButton("حذف", Icons.Rounded.Delete, Color(0xFFFF6B6B)) {
                            d.items.filter { !it.isFixed(root) }.forEach { it.deleteRecursively() }; done()
                        }
                    }
                    is Dlg.Pick -> {
                        BarTitle(if (d.move) "نقل إلى…" else "نسخ إلى…")
                        val dirs = remember(tick) { allDirs(root) }
                        LazyColumn(Modifier.heightIn(max = 360.dp)) {
                            items(dirs, key = { it.first.path }) { (dir, depth) ->
                                Row(
                                    Modifier.fillMaxWidth().bounceClick(scaleDown = 0.97f) {
                                        val ok = d.items.all { transfer(it, dir, d.move) }
                                        if (!ok) toast(ctx, "ما يصير تنقل/تنسخ مجلد داخل نفسه")
                                        expanded = expanded + dir.path
                                        done()
                                    }.padding(start = (depth * 16).dp, top = 10.dp, bottom = 10.dp),
                                    verticalAlignment = Alignment.CenterVertically
                                ) {
                                    Icon(Icons.Rounded.Folder, contentDescription = null, tint = Color(0xFFFFC857), modifier = Modifier.size(20.dp))
                                    Spacer(Modifier.width(10.dp))
                                    Text(if (dir == root) root.name else dir.name, color = Color.White)
                                }
                            }
                        }
                    }
                    else -> {}
                }
            }
        }
    ) { pad ->
        LazyColumn(contentPadding = pad, modifier = Modifier.padding(horizontal = 12.dp), verticalArrangement = Arrangement.spacedBy(4.dp)) {
            itemsIndexed(rows, key = { _, r -> r.first.path }) { index, (f, depth) ->
                val isSel = f in selected
                val open = f.path in expanded
                val bg by animateColorAsState(if (isSel) Color(0x663D8BFF) else Color.White.copy(0.06f), tween(220), label = "rowBg")
                val rot by animateFloatAsState(
                    if (f.isDirectory && open) 90f else 0f,
                    spring(dampingRatio = Spring.DampingRatioMediumBouncy, stiffness = Spring.StiffnessMediumLow), label = "chev"
                )
                CompositionLocalProvider(LocalLayoutDirection provides LayoutDirection.Ltr) {
                    Row(
                        Modifier.fillMaxWidth().animateItem().staggerIn(index)
                            .bounceClick(
                                scaleDown = 0.97f,
                                onLongClick = { selected = if (isSel) selected - f else selected + f },
                                onClick = {
                                    when {
                                        selected.isNotEmpty() -> selected = if (isSel) selected - f else selected + f
                                        f.isDirectory -> expanded = if (open) expanded - f.path else expanded + f.path
                                        else -> onOpen(f)
                                    }
                                }
                            )
                            .clip(RoundedCornerShape(14.dp)).background(bg)
                            .padding(start = (12 + depth * 18).dp, top = 12.dp, bottom = 12.dp, end = 12.dp),
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        if (f.isDirectory)
                            Icon(Icons.Rounded.ChevronRight, contentDescription = null, tint = Color.White.copy(0.6f),
                                modifier = Modifier.size(20.dp).graphicsLayer { rotationZ = rot })
                        else Spacer(Modifier.size(20.dp))
                        Spacer(Modifier.width(4.dp))
                        FileIcon(f, open)
                        Spacer(Modifier.width(10.dp))
                        Text(f.name, color = Color.White, fontFamily = FontFamily.Monospace, fontSize = 14.sp, modifier = Modifier.weight(1f))
                        if (f.isFixed(root))
                            Icon(Icons.Rounded.Lock, contentDescription = null, tint = Color.White.copy(0.5f), modifier = Modifier.size(14.dp))
                        androidx.compose.animation.AnimatedVisibility(
                            visible = isSel,
                            enter = scaleIn(spring(Spring.DampingRatioMediumBouncy)) + fadeIn(),
                            exit = scaleOut() + fadeOut()
                        ) {
                            Icon(Icons.Rounded.Check, contentDescription = null, tint = Color.White, modifier = Modifier.padding(start = 8.dp).size(20.dp))
                        }
                    }
                }
            }
        }
    }
}

// ───────────── المحرر ─────────────

@Composable
fun EditorScreen(file: File, backdrop: LayerBackdrop, onClose: () -> Unit) {
    val ctx = LocalContext.current
    var tfv by remember(file) { mutableStateOf(TextFieldValue(runCatching { file.readText() }.getOrDefault(""))) }
    val latest by rememberUpdatedState(tfv)
    DisposableEffect(file) { onDispose { runCatching { file.writeText(latest.text) } } }
    var saved by remember { mutableStateOf(false) }
    LaunchedEffect(saved) { if (saved) { delay(1400); saved = false } }
    fun insert(s: String) {
        val sel = tfv.selection
        tfv = TextFieldValue(tfv.text.replaceRange(sel.min, sel.max, s), TextRange(sel.min + s.length))
    }
    val highlight = file.extension in setOf("kt", "kts", "java", "gradle")
    GlassScaffold(
        backdrop,
        top = {
            GlassButton(backdrop, icon = Icons.AutoMirrored.Rounded.ArrowBack) { onClose() }
            BarTitle(file.name, Modifier.weight(1f))
            GlassButton(backdrop, "حفظ", if (saved) Icons.Rounded.Check else Icons.Rounded.Save) {
                file.writeText(tfv.text); saved = true; toast(ctx, "تم الحفظ")
            }
        },
        bottom = {
            listOf("    ", "{", "}", "(", ")", "[", "]", "\"", ";", ":", "=", "<", ">", "\$", "!", "?", ".", ",").forEach { s ->
                GlassButton(backdrop, if (s.isBlank()) "Tab" else s) { insert(s) }
            }
        }
    ) { pad ->
        CompositionLocalProvider(LocalLayoutDirection provides LayoutDirection.Ltr) {
            Box(Modifier.fillMaxSize().imePadding().padding(pad).padding(horizontal = 12.dp).clip(RoundedCornerShape(20.dp)).background(Color(0x77000000))) {
                BasicTextField(
                    tfv, { tfv = it },
                    textStyle = TextStyle(fontFamily = FontFamily.Monospace, fontSize = 14.sp, color = Color(0xFFE6E6E6), lineHeight = 20.sp),
                    cursorBrush = SolidColor(Color.White),
                    visualTransformation = if (highlight) KotlinHighlight else VisualTransformation.None,
                    modifier = Modifier.fillMaxSize().verticalScroll(rememberScrollState()).padding(14.dp)
                )
            }
        }
    }
}
