package com.kotlinide.app

import android.os.Bundle
import android.widget.Toast
import androidx.activity.ComponentActivity
import androidx.activity.compose.BackHandler
import androidx.activity.compose.setContent
import androidx.activity.enableEdgeToEdge
import androidx.compose.foundation.*
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.text.BasicTextField
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Text
import androidx.compose.material3.darkColorScheme
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.SolidColor
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.TextRange
import androidx.compose.ui.text.TextStyle
import androidx.compose.ui.text.font.FontFamily
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.input.TextFieldValue
import androidx.compose.ui.text.input.VisualTransformation
import androidx.compose.ui.platform.LocalLayoutDirection
import androidx.compose.ui.unit.Dp
import androidx.compose.ui.unit.LayoutDirection
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.kyant.backdrop.Backdrop
import com.kyant.backdrop.backdrops.LayerBackdrop
import com.kyant.backdrop.backdrops.layerBackdrop
import com.kyant.backdrop.backdrops.rememberLayerBackdrop
import com.kyant.backdrop.drawBackdrop
import com.kyant.backdrop.effects.blur
import com.kyant.backdrop.effects.lens
import com.kyant.backdrop.effects.vibrancy
import java.io.File

class MainActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        enableEdgeToEdge()
        setContent { MaterialTheme(colorScheme = darkColorScheme()) { App() } }
    }
}

// ───────────── Liquid Glass (من مكتبة backdrop) ─────────────

fun Modifier.glass(backdrop: Backdrop, radius: Dp = 24.dp): Modifier = drawBackdrop(
    backdrop = backdrop,
    shape = { RoundedCornerShape(radius) },
    effects = {
        vibrancy()
        blur(6.dp.toPx())
        lens(12.dp.toPx(), 24.dp.toPx())
    },
    onDrawSurface = { drawRect(Color.White.copy(alpha = 0.14f)) }
)

@Composable
fun Wallpaper() {
    Canvas(Modifier.fillMaxSize()) {
        drawRect(Color(0xFF0B0F1A))
        fun blob(c: Color, x: Float, y: Float) {
            val center = Offset(size.width * x, size.height * y)
            val r = size.width * 0.75f
            drawCircle(Brush.radialGradient(listOf(c, Color.Transparent), center, r), r, center)
        }
        blob(Color(0xFF7C4DFF), 0.15f, 0.12f)
        blob(Color(0xFF00BFA5), 0.95f, 0.45f)
        blob(Color(0xFFFF4081), 0.2f, 0.9f)
    }
}

@Composable
fun GlassScaffold(
    backdrop: LayerBackdrop,
    top: @Composable RowScope.() -> Unit,
    bottom: (@Composable RowScope.() -> Unit)? = null,
    dialog: (@Composable () -> Unit)? = null,
    content: @Composable (PaddingValues) -> Unit
) {
    val sb = WindowInsets.statusBars.asPaddingValues().calculateTopPadding()
    val nb = WindowInsets.navigationBars.asPaddingValues().calculateBottomPadding()
    val pad = PaddingValues(top = sb + 76.dp, bottom = nb + if (bottom != null) 84.dp else 16.dp)
    Box(Modifier.fillMaxSize()) {
        Box(Modifier.fillMaxSize().layerBackdrop(backdrop)) { Wallpaper(); content(pad) }
        Row(
            Modifier.align(Alignment.TopCenter).statusBarsPadding().padding(12.dp, 8.dp)
                .fillMaxWidth().height(56.dp).glass(backdrop, 28.dp).padding(horizontal = 8.dp),
            verticalAlignment = Alignment.CenterVertically, content = top
        )
        if (bottom != null) Row(
            Modifier.align(Alignment.BottomCenter).imePadding().navigationBarsPadding().padding(12.dp, 8.dp)
                .fillMaxWidth().height(60.dp).glass(backdrop, 30.dp)
                .horizontalScroll(rememberScrollState()).padding(horizontal = 8.dp),
            verticalAlignment = Alignment.CenterVertically, content = bottom
        )
        dialog?.invoke()
    }
}

@Composable
fun GlassButton(backdrop: Backdrop, text: String, enabled: Boolean = true, onClick: () -> Unit) {
    Box(
        Modifier.padding(horizontal = 4.dp).height(44.dp).glass(backdrop, 22.dp)
            .clickable(enabled = enabled, onClick = onClick).padding(horizontal = 16.dp),
        contentAlignment = Alignment.Center
    ) { Text(text, color = Color.White.copy(if (enabled) 1f else 0.4f), fontSize = 14.sp) }
}

@Composable
fun BarTitle(text: String, modifier: Modifier = Modifier) =
    Text(text, color = Color.White, fontSize = 17.sp, fontWeight = FontWeight.SemiBold, maxLines = 1, modifier = modifier.padding(horizontal = 8.dp))

@Composable
fun GlassDialog(backdrop: Backdrop, onDismiss: () -> Unit, content: @Composable ColumnScope.() -> Unit) {
    val none = remember { MutableInteractionSource() }
    Box(
        Modifier.fillMaxSize().background(Color.Black.copy(0.45f)).clickable(none, null) { onDismiss() },
        contentAlignment = Alignment.Center
    ) {
        Column(
            Modifier.padding(24.dp).fillMaxWidth().glass(backdrop, 28.dp)
                .clickable(none, null) {}.padding(20.dp),
            verticalArrangement = Arrangement.spacedBy(12.dp), content = content
        )
    }
}

@Composable
fun PlainButton(text: String, onClick: () -> Unit) = Box(
    Modifier.clip(RoundedCornerShape(14.dp)).background(Color.White.copy(0.16f)).clickable(onClick = onClick)
        .padding(horizontal = 18.dp, vertical = 10.dp)
) { Text(text, color = Color.White) }

@Composable
fun Field(value: String, hint: String, onChange: (String) -> Unit) = Box(
    Modifier.fillMaxWidth().clip(RoundedCornerShape(14.dp)).background(Color.White.copy(0.12f)).padding(14.dp)
) {
    if (value.isEmpty()) Text(hint, color = Color.White.copy(0.5f))
    CompositionLocalProvider(LocalLayoutDirection provides LayoutDirection.Ltr) {
        BasicTextField(value, onChange, singleLine = true, cursorBrush = SolidColor(Color.White),
            textStyle = TextStyle(color = Color.White, fontSize = 16.sp), modifier = Modifier.fillMaxWidth())
    }
}

// ───────────── التنقل ─────────────

sealed interface Dlg {
    data object NewProject : Dlg
    data class NewEntry(val parent: File, val dir: Boolean) : Dlg
    data class Rename(val f: File) : Dlg
    data class Delete(val items: List<File>) : Dlg
    data class Pick(val items: List<File>, val move: Boolean) : Dlg
}

@Composable
fun App() {
    val ctx = LocalContext.current
    val base = remember { File(ctx.filesDir, "projects").apply { mkdirs() } }
    val backdrop = rememberLayerBackdrop()
    var project by remember { mutableStateOf<File?>(null) }
    var editing by remember { mutableStateOf<File?>(null) }
    BackHandler(project != null) { if (editing != null) editing = null else project = null }
    val p = project
    val e = editing
    when {
        p != null && e != null -> EditorScreen(e, backdrop) { editing = null }
        p != null -> ProjectScreen(p, backdrop, { project = null }) { editing = it }
        else -> ProjectsScreen(base, backdrop) { project = it }
    }
}

fun toast(ctx: android.content.Context, s: String) = Toast.makeText(ctx, s, Toast.LENGTH_SHORT).show()

// ───────────── شاشة المشاريع ─────────────

@OptIn(ExperimentalFoundationApi::class)
@Composable
fun ProjectsScreen(base: File, backdrop: LayerBackdrop, onOpen: (File) -> Unit) {
    val ctx = LocalContext.current
    var tick by remember { mutableIntStateOf(0) }
    var dlg by remember { mutableStateOf<Dlg?>(null) }
    val projects = remember(tick) { sortedChildren(base).filter { it.isDirectory } }
    GlassScaffold(
        backdrop,
        top = {
            BarTitle("Kotlin IDE", Modifier.weight(1f))
            GlassButton(backdrop, "＋ مشروع جديد") { dlg = Dlg.NewProject }
        },
        dialog = {
            when (val d = dlg) {
                Dlg.NewProject -> {
                    var name by remember { mutableStateOf("") }
                    var pkg by remember { mutableStateOf("com.example.app") }
                    GlassDialog(backdrop, { dlg = null }) {
                        BarTitle("مشروع جديد")
                        Field(name, "اسم المشروع") { name = it }
                        Field(pkg, "اسم الحزمة (package)") { pkg = it }
                        PlainButton("إنشاء") {
                            val n = name.trim()
                            when {
                                !Regex("[A-Za-z0-9_-]+").matches(n) -> toast(ctx, "اسم المشروع: حروف انجليزية وأرقام فقط")
                                !Regex("[a-z][a-z0-9_]*(\\.[a-z][a-z0-9_]*)+").matches(pkg) -> toast(ctx, "اسم الحزمة غير صالح")
                                File(base, n).exists() -> toast(ctx, "المشروع موجود")
                                else -> { createProject(base, n, pkg); dlg = null; tick++ }
                            }
                        }
                    }
                }
                is Dlg.Delete -> GlassDialog(backdrop, { dlg = null }) {
                    BarTitle(d.items.first().name)
                    PlainButton("📦 تصدير ZIP إلى التنزيلات/KotlinIDE") {
                        toast(ctx, if (exportZip(ctx, d.items.first())) "تم التصدير: التنزيلات/KotlinIDE" else "فشل التصدير")
                        dlg = null
                    }
                    PlainButton("🗑 حذف المشروع نهائياً") { d.items.forEach { it.deleteRecursively() }; dlg = null; tick++ }
                }
                else -> {}
            }
        }
    ) { pad ->
        LazyColumn(contentPadding = pad, modifier = Modifier.padding(horizontal = 16.dp), verticalArrangement = Arrangement.spacedBy(8.dp)) {
            if (projects.isEmpty()) item { Text("ماكو مشاريع. اضغط «مشروع جديد» حتى تبدي.", color = Color.White.copy(0.7f)) }
            items(projects, key = { it.path }) { f ->
                Box(
                    Modifier.fillMaxWidth().clip(RoundedCornerShape(20.dp)).background(Color.White.copy(0.08f))
                        .combinedClickable(onClick = { onOpen(f) }, onLongClick = { dlg = Dlg.Delete(listOf(f)) })
                        .padding(20.dp)
                ) { Text("📁  ${f.name}", color = Color.White, fontSize = 18.sp) }
            }
            if (projects.isNotEmpty()) item { Text("اضغط مطوّلاً على مشروع لتصديره أو حذفه", color = Color.White.copy(0.5f), fontSize = 12.sp) }
        }
    }
}

// ───────────── شاشة ملفات المشروع ─────────────

@OptIn(ExperimentalFoundationApi::class)
@Composable
fun ProjectScreen(root: File, backdrop: LayerBackdrop, onBack: () -> Unit, onOpen: (File) -> Unit) {
    val ctx = LocalContext.current
    var tick by remember { mutableIntStateOf(0) }
    var expanded by remember { mutableStateOf(setOf(File(root, "app").path)) }
    var selected by remember { mutableStateOf(setOf<File>()) }
    var dlg by remember { mutableStateOf<Dlg?>(null) }
    val rows = remember(tick, expanded) { buildList<Pair<File, Int>> { flatten(root, expanded, 0, this) } }
    val sel = selected.toList()
    val single = selected.singleOrNull()
    fun target(): File = when {
        single == null -> root
        single.isDirectory -> single
        else -> single.parentFile ?: root
    }
    fun done() { selected = emptySet(); dlg = null; tick++ }
    val fixedSel = sel.any { it.isFixed(root) }

    GlassScaffold(
        backdrop,
        top = {
            GlassButton(backdrop, "‹") { onBack() }
            BarTitle(if (sel.isEmpty()) root.name else "${sel.size} محدد", Modifier.weight(1f))
            if (sel.isNotEmpty()) GlassButton(backdrop, "إلغاء") { selected = emptySet() }
            else GlassButton(backdrop, "📦 ZIP") {
                toast(ctx, if (exportZip(ctx, root)) "تم التصدير: التنزيلات/KotlinIDE/${root.name}.zip" else "فشل التصدير")
            }
        },
        bottom = {
            GlassButton(backdrop, "📄 ملف") { dlg = Dlg.NewEntry(target(), false) }
            GlassButton(backdrop, "📁 مجلد") { dlg = Dlg.NewEntry(target(), true) }
            GlassButton(backdrop, "نسخ", sel.isNotEmpty()) { dlg = Dlg.Pick(sel, false) }
            GlassButton(backdrop, "نقل", sel.isNotEmpty() && !fixedSel) { dlg = Dlg.Pick(sel, true) }
            GlassButton(backdrop, "تسمية", single != null && !fixedSel) { dlg = Dlg.Rename(single!!) }
            GlassButton(backdrop, "حذف", sel.isNotEmpty() && !fixedSel) { dlg = Dlg.Delete(sel) }
        },
        dialog = {
            when (val d = dlg) {
                is Dlg.NewEntry -> {
                    var name by remember { mutableStateOf("") }
                    GlassDialog(backdrop, { dlg = null }) {
                        BarTitle(if (d.dir) "مجلد جديد" else "ملف جديد")
                        Text("داخل: ${d.parent.relativeTo(root).path.ifEmpty { "/" }}", color = Color.White.copy(0.6f), fontSize = 12.sp)
                        Field(name, if (d.dir) "اسم المجلد" else "مثال: Utils.kt") { name = it }
                        PlainButton("إنشاء") {
                            val n = name.trim()
                            val f = File(d.parent, n)
                            when {
                                n.isEmpty() || n.contains("..") -> toast(ctx, "اسم غير صالح")
                                f.exists() -> toast(ctx, "موجود من قبل")
                                else -> {
                                    if (d.dir) f.mkdirs() else { f.parentFile?.mkdirs(); f.writeText(ktHeader(f)) }
                                    expanded = expanded + d.parent.path
                                    done()
                                }
                            }
                        }
                    }
                }
                is Dlg.Rename -> {
                    var name by remember { mutableStateOf(d.f.name) }
                    GlassDialog(backdrop, { dlg = null }) {
                        BarTitle("إعادة تسمية")
                        Field(name, "الاسم الجديد") { name = it }
                        PlainButton("تم") {
                            val t = File(d.f.parentFile, name.trim())
                            if (name.isBlank() || name.contains("/") || t.exists()) toast(ctx, "اسم غير صالح أو موجود")
                            else { d.f.renameTo(t); done() }
                        }
                    }
                }
                is Dlg.Delete -> GlassDialog(backdrop, { dlg = null }) {
                    BarTitle("حذف ${d.items.size} عنصر؟")
                    PlainButton("حذف") { d.items.filter { !it.isFixed(root) }.forEach { it.deleteRecursively() }; done() }
                }
                is Dlg.Pick -> GlassDialog(backdrop, { dlg = null }) {
                    BarTitle(if (d.move) "نقل إلى…" else "نسخ إلى…")
                    LazyColumn(Modifier.heightIn(max = 360.dp)) {
                        items(remember(tick) { allDirs(root) }, key = { it.first.path }) { (dir, depth) ->
                            Text(
                                "📁 " + if (dir == root) root.name else dir.name, color = Color.White,
                                modifier = Modifier.fillMaxWidth().clickable {
                                    val ok = d.items.all { transfer(it, dir, d.move) }
                                    if (!ok) toast(ctx, "ما يصير تنقل/تنسخ مجلد داخل نفسه")
                                    expanded = expanded + dir.path
                                    done()
                                }.padding(start = (depth * 16).dp, top = 10.dp, bottom = 10.dp)
                            )
                        }
                    }
                }
                else -> {}
            }
        }
    ) { pad ->
        LazyColumn(contentPadding = pad, modifier = Modifier.padding(horizontal = 12.dp), verticalArrangement = Arrangement.spacedBy(4.dp)) {
            items(rows, key = { it.first.path }) { (f, depth) ->
                val isSel = f in selected
                CompositionLocalProvider(LocalLayoutDirection provides LayoutDirection.Ltr) {
                    Row(
                        Modifier.fillMaxWidth().clip(RoundedCornerShape(14.dp))
                            .background(if (isSel) Color(0x663D8BFF) else Color.White.copy(0.06f))
                            .combinedClickable(
                                onClick = {
                                    when {
                                        selected.isNotEmpty() -> selected = if (isSel) selected - f else selected + f
                                        f.isDirectory -> expanded = if (f.path in expanded) expanded - f.path else expanded + f.path
                                        else -> onOpen(f)
                                    }
                                },
                                onLongClick = { selected = if (isSel) selected - f else selected + f }
                            )
                            .padding(start = (12 + depth * 18).dp, top = 12.dp, bottom = 12.dp, end = 12.dp),
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        val icon = when {
                            f.isDirectory -> if (f.path in expanded) "▾ 📂" else "▸ 📁"
                            f.extension == "kt" || f.extension == "kts" -> "🟣"
                            else -> "📄"
                        }
                        Text("$icon  ${f.name}", color = Color.White, fontFamily = FontFamily.Monospace, fontSize = 14.sp, modifier = Modifier.weight(1f))
                        if (f.isFixed(root)) Text("🔒", fontSize = 12.sp)
                    }
                }
            }
        }
    }
}

// ───────────── المحرر ─────────────

@Composable
fun EditorScreen(file: File, backdrop: LayerBackdrop, onClose: () -> Unit) {
    val ctx = LocalContext.current
    var tfv by remember(file) { mutableStateOf(TextFieldValue(runCatching { file.readText() }.getOrDefault(""))) }
    val latest by rememberUpdatedState(tfv)
    DisposableEffect(file) { onDispose { runCatching { file.writeText(latest.text) } } }
    fun insert(s: String) {
        val sel = tfv.selection
        tfv = TextFieldValue(tfv.text.replaceRange(sel.min, sel.max, s), TextRange(sel.min + s.length))
    }
    val highlight = file.extension in setOf("kt", "kts", "java", "gradle")
    GlassScaffold(
        backdrop,
        top = {
            GlassButton(backdrop, "‹") { onClose() }
            BarTitle(file.name, Modifier.weight(1f))
            GlassButton(backdrop, "حفظ") { file.writeText(tfv.text); toast(ctx, "تم الحفظ") }
        },
        bottom = {
            listOf("    ", "{", "}", "(", ")", "[", "]", "\"", ";", ":", "=", "<", ">", "\$", "!", "?", ".", ",").forEach { s ->
                GlassButton(backdrop, if (s.isBlank()) "Tab" else s) { insert(s) }
            }
        }
    ) { pad ->
        CompositionLocalProvider(LocalLayoutDirection provides LayoutDirection.Ltr) {
            Box(Modifier.fillMaxSize().imePadding().padding(pad).padding(horizontal = 12.dp).clip(RoundedCornerShape(20.dp)).background(Color(0x77000000))) {
                BasicTextField(
                    tfv, { tfv = it },
                    textStyle = TextStyle(fontFamily = FontFamily.Monospace, fontSize = 14.sp, color = Color(0xFFE6E6E6), lineHeight = 20.sp),
                    cursorBrush = SolidColor(Color.White),
                    visualTransformation = if (highlight) KotlinHighlight else VisualTransformation.None,
                    modifier = Modifier.fillMaxSize().verticalScroll(rememberScrollState()).padding(14.dp)
                )
            }
        }
    }
}
