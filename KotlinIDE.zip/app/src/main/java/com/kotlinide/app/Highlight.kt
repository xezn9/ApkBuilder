package com.kotlinide.app

import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.AnnotatedString
import androidx.compose.ui.text.SpanStyle
import androidx.compose.ui.text.input.OffsetMapping
import androidx.compose.ui.text.input.TransformedText
import androidx.compose.ui.text.input.VisualTransformation

private val KW = Regex("\\b(package|import|class|interface|object|fun|val|var|if|else|when|for|while|do|return|override|private|public|internal|protected|data|sealed|enum|companion|null|true|false|is|in|as|try|catch|finally|throw|suspend|by|init|this|super|open|abstract|const|lateinit|typealias|plugins|dependencies)\\b")
private val STR = Regex("\"\"\"[\\s\\S]*?\"\"\"|\"(\\\\.|[^\"\\\\\\n])*\"")
private val CMT = Regex("//.*|/\\*[\\s\\S]*?\\*/")
private val NUM = Regex("\\b\\d+(\\.\\d+)?[fFL]?\\b")
private val ANN = Regex("@\\w+")
private val TYPE = Regex("\\b[A-Z]\\w*\\b")

object KotlinHighlight : VisualTransformation {
    override fun filter(text: AnnotatedString): TransformedText {
        val s = text.text
        val b = AnnotatedString.Builder(s)
        fun paint(r: Regex, c: Color) = r.findAll(s).forEach {
            b.addStyle(SpanStyle(color = c), it.range.first, it.range.last + 1)
        }
        paint(NUM, Color(0xFFF78C6C))
        paint(TYPE, Color(0xFFFFCB6B))
        paint(KW, Color(0xFFC792EA))
        paint(ANN, Color(0xFF82AAFF))
        paint(STR, Color(0xFFC3E88D))
        paint(CMT, Color(0xFF7F8CA3))
        return TransformedText(b.toAnnotatedString(), OffsetMapping.Identity)
    }
}
