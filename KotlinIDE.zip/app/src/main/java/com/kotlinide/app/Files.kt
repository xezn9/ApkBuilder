package com.kotlinide.app

import android.content.ContentValues
import android.content.Context
import android.provider.MediaStore
import java.io.File
import java.util.zip.ZipEntry
import java.util.zip.ZipOutputStream

/** الملفات والمجلدات الثابتة بجذر أي مشروع: ما تنحذف ولا تننقل ولا تتغير تسميتها */
val FIXED = setOf("build.gradle.kts", "settings.gradle.kts", "gradle.properties", "gradle", "app")

fun File.isFixed(root: File) = parentFile == root && name in FIXED

fun createProject(base: File, name: String, pkg: String): File {
    val root = File(base, name)
    fun w(path: String, text: String) {
        File(root, path).apply { parentFile?.mkdirs(); writeText(text.trimIndent() + "\n") }
    }
    w("settings.gradle.kts", """
        pluginManagement {
            repositories { google(); mavenCentral(); gradlePluginPortal() }
        }
        dependencyResolutionManagement {
            repositoriesMode.set(RepositoriesMode.FAIL_ON_PROJECT_REPOS)
            repositories { google(); mavenCentral() }
        }
        rootProject.name = "$name"
        include(":app")
    """)
    w("build.gradle.kts", """
        plugins {
            id("com.android.application") version "8.9.1" apply false
            id("org.jetbrains.kotlin.android") version "2.1.20" apply false
            id("org.jetbrains.kotlin.plugin.compose") version "2.1.20" apply false
        }
    """)
    w("gradle.properties", """
        org.gradle.jvmargs=-Xmx2g -Dfile.encoding=UTF-8
        android.useAndroidX=true
        kotlin.code.style=official
    """)
    w("gradle/wrapper/gradle-wrapper.properties", """
        distributionBase=GRADLE_USER_HOME
        distributionPath=wrapper/dists
        distributionUrl=https\://services.gradle.org/distributions/gradle-8.11.1-bin.zip
        zipStoreBase=GRADLE_USER_HOME
        zipStorePath=wrapper/dists
    """)
    w("app/build.gradle.kts", """
        plugins {
            id("com.android.application")
            id("org.jetbrains.kotlin.android")
            id("org.jetbrains.kotlin.plugin.compose")
        }
        android {
            namespace = "$pkg"
            compileSdk = 35
            defaultConfig {
                applicationId = "$pkg"
                minSdk = 24
                targetSdk = 35
                versionCode = 1
                versionName = "1.0"
            }
            buildFeatures { compose = true }
            compileOptions {
                sourceCompatibility = JavaVersion.VERSION_17
                targetCompatibility = JavaVersion.VERSION_17
            }
            kotlinOptions { jvmTarget = "17" }
        }
        dependencies {
            implementation(platform("androidx.compose:compose-bom:2025.04.01"))
            implementation("androidx.activity:activity-compose:1.10.1")
            implementation("androidx.compose.ui:ui")
            implementation("androidx.compose.material3:material3")
        }
    """)
    w("app/src/main/AndroidManifest.xml", """
        <?xml version="1.0" encoding="utf-8"?>
        <manifest xmlns:android="http://schemas.android.com/apk/res/android">
            <application
                android:label="$name"
                android:theme="@android:style/Theme.Material.NoActionBar">
                <activity android:name=".MainActivity" android:exported="true">
                    <intent-filter>
                        <action android:name="android.intent.action.MAIN" />
                        <category android:name="android.intent.category.LAUNCHER" />
                    </intent-filter>
                </activity>
            </application>
        </manifest>
    """)
    w("app/src/main/java/${pkg.replace('.', '/')}/MainActivity.kt", """
        package $pkg

        import android.os.Bundle
        import androidx.activity.ComponentActivity
        import androidx.activity.compose.setContent
        import androidx.compose.material3.Text

        class MainActivity : ComponentActivity() {
            override fun onCreate(savedInstanceState: Bundle?) {
                super.onCreate(savedInstanceState)
                setContent { Text("Hello from $name") }
            }
        }
    """)
    return root
}

fun ktHeader(f: File): String {
    if (f.extension != "kt") return ""
    val m = Regex("src/[^/]+/(java|kotlin)/(.+)$").find(f.parentFile?.invariantSeparatorsPath ?: "") ?: return ""
    return "package ${m.groupValues[2].replace('/', '.')}\n\n"
}

fun uniqueIn(dir: File, name: String): File {
    var f = File(dir, name)
    if (!f.exists()) return f
    val base = f.nameWithoutExtension
    val ext = if (f.extension.isEmpty()) "" else "." + f.extension
    var i = 1
    while (f.exists()) { f = File(dir, "${base}_copy${if (i > 1) i.toString() else ""}$ext"); i++ }
    return f
}

fun transfer(src: File, destDir: File, move: Boolean): Boolean {
    if (src.isDirectory && (destDir.canonicalPath + "/").startsWith(src.canonicalPath + "/")) return false
    if (move && src.parentFile == destDir) return true
    val t = uniqueIn(destDir, src.name)
    val ok = if (src.isDirectory) src.copyRecursively(t) else { src.copyTo(t); true }
    if (ok && move) src.deleteRecursively()
    return ok
}

fun sortedChildren(dir: File): List<File> =
    dir.listFiles()?.sortedWith(compareBy({ !it.isDirectory }, { it.name.lowercase() })) ?: emptyList()

fun flatten(dir: File, expanded: Set<String>, depth: Int, out: MutableList<Pair<File, Int>>) {
    for (f in sortedChildren(dir)) {
        out += f to depth
        if (f.isDirectory && f.path in expanded) flatten(f, expanded, depth + 1, out)
    }
}

fun allDirs(dir: File, depth: Int = 0, out: MutableList<Pair<File, Int>> = mutableListOf()): List<Pair<File, Int>> {
    out += dir to depth
    sortedChildren(dir).filter { it.isDirectory }.forEach { allDirs(it, depth + 1, out) }
    return out
}

/** يصدّر المشروع كملف zip إلى: التنزيلات/KotlinIDE/اسم_المشروع.zip */
fun exportZip(ctx: Context, root: File): Boolean = runCatching {
    val name = root.name + ".zip"
    val rel = "Download/KotlinIDE/"
    val res = ctx.contentResolver
    val coll = MediaStore.Downloads.EXTERNAL_CONTENT_URI
    runCatching {
        res.delete(
            coll,
            "${MediaStore.MediaColumns.DISPLAY_NAME}=? AND ${MediaStore.MediaColumns.RELATIVE_PATH}=?",
            arrayOf(name, rel)
        )
    }
    val values = ContentValues().apply {
        put(MediaStore.MediaColumns.DISPLAY_NAME, name)
        put(MediaStore.MediaColumns.MIME_TYPE, "application/zip")
        put(MediaStore.MediaColumns.RELATIVE_PATH, rel)
    }
    val uri = res.insert(coll, values)!!
    res.openOutputStream(uri)!!.use { out ->
        ZipOutputStream(out.buffered()).use { zip ->
            root.walkTopDown().filter { it != root }.forEach { f ->
                val path = f.relativeTo(root).invariantSeparatorsPath
                if (f.isDirectory) {
                    zip.putNextEntry(ZipEntry("$path/")); zip.closeEntry()
                } else {
                    zip.putNextEntry(ZipEntry(path))
                    f.inputStream().use { it.copyTo(zip) }
                    zip.closeEntry()
                }
            }
        }
    }
    true
}.getOrDefault(false)
